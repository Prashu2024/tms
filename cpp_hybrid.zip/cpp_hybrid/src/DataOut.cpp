// DataOut.cpp - Output file generation (VTK, TecPlot, curves)
// Translated from DataOut.f90

#include "DataOut.hpp"
#include <fstream>
#include <iomanip>
#include <sstream>
#include <iostream>
#include <cmath>
#include <cstdio>

namespace mpm3d {

static std::string fmt_e12_4_fortran(Real x) {
    if (x == 0.0) {
        return std::string("  0.0000E+00");
    }

    // Start from a canonical scientific string with 4 decimals, then shift one
    // decade to match the Fortran compiler's observed 0.x mantissa style.
    // Example:  7.9375E-05 ->  0.7938E-04
    char sci[64];
    std::snprintf(sci, sizeof(sci), "%.4E", static_cast<double>(x));

    // sci format: [-]d.ddddE[+-]dd
    const bool neg = (sci[0] == '-');
    const int d0_pos = neg ? 1 : 0;
    const char d0 = sci[d0_pos];
    const char d1 = sci[d0_pos + 2];
    const char d2 = sci[d0_pos + 3];
    const char d3 = sci[d0_pos + 4];
    const char d4 = sci[d0_pos + 5];

    const char exp_sign = sci[d0_pos + 7];
    const int exp_val = std::atoi(&sci[d0_pos + 8]);
    int exp10 = (exp_sign == '-') ? -exp_val : exp_val;
    exp10 += 1;

    int frac4 = (d0 - '0') * 1000 + (d1 - '0') * 100 + (d2 - '0') * 10 + (d3 - '0');
    const int round_digit = (d4 - '0');
    if (round_digit >= 5) {
        frac4 += 1;
    }

    // Handle carry: 0.99995 -> 1.0000, which we rewrite as 0.1000 with exp+1.
    if (frac4 >= 10000) {
        frac4 = 1000;
        exp10 += 1;
    }

    const Real mant = (neg ? -1.0 : 1.0) * (static_cast<Real>(frac4) / 10000.0);

    char mantbuf[32];
    std::snprintf(mantbuf, sizeof(mantbuf), "% .4f", static_cast<double>(mant));

    const char esign = (exp10 >= 0) ? '+' : '-';
    const int eabs = std::abs(exp10);
    char expbuf[16];
    std::snprintf(expbuf, sizeof(expbuf), "E%c%02d", esign, eabs);

    std::string s = std::string(mantbuf) + std::string(expbuf);
    if (s.size() < 12) {
        s = std::string(12 - s.size(), ' ') + s;
    }
    return s;
}

DataOut::DataOut()
    : output_counter_(0), write_tecplot_(false), write_paraview_(false),
      write_curves_(false), contact_enabled_(false), contact_force_({0, 0, 0}) {
}

void DataOut::initialize(const std::string& job_name, bool tecplot, bool paraview) {
    job_name_ = job_name;
    write_tecplot_ = tecplot;
    write_paraview_ = paraview;
    
    if (write_paraview_) {
        initializeParaView();
    }
    
    if (write_curves_) {
        initializeCurves();
    }
}

void DataOut::initializeParaView() {
    // Create PVD collection file for ParaView
    pvd_filename_ = job_name_ + ".pvd";
    std::ofstream pvd(pvd_filename_);
    
    pvd << "<?xml version=\"1.0\"?>\n";
    pvd << "<VTKFile type=\"Collection\" version=\"0.1\">\n";
    pvd << "  <Collection>\n";
    
    pvd.close();
    
    std::cout << "ParaView output initialized: " << pvd_filename_ << std::endl;
}

void DataOut::initializeCurves() {
    // Open curve data files
    curve_filename_ = job_name_ + "_curves.dat";
    energy_filename_ = job_name_ + "_energy.dat";
    momentum_filename_ = job_name_ + "_momentum.dat";
    
    std::ofstream curve(curve_filename_);
    curve << "# Time History Data\n";
    curve << "# Time  KE  IE  Total\n";
    curve.close();
    
    std::ofstream energy(energy_filename_);
    energy << "# Energy History\n";
    energy << "# Time  Total  Kinetic  Internal\n";
    energy.close();
    
    std::ofstream momentum(momentum_filename_);
    momentum << "# Momentum History\n";
    momentum << "# Time  Px  Py  Pz\n";
    momentum.close();

    // Fortran reference files used by MPM3D-F90 (append-only, no headers).
    // These are written so we can diff C++ vs Fortran line-by-line.
    {
        std::ofstream e("EnergyPlot.dat");
        (void)e;
    }
    {
        std::ofstream m("MomentumPlot.dat");
        (void)m;
    }
}

void DataOut::writeOutput(Real time, const ParticleList& particles,
                         const BodyList& bodies, const Grid& grid) {
    output_counter_++;
    
    if (write_paraview_) {
        writeParaView(time, particles, bodies, grid);
    }
    
    if (write_tecplot_) {
        writeTecPlot(time, particles, bodies);
    }
}

void DataOut::writeEnergy(Real time, const ParticleList& particles) {
    if (!write_curves_) return;
    writeCurves(time, particles);
}

void DataOut::writeEnergy(Real time, Real kinetic_energy, Real internal_energy,
                          const Vec3& momentum) {
    if (!write_curves_) return;

    const Real ke = kinetic_energy;
    const Real ie = internal_energy;

    // Write energy
    std::ofstream energy(energy_filename_, std::ios::app);
    energy << std::scientific << std::setprecision(6)
           << time << " " << (ke + ie) << " " << ke << " " << ie << "\n";
    energy.close();

    // Write momentum
    std::ofstream mom(momentum_filename_, std::ios::app);
    mom << std::scientific << std::setprecision(6)
        << time << " " << momentum[0] << " " << momentum[1] << " "
        << momentum[2] << "\n";
    mom.close();

    // Write contact force if contact is enabled
    if (contact_enabled_) {
        std::ofstream cf("ContforcPlot.dat", std::ios::app);
        cf << std::scientific << std::setprecision(6)
           << time << " " << contact_force_[0] << " " << contact_force_[1] << " "
           << contact_force_[2] << "\n";
        cf.close();
    }

    {
        std::ofstream ef("EnergyPlot.dat", std::ios::app);
        ef << fmt_e12_4_fortran(time)
           << fmt_e12_4_fortran(ke + ie)
           << fmt_e12_4_fortran(ke)
           << fmt_e12_4_fortran(ie)
           << "\n";
    }
    {
        std::ofstream mf("MomentumPlot.dat", std::ios::app);
        mf << fmt_e12_4_fortran(time)
           << fmt_e12_4_fortran(momentum[0])
           << fmt_e12_4_fortran(momentum[1])
           << fmt_e12_4_fortran(momentum[2])
           << "\n";
    }
}

void DataOut::writeParaView(Real time, const ParticleList& particles,
                            const BodyList& bodies, const Grid& grid) {
    // Write VTU file for this time step
    std::ostringstream oss;
    oss << job_name_ << "_" << std::setw(6) << std::setfill('0') 
        << output_counter_ << ".vtu";
    std::string vtu_filename = oss.str();
    
    std::ofstream vtu(vtu_filename);
    
    // VTU header
    vtu << "<?xml version=\"1.0\"?>\n";
    vtu << "<VTKFile type=\"UnstructuredGrid\" version=\"0.1\" byte_order=\"LittleEndian\">\n";
    vtu << "  <UnstructuredGrid>\n";
    
    // Count active particles
    int num_active = 0;
    for (const auto& p : particles) {
        if (p.getCell() >= 0) num_active++;
    }
    
    vtu << "    <Piece NumberOfPoints=\"" << num_active 
        << "\" NumberOfCells=\"" << num_active << "\">\n";
    
    // Points
    vtu << "      <Points>\n";
    vtu << "        <DataArray type=\"Float64\" NumberOfComponents=\"3\" format=\"ascii\">\n";
    for (const auto& p : particles) {
        if (p.getCell() >= 0) {
            Vec3 pos = p.getPosition();
            vtu << "          " << pos[0] << " " << pos[1] << " " << pos[2] << "\n";
        }
    }
    vtu << "        </DataArray>\n";
    vtu << "      </Points>\n";
    
    // Cells (particles as vertices)
    vtu << "      <Cells>\n";
    vtu << "        <DataArray type=\"Int32\" Name=\"connectivity\" format=\"ascii\">\n";
    for (int i = 0; i < num_active; ++i) {
        vtu << "          " << i << "\n";
    }
    vtu << "        </DataArray>\n";
    vtu << "        <DataArray type=\"Int32\" Name=\"offsets\" format=\"ascii\">\n";
    for (int i = 1; i <= num_active; ++i) {
        vtu << "          " << i << "\n";
    }
    vtu << "        </DataArray>\n";
    vtu << "        <DataArray type=\"UInt8\" Name=\"types\" format=\"ascii\">\n";
    for (int i = 0; i < num_active; ++i) {
        vtu << "          1\n";  // VTK_VERTEX
    }
    vtu << "        </DataArray>\n";
    vtu << "      </Cells>\n";
    
    // Point data
    vtu << "      <PointData>\n";
    
    // Velocity
    vtu << "        <DataArray type=\"Float64\" Name=\"Velocity\" NumberOfComponents=\"3\" format=\"ascii\">\n";
    for (const auto& p : particles) {
        if (p.getCell() >= 0) {
            Vec3 vel = p.getVelocity();
            vtu << "          " << vel[0] << " " << vel[1] << " " << vel[2] << "\n";
        }
    }
    vtu << "        </DataArray>\n";
    
    // Equivalent stress
    vtu << "        <DataArray type=\"Float64\" Name=\"EquivStress\" format=\"ascii\">\n";
    for (const auto& p : particles) {
        if (p.getCell() >= 0) {
            vtu << "          " << p.getEquivalentStress() << "\n";
        }
    }
    vtu << "        </DataArray>\n";
    
    // Plastic strain
    vtu << "        <DataArray type=\"Float64\" Name=\"PlasticStrain\" format=\"ascii\">\n";
    for (const auto& p : particles) {
        if (p.getCell() >= 0) {
            vtu << "          " << p.getPlasticStrain() << "\n";
        }
    }
    vtu << "        </DataArray>\n";
    
    // Pressure
    vtu << "        <DataArray type=\"Float64\" Name=\"Pressure\" format=\"ascii\">\n";
    for (const auto& p : particles) {
        if (p.getCell() >= 0) {
            vtu << "          " << -p.getMeanStress() << "\n";
        }
    }
    vtu << "        </DataArray>\n";
    
    // Damage
    vtu << "        <DataArray type=\"Float64\" Name=\"Damage\" format=\"ascii\">\n";
    for (const auto& p : particles) {
        if (p.getCell() >= 0) {
            vtu << "          " << p.getDamage() << "\n";
        }
    }
    vtu << "        </DataArray>\n";
    
    // Temperature
    vtu << "        <DataArray type=\"Float64\" Name=\"Temperature\" format=\"ascii\">\n";
    for (const auto& p : particles) {
        if (p.getCell() >= 0) {
            vtu << "          " << p.getTemperature() << "\n";
        }
    }
    vtu << "        </DataArray>\n";
    
    vtu << "      </PointData>\n";
    vtu << "    </Piece>\n";
    vtu << "  </UnstructuredGrid>\n";
    vtu << "</VTKFile>\n";
    
    vtu.close();
    
    // Add to PVD collection
    updatePVDCollection(time, vtu_filename);
    
    std::cout << "Written ParaView output: " << vtu_filename << std::endl;
}

void DataOut::updatePVDCollection(Real time, const std::string& vtu_file) {
    // Read existing PVD
    std::ifstream pvd_in(pvd_filename_);
    std::vector<std::string> lines;
    std::string line;
    
    while (std::getline(pvd_in, line)) {
        lines.push_back(line);
        if (line.find("</Collection>") != std::string::npos) {
            lines.pop_back();  // Remove closing tag
            break;
        }
    }
    pvd_in.close();
    
    // Rewrite with new entry
    std::ofstream pvd_out(pvd_filename_);
    for (const auto& l : lines) {
        pvd_out << l << "\n";
    }
    
    pvd_out << "    <DataSet timestep=\"" << time 
            << "\" file=\"" << vtu_file << "\"/>\n";
    pvd_out << "  </Collection>\n";
    pvd_out << "</VTKFile>\n";
    
    pvd_out.close();
}

void DataOut::writeTecPlot(Real time, const ParticleList& particles,
                           const BodyList& bodies) {
    // Write TecPlot format
    std::ostringstream oss;
    oss << job_name_ << "_" << std::setw(6) << std::setfill('0') 
        << output_counter_ << ".dat";
    std::string tec_filename = oss.str();
    
    std::ofstream tec(tec_filename);
    
    tec << "TITLE = \"MPM3D Results\"\n";
    tec << "VARIABLES = \"X\" \"Y\" \"Z\" \"Velocity\" \"EquivStress\" \"PlasticStrain\" \"Pressure\"\n";
    tec << "ZONE T=\"Time=" << time << "\"\n";
    
    for (const auto& p : particles) {
        if (p.getCell() >= 0) {
            Vec3 pos = p.getPosition();
            Vec3 vel = p.getVelocity();
            Real v_mag = norm(vel);
            
            tec << std::scientific << std::setprecision(6)
                << pos[0] << " " << pos[1] << " " << pos[2] << " "
                << v_mag << " " << p.getEquivalentStress() << " "
                << p.getPlasticStrain() << " " << -p.getMeanStress() << "\n";
        }
    }
    
    tec.close();
    
    std::cout << "Written TecPlot output: " << tec_filename << std::endl;
}

void DataOut::writeCurves(Real time, const ParticleList& particles) {
    // Calculate energies
    Real ke = 0.0;
    Real ie = 0.0;
    Real mx = 0.0, my = 0.0, mz = 0.0;

    // Match Fortran (src/Particle.f90 calcEnergy): strict global particle order
    // and explicit scalar accumulation.
    for (size_t pid = 0; pid < particles.size(); ++pid) {
        const auto &p = particles[pid];
        const Real mass = p.getMass();
        const Vec3 vel = p.getVelocity();

        const Real vx = vel[0];
        const Real vy = vel[1];
        const Real vz = vel[2];

        ke += 0.5 * mass * (vx * vx + vy * vy + vz * vz);
        ie += p.getInternalEnergy();
        mx += mass * vx;
        my += mass * vy;
        mz += mass * vz;
    }

    const Vec3 momentum = {mx, my, mz};
    
    // Write energy
    std::ofstream energy(energy_filename_, std::ios::app);
    energy << std::scientific << std::setprecision(6)
           << time << " " << (ke + ie) << " " << ke << " " << ie << "\n";
    energy.close();
    
    // Write momentum
    std::ofstream mom(momentum_filename_, std::ios::app);
    mom << std::scientific << std::setprecision(6)
        << time << " " << momentum[0] << " " << momentum[1] << " " << momentum[2] << "\n";
    mom.close();

    // Also write Fortran-compatible files (EnergyPlot.dat / MomentumPlot.dat)
    // Format: 4 columns, scientific, similar width/precision to Fortran (e12.4).

    {
        std::ofstream ef("EnergyPlot.dat", std::ios::app);
        ef << fmt_e12_4_fortran(time)
           << fmt_e12_4_fortran(ke + ie)
           << fmt_e12_4_fortran(ke)
           << fmt_e12_4_fortran(ie)
           << "\n";
    }
    {
        std::ofstream mf("MomentumPlot.dat", std::ios::app);
        mf << fmt_e12_4_fortran(time)
           << fmt_e12_4_fortran(momentum[0])
           << fmt_e12_4_fortran(momentum[1])
           << fmt_e12_4_fortran(momentum[2])
           << "\n";
    }
}

void DataOut::finalize() {
    std::cout << "Output complete. Total outputs: " << output_counter_ << std::endl;
    std::cout << "ParaView collection: " << pvd_filename_ << std::endl;
    std::cout << "Energy history: " << energy_filename_ << std::endl;
    std::cout << "Momentum history: " << momentum_filename_ << std::endl;
}

} // namespace mpm3d
