// Particle.cpp - Particle implementation
// Translated from Particle.f90

#include "Particle.hpp"

namespace mpm3d {

// Constructor implementation
Particle::Particle()
    : XX_({0, 0, 0}), Xp_({0, 0, 0}), Xo_({0, 0, 0}), VXp_({0, 0, 0}), FXp_({0, 0, 0}),
      XN_({0, 0, 0}), XXN_({0, 0, 0}), icell_(-1), centericell_(-1), inode_(-1),
      owner_rank_(0), body_id_(-1),
      mass_(0), VOL_(0), VOL0_(0), SM_(0), Seqv_(0), SDxx_(0), SDyy_(0), SDzz_(0),
      SDxy_(0), SDyz_(0), SDxz_(0), Spre_(0), PK_({0, 0, 0, 0, 0, 0, 0, 0, 0}),
      Fp_(identity_mat3()), sig_y_(0), epeff_(0), DMG_(0), failure_(false),
      celsius_t_(293.0), ie_(0), cp_(0), q_(0), LT_(0), SkipThis_(false) {
}

// Update deformation gradient
void Particle::updateDeformationGradient(const Mat3& velocity_gradient, Real dt) {
    // F_{n+1} = (I + dt * L) * F_n
    Mat3 I_plus_dt_L = identity_mat3();
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            I_plus_dt_L[i][j] += dt * velocity_gradient[i][j];
        }
    }
    
    Mat3 F_new;
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            F_new[i][j] = 0;
            for (int k = 0; k < 3; ++k) {
                F_new[i][j] += I_plus_dt_L[i][k] * Fp_[k][j];
            }
        }
    }
    
    Fp_ = F_new;
}

} // namespace mpm3d
