// MPMSolver.cpp - Main MPM solver coordination
// Translated from MPM3D.f90

#include "MPMSolver.hpp"
#include "DataIn.hpp"
#include "DataOut.hpp"
#include "UpdateStep.hpp"
#include "DomainDecomp.hpp"
#include <cstdlib>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <fstream>
#if defined(MPM3D_USE_MPI)
#include <mpi.h>
#endif

namespace mpm3d {

MPMSolver::MPMSolver()
    : algorithm_(AlgorithmType::MUSL),
      shape_func_type_(ShapeFunctionType::LINEAR), current_time_(0),
      final_time_(1.0), dt_(0.001), dt_scale_(0.8), output_interval_(0.01),
      report_interval_(0.1), step_(0), initialized_(false),
      quasi_static_(false), data_out_initialized_(false),
      mpi_rank_(0), mpi_size_(1), mpi_strict_(false) {}

void MPMSolver::initialize(const std::string &input_file) {
  std::cout << "=================================================="
            << std::endl;
  std::cout << "MPM3D-Faithful: Material Point Method Solver" << std::endl;
  std::cout << "=================================================="
            << std::endl;

  std::cout << "Initializing solver..." << std::endl;

  // Read input file
  std::cout << "Reading input file: " << input_file << std::endl;
  DataIn data_in;
  SimulationParameters params;

  if (!data_in.readInputFile(input_file, particles_, bodies_, grid_, materials_,
                             params)) {
    throw std::runtime_error("Failed to read input file");
  }

  // Apply parameters from input file
  params_ = params;
  algorithm_ = params.algorithm;
  shape_func_type_ = params.shape_function;
  final_time_ = params.end_time;
  dt_scale_ = params.dt_scale;
  output_interval_ = params.output_interval;
  report_interval_ = params.report_interval;
  quasi_static_ = params.quasi_static;

  // Derive job name from input filename (strip directories and extension)
  {
    std::string name = input_file;
    const auto slash = name.find_last_of("/\\");
    if (slash != std::string::npos)
      name = name.substr(slash + 1);
    const auto dot = name.find_last_of('.');
    if (dot != std::string::npos)
      name = name.substr(0, dot);
    job_name_ = name;
  }

  // Create shape function object
  shape_function_ = std::make_unique<ShapeFunction>(shape_func_type_);

  // Create constitution model
  constitution_ = std::make_unique<ConstitutionModel>();

  // Create update step coordinator
  update_step_ = std::make_unique<UpdateStep>();
  update_step_->initialize(particles_, bodies_, grid_, materials_,
                           *shape_function_, *constitution_);

  // Domain decomposition (MPI-ready). For now, we only compute and report it.
#if defined(MPM3D_USE_MPI)
  int mpi_initialized = 0;
  MPI_Initialized(&mpi_initialized);
  if (mpi_initialized) {
    MPI_Comm_rank(MPI_COMM_WORLD, &mpi_rank_);
    MPI_Comm_size(MPI_COMM_WORLD, &mpi_size_);
    const int nx = grid_.getNumCellsX();
    const int ny = grid_.getNumCellsY();
    const int nz = grid_.getNumCellsZ();
    const auto decomp = DomainDecomp::compute(mpi_rank_, mpi_size_, nx, ny, nz);
    grid_.setDecomposition(decomp, mpi_rank_, mpi_size_, 1);
    if (mpi_size_ > 1) {
      std::cout << "MPI domain decomposition (cells): "
                << DomainDecomp::toString(decomp) << std::endl;
    }
  }
#endif

  const char *strict_env = std::getenv("MPM3D_MPI_STRICT");
  mpi_strict_ = (strict_env && std::string(strict_env) != "0");

  // Set algorithm flags
  setAlgorithmFlags();

  // Initial particle migration for MPI decomposition
#if defined(MPM3D_USE_MPI)
  if (mpi_size_ > 1) {
    if (mpi_rank_ != 0) {
      particles_.clear();
      for (size_t b = 0; b < bodies_.size(); ++b) {
        bodies_[b].setParticleRange(0, 0);
      }
    }
    update_step_->migrateParticlesInitial();
  }
#endif
  
  // Initialize contact if enabled
  if (params_.contact_type != ContactType::NONE) {
    update_step_->setContact(true);
    update_step_->setContactType(params_.contact_type, 
                               params_.friction_coefficient);
  }

  initialized_ = true;
  std::cout << "Solver initialized successfully!" << std::endl;
}

void MPMSolver::setAlgorithmFlags() {
  // Set flags based on algorithm type
  bool usl = (algorithm_ == AlgorithmType::USL);
  bool usf = (algorithm_ == AlgorithmType::USF);
  bool musl = (algorithm_ == AlgorithmType::MUSL);
  bool tlmpm = (algorithm_ == AlgorithmType::TLMPM);

  update_step_->setUSL(usl);
  update_step_->setUSF(usf);
  update_step_->setMUSL(musl);
  update_step_->setTLMPM(tlmpm);

  // Set shape function flags
  bool gimp = (shape_func_type_ == ShapeFunctionType::GIMP);
  bool bspline = (shape_func_type_ == ShapeFunctionType::BSPLINE);
  bool sgmp = (shape_func_type_ == ShapeFunctionType::SGMP);

  update_step_->setGIMP(gimp);
  update_step_->setBspline(bspline);
  update_step_->setSGMP(sgmp);

  // Set time step parameters
  update_step_->setDT(dt_);
  update_step_->setDTScale(dt_scale_);
}

void MPMSolver::initializeParticleProperties() {
  // Initialize particle properties based on material
  // This is equivalent to Fortran's Initial() subroutine

  std::cout << "Initializing particle properties..." << std::endl;

  for (size_t b = 0; b < bodies_.size(); ++b) {
    const Body &body = bodies_[b];
    int mat_id = body.getMaterialID();
    const Material &mat = materials_.getMaterial(mat_id);

    int par_begin = body.getParticleBegin();
    int par_end = body.getParticleEnd();

    std::cout << "  Body " << b << ": mat=" << mat_id
              << " particles=" << par_begin << "-" << par_end << std::endl;

    for (int p = par_begin; p < par_end; ++p) {
      Particle &pt = particles_[p];

      // Set initial volume from mass and density
      Real vol = pt.getMass() / mat.getDensity();
      pt.setVolume(vol);
      pt.setVolumeInitial(vol);

      // Set yield stress
      pt.setYieldStress(mat.getYieldStress());

      // Set internal energy from EOS constants
      // Match Fortran: pt%ie = mat_list(m)%cEos(10) * pt%VOL
      // cEos(10) in Fortran (1-based) = eos_const[9] in C++ (0-based)
      const auto &eos_const = mat.getEosConstants();
      Real e0 = eos_const[9]; // Always use index 9 (cEos(10) in Fortran)
      Real ie_init = e0 * vol;
      pt.setInternalEnergy(ie_init);

      Real cp = 0.0;
      if (mat.getMaterialType() == MaterialType::ELASTIC ||
          mat.getMaterialType() == MaterialType::USER_MAT1) {
        Real E = mat.getYoungsModulus();
        Real nu = mat.getPoissonsRatio();
        Real rho = mat.getDensity();
        if (E > EPSILON && std::abs(1.0 - 2.0 * nu) > EPSILON) {
          cp =
              std::sqrt(E * (1.0 - nu) / ((1.0 + nu) * (1.0 - 2.0 * nu) * rho));
        }
      }
      pt.setSoundSpeed(cp);

      // NOTE: Do NOT set initial stress here!
      // The Fortran code only sets internal energy in Initial()
      // Stress is calculated later in the first constitution call
    }
  }

  std::cout << "Particle properties initialized." << std::endl;
}

void MPMSolver::solve() {
  if (!initialized_) {
    std::cerr << "Error: Solver not initialized!" << std::endl;
    return;
  }
#if defined(MPM3D_USE_MPI)
  if (mpi_strict_ && mpi_size_ > 1 && mpi_rank_ != 0) {
    return;
  }
#endif
  // Particle properties (volume, yield stress, IE, cp, LT) have already been
  // initialized by DataIn::readInputFile() using a direct port of the
  // Fortran Initial() subroutine. We must NOT re‑initialize them here or we
  // would overwrite the Fortran‑equivalent state and change the physics.
  //
  // Compute the initial time step (Fortran SetDT): based on material wave speed
  // only (no max particle velocity term).
  update_step_->setDTInitial();
  dt_ = update_step_->getDT();

  std::cout << "\nStarting simulation..." << std::endl;
  std::cout << "Algorithm: " << getAlgorithmName() << std::endl;
  std::cout << "Shape function: " << getShapeFunctionName() << std::endl;
  std::cout << "Final time: " << final_time_ << std::endl;
  std::cout << "Initial dt: " << dt_ << std::endl;
  std::cout << "\n";

  // Safety check.
  // In MPI decomposition runs, some non-root ranks can legitimately hold zero
  // particles and still must participate in collectives.
  if (particles_.size() == 0) {
#if defined(MPM3D_USE_MPI)
    if (!(mpi_size_ > 1 && !isRootRank())) {
      std::cerr << "ERROR: No particles in simulation!" << std::endl;
      return;
    }
#else
    std::cerr << "ERROR: No particles in simulation!" << std::endl;
    return;
#endif
  }

  Real next_output_time = output_interval_;
  Real next_report_time = report_interval_;

  while (true) {
    step_++;

    // Guard against non-progress / NaN time stepping (prevents infinite loop “hang”)
    if (!std::isfinite(dt_) || dt_ <= 0.0) {
      std::cerr << "Error: invalid dt detected; aborting to avoid infinite loop."
                << " step=" << step_ << " time=" << current_time_ << " dt=" << dt_
                << std::endl;
      break;
    }

    // Update time FIRST (matching Fortran line 73: CurrentTime = CurrentTime + DT)
    current_time_ += dt_;

    // Set current time for constitution (detonation check needs NEW time)
    update_step_->setCurrentTime(current_time_);

    // Take one time step using new time
    step();

    if (step_ <= 2 && isRootRank()) {
      std::ofstream pf(std::string("ParticleVel_step") + std::to_string(step_) + ".dat");
      pf.setf(std::ios::scientific);
      pf.precision(17);
      for (size_t p = 0; p < particles_.size(); ++p) {
        const Particle &pt = particles_[static_cast<int>(p)];
        const Vec3 v = pt.getVelocity();
        pf << p << " " << pt.getMass() << " " << v[0] << " " << v[1] << " "
           << v[2] << "\n";
      }
    }

    // Get updated dt (may change based on conditions)
    dt_ = update_step_->getDT();

    // Guard again after physics update (dt can be updated inside step())
    if (!std::isfinite(dt_) || dt_ <= 0.0) {
      std::cerr << "Error: invalid dt after step; aborting to avoid infinite loop."
                << " step=" << step_ << " time=" << current_time_ << " dt=" << dt_
                << std::endl;
      break;
    }

    // Report progress
    if (step_ == 1) {
      report();
    } else if (current_time_ >= next_report_time) {
      report();
      next_report_time += report_interval_;
    }

    // Output results
    if (isRootRank()) {
      if (current_time_ >= next_output_time) {
        output();
        next_output_time += output_interval_;
      }
    }

    // Check for completion
    if (quasi_static_) {
      // Quasi-static termination: check if KE/(KE+IE) < threshold AND time > min_time
      Real ke = update_step_->getKineticEnergy();
      Real ie = update_step_->getInternalEnergy();
      Real te = ke + ie;

      if (te > EPSILON) {
        Real ke_ratio = ke / te;
        const Real KE_THRESHOLD = 0.005; // 0.5% as in Fortran
        const Real MIN_TIME = 100.0;     // Minimum time as in Fortran

        if (current_time_ > final_time_ && ke_ratio < KE_THRESHOLD &&
            current_time_ > MIN_TIME) {
          std::cout << "\nQuasi-static equilibrium reached!" << std::endl;
          std::cout << "  KE ratio: " << ke_ratio << std::endl;
          std::cout << "  Current time: " << current_time_ << std::endl;
          std::cout << "  Final time: " << final_time_ << std::endl;
          break;
        }
      }
    }
    
    // Normal termination (matches Fortran: if (CurrentTime > EndTime) exit)
    if (current_time_ > final_time_) {
      std::cout << "\nSimulation completed!" << std::endl;
      break;
    }
  }

  // Final output
  if (isRootRank()) {
    output();
    finalReport();
  }
}

void MPMSolver::step() {
  // Execute one time step based on algorithm
  // Note: current_time has already been updated in solve()
  // Note: Each step function now calls updateDT() internally

  switch (algorithm_) {
  case AlgorithmType::USL:
    stepUSL();
    break;
  case AlgorithmType::USF:
    stepUSF();
    break;
  case AlgorithmType::MUSL:
    stepMUSL();
    break;
  case AlgorithmType::TLMPM:
    stepTLMPM();
    break;
  }

  // Get updated time step (already calculated inside step functions)
  dt_ = update_step_->getDT();
}

void MPMSolver::report() {
  // Fortran-style report at current_time_/step_
  Real ke = update_step_->getKineticEnergy();
  Real ie = update_step_->getInternalEnergy();
  Real te = ke + ie;
  Vec3 mom = update_step_->getMomentum();
  Real mom_mag = norm(mom);
  Real max_vp = update_step_->getLastMaxVp();
  Real dt_min = update_step_->getLastDtMin();
  Real max_vg = update_step_->getLastMaxVg();

  int he_total = 0;
  int he_burned = 0;
  Real he_pmax = 0.0;
  for (size_t b = 0; b < bodies_.size(); ++b) {
    const Body &body = bodies_[b];
    const Material &mat = materials_.getMaterial(body.getMaterialID());
    if (mat.getMaterialType() != MaterialType::HIGH_EXPLOSIVE)
      continue;
    for (int p = body.getParticleBegin(); p < body.getParticleEnd(); ++p) {
      const Particle &pt = particles_[p];
      ++he_total;
      if (current_time_ > pt.getLightingTime())
        ++he_burned;

      // Pressure is -meanStress (Fortran uses sm = -pnew)
      Real pres = -pt.getMeanStress();
      if (pres > he_pmax)
        he_pmax = pres;
    }
  }

#if defined(MPM3D_USE_MPI)
  if (mpi_size_ > 1) {
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (mpi_initialized) {
      int he_total_global = 0;
      int he_burned_global = 0;
      Real he_pmax_global = he_pmax;
      MPI_Allreduce(&he_total, &he_total_global, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
      MPI_Allreduce(&he_burned, &he_burned_global, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
      MPI_Allreduce(&he_pmax, &he_pmax_global, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
      he_total = he_total_global;
      he_burned = he_burned_global;
      he_pmax = he_pmax_global;
    }
  }
#endif

  if (!isRootRank()) {
    return;
  }

  const char *dbg_env = std::getenv("MPM3D_SGMP_DEBUG");
  const bool sgmp_dbg = (dbg_env && std::string(dbg_env) != "0");
  if (sgmp_dbg) {
    Real max_vp_abs = 0.0;
    Real pmax = -std::numeric_limits<Real>::infinity();
    Real pmin = std::numeric_limits<Real>::infinity();
    Real vol_min = std::numeric_limits<Real>::infinity();
    Real vol_max = 0.0;

    int track_pid = -1;
    Real track_lt = std::numeric_limits<Real>::infinity();

    int vmax_pid = -1;
    Real vmax_val = 0.0;

    int pmax_pid = -1;
    Real pmax_val = -std::numeric_limits<Real>::infinity();

    for (size_t b = 0; b < bodies_.size(); ++b) {
      const Body &body = bodies_[b];
      const Material &mat = materials_.getMaterial(body.getMaterialID());
      for (int p = body.getParticleBegin(); p < body.getParticleEnd(); ++p) {
        const Particle &pt = particles_[p];
        const Vec3 v = pt.getVelocity();
        const Real vp = std::max({std::abs(v[0]), std::abs(v[1]), std::abs(v[2])});
        if (vp > max_vp_abs)
          max_vp_abs = vp;

        if (vp > vmax_val) {
          vmax_val = vp;
          vmax_pid = p;
        }

        const Real pres = -pt.getMeanStress();
        if (pres > pmax)
          pmax = pres;
        if (pres < pmin)
          pmin = pres;

        if (pres > pmax_val) {
          pmax_val = pres;
          pmax_pid = p;
        }

        const Real vol = pt.getVolume();
        if (vol < vol_min)
          vol_min = vol;
        if (vol > vol_max)
          vol_max = vol;

        if (mat.getMaterialType() == MaterialType::HIGH_EXPLOSIVE) {
          const Real lt = pt.getLightingTime();
          if (lt < track_lt) {
            track_lt = lt;
            track_pid = p;
          }
        }
      }
    }

    std::cout << std::scientific << std::setprecision(6);
    std::cout << "SGMP_DBG step=" << step_ << " time=" << current_time_
              << " dt=" << dt_ << " max_vp_abs=" << max_vp_abs
              << " pmin=" << pmin << " pmax=" << pmax
              << " vol_min=" << vol_min << " vol_max=" << vol_max;

    if (track_pid >= 0 && track_pid < static_cast<int>(particles_.size())) {
      const Particle &tpt = particles_[track_pid];
      const Vec3 x = tpt.getPosition();
      const Vec3 v = tpt.getVelocity();
      const Real pres = -tpt.getMeanStress();
      const bool burned = (current_time_ > tpt.getLightingTime());
      std::cout << " track_pid=" << track_pid << " burned=" << (burned ? 1 : 0)
                << " LT=" << tpt.getLightingTime() << " X=" << x[0] << "," << x[1]
                << "," << x[2] << " V=" << v[0] << "," << v[1] << "," << v[2]
                << " VOL=" << tpt.getVolume() << " IE=" << tpt.getInternalEnergy()
                << " P=" << pres;
    }

    if (vmax_pid >= 0 && vmax_pid < static_cast<int>(particles_.size())) {
      const Particle &vpt = particles_[vmax_pid];
      const Vec3 x = vpt.getPosition();
      const Vec3 v = vpt.getVelocity();
      const Real pres = -vpt.getMeanStress();
      std::cout << " vmax_pid=" << vmax_pid << " vmax=" << vmax_val
                << " Xv=" << x[0] << "," << x[1] << "," << x[2]
                << " Vv=" << v[0] << "," << v[1] << "," << v[2]
                << " VOLv=" << vpt.getVolume() << " IEv=" << vpt.getInternalEnergy()
                << " Pv=" << pres;
    }

    if (pmax_pid >= 0 && pmax_pid < static_cast<int>(particles_.size())) {
      const Particle &ppt = particles_[pmax_pid];
      const Vec3 x = ppt.getPosition();
      const Vec3 v = ppt.getVelocity();
      std::cout << " pmax_pid=" << pmax_pid << " pmax_val=" << pmax_val
                << " Xpmax=" << x[0] << "," << x[1] << "," << x[2]
                << " Vpmax=" << v[0] << "," << v[1] << "," << v[2];
    }
    std::cout << std::endl;
    std::cout.unsetf(std::ios::scientific);
  }

  std::cout << std::scientific << std::setprecision(5);
  std::cout << "Step " << std::setw(8) << step_ << " | Time " << std::setw(11)
            << current_time_ << " | dt " << std::setw(11) << dt_ << " | KE "
            << std::setw(11) << ke << " | IE " << std::setw(11) << ie
            << " | Total " << std::setw(11) << te << " | |p| " << std::setw(11)
            << mom_mag << " | max_vp " << std::setw(11) << max_vp
            << " | max_vg " << std::setw(11) << max_vg
            << " | dt_min " << std::setw(11) << dt_min
            << " | HE(burn) " << he_burned << "/" << he_total
            << " | HE(pmax) " << std::setw(11) << he_pmax << std::endl;
  std::cout.unsetf(std::ios::scientific);
}

void MPMSolver::output() {
  if (!isRootRank()) {
    return;
  }
  if (!data_out_initialized_) {
    data_out_.initialize(job_name_, params_.write_tecplot, params_.write_paraview);
    data_out_initialized_ = true;
  }

  data_out_.writeOutput(current_time_, particles_, bodies_, grid_);
  std::cout << "Output at time " << current_time_ << std::endl;
}

void MPMSolver::stepUSL() {
  // Update Stress Last (USL) algorithm
  // Standard MPM: v(t) -> v(t+dt) -> x(t+dt) -> stress(t+dt)

  // 1. Map particle mass and momentum to grid (P2G)
  update_step_->gridMomentumInitial();

  // 2. Calculate internal forces from old stresses
  update_step_->gridMomentumUpdate();

  // 3. Integrate momentum (explicit)
  update_step_->integrateMomentum(step_);

  // 4. Apply boundary conditions (AFTER integration, matching Fortran)
  update_step_->applyBoundaryConditions();

  // 5. Map grid velocities to particles and update positions (G2P)
  update_step_->particlePositionUpdate(step_);

  // 6. Update particle stresses (hence "Update Stress Last")
  update_step_->particleStressUpdate();

  // 7. Calculate energy
  update_step_->calcEnergy();

  // 8. Update time step (matching Fortran order)
  update_step_->updateDT();

  // Write energy/momentum history after calcEnergy (matching Fortran OutCurve)
  writeEnergy();

  // 9. Optional: Stress smoothing
  // update_step_->smoothStressByGrid();

  // 10. Optional: Dynamic relaxation damping
  // update_step_->dynamicRelaxationDamping();
}

void MPMSolver::stepUSF() {
  // Update Stress First (USF) algorithm
  // v(t) -> stress(t+dt) -> v(t+dt) -> x(t+dt)

  // Match Fortran USF order (src/MPM3D.f90):
  // 1) GridMomentumInitial
  // 2) ApplyBoundaryConditions
  // 3) ParticleStressUpdate
  // 4) GridMomentumUpdate
  // 5) IntegrateMomentum
  // 6) ApplyBoundaryConditions
  // 7) ParticlePositionUpdate
  // 8) Energy
  // 9) UpdateDT

  update_step_->gridMomentumInitial();
  update_step_->applyBoundaryConditions();
  update_step_->particleStressUpdate();
  update_step_->gridMomentumUpdate();
  update_step_->integrateMomentum(step_);
  update_step_->applyBoundaryConditions();
  update_step_->particlePositionUpdate(step_);
  update_step_->calcEnergy();
  update_step_->updateDT();

  // Write energy/momentum history after calcEnergy (matching Fortran OutCurve)
  writeEnergy();
}

void MPMSolver::stepMUSL() {
  // Modified Update Stress Last (MUSL) algorithm
  // Fortran order: gridInit -> forces -> integrate -> position -> MUSL-remap ->
  // BC -> stress

  // 1. P2G: Map particle mass and momentum to grid
  // Note: resetGridData() is called internally in gridMomentumInitial()
  // to match Fortran behavior exactly
  update_step_->gridMomentumInitial();

  // 2. Calculate internal forces from stresses
  update_step_->gridMomentumUpdate();

  // 3. Integrate momentum equations on grid (NO BC yet!)
  update_step_->integrateMomentum(step_);

  // 4. G2P: Update particle positions and velocities
  update_step_->particlePositionUpdate(step_);

  // 5. MUSL: Recalculate grid momentum with updated particle positions
  update_step_->gridMomentumMUSL();

  // 6. Apply boundary conditions (AFTER GridMomentumMUSL in Fortran!)
  update_step_->applyBoundaryConditions();

  // 7. Update particle stresses (AFTER GridMomentumMUSL in Fortran!)
  update_step_->particleStressUpdate();

  // 8. Calculate energy
  update_step_->calcEnergy();

  // 9. Update time step (CRITICAL: Must be here, matching Fortran line 113)
  update_step_->updateDT();

  // Write energy/momentum history after calcEnergy (matching Fortran OutCurve)
  writeEnergy();
}

void MPMSolver::stepTLMPM() {
  // Total Lagrangian MPM
  // Uses reference configuration

  // First time: initialize grid mass (only once)
  static bool mass_initialized = false;
  if (!mass_initialized) {
    update_step_->gridMassInitial();
    mass_initialized = true;
  }

  // 1. P2G (TL version)
  update_step_->TLGridMomentumInitial();

  // 2. Forces (TL version)
  update_step_->TLGridMomentumUpdate();

  // 3. Integrate momentum
  update_step_->integrateMomentum(step_);

  // 4. Apply boundary conditions (AFTER integration)
  update_step_->applyBoundaryConditions();

  // 5. G2P
  update_step_->particlePositionUpdate(step_);

  // 6. Update stress (TL version)
  update_step_->TLParticleStressUpdate();

  // 7. Calculate energy
  update_step_->calcEnergy();

  // 8. Update time step
  update_step_->updateDT();

  // Write energy/momentum history after calcEnergy (matching Fortran OutCurve)
  writeEnergy();

  Real ke = update_step_->getKineticEnergy();
  Real ie = update_step_->getInternalEnergy();
  Real te = ke + ie;
  Vec3 mom = update_step_->getMomentum();
  Real mom_mag = norm(mom);
  Real max_vp = update_step_->getLastMaxVp();
  Real dt_min = update_step_->getLastDtMin();
  Real max_vg = update_step_->getLastMaxVg();

  int he_total = 0;
  int he_burned = 0;
  Real he_pmax = 0.0;
  for (size_t b = 0; b < bodies_.size(); ++b) {
    const Body &body = bodies_[b];
    const Material &mat = materials_.getMaterial(body.getMaterialID());
    if (mat.getMaterialType() != MaterialType::HIGH_EXPLOSIVE)
      continue;
    for (int p = body.getParticleBegin(); p < body.getParticleEnd(); ++p) {
      const Particle &pt = particles_[p];
      ++he_total;
      if (current_time_ > pt.getLightingTime())
        ++he_burned;

      // Pressure is -meanStress (Fortran uses sm = -pnew)
      Real pres = -pt.getMeanStress();
      if (pres > he_pmax)
        he_pmax = pres;
    }
  }

  std::cout << std::scientific << std::setprecision(5);
  std::cout << "Step " << std::setw(8) << step_ << " | Time " << std::setw(11)
            << current_time_ << " | dt " << std::setw(11) << dt_ << " | KE "
            << std::setw(11) << ke << " | IE " << std::setw(11) << ie
            << " | Total " << std::setw(11) << te << " | |p| " << std::setw(11)
            << mom_mag << " | max_vp " << std::setw(11) << max_vp
            << " | max_vg " << std::setw(11) << max_vg
            << " | dt_min " << std::setw(11) << dt_min
            << " | HE(burn) " << he_burned << "/" << he_total
            << " | HE(pmax) " << std::setw(11) << he_pmax << std::endl;

  std::cout.unsetf(std::ios::scientific);
}

void MPMSolver::writeEnergy() {
  if (!isRootRank()) {
    return;
  }
  if (!data_out_initialized_) {
    data_out_.initialize(job_name_, params_.write_tecplot, params_.write_paraview);
    data_out_.setWriteCurves(true);  // Enable EnergyPlot/MomentumPlot output
    if (params_.contact_type != ContactType::NONE) {
      data_out_.setContactEnabled(true);  // Enable contact output if contact is used
    }
    data_out_initialized_ = true;
  }

  // Update contact force for output
  data_out_.setContactForce(update_step_->getTotalContactForce());

  data_out_.writeEnergy(current_time_, update_step_->getKineticEnergy(),
                        update_step_->getInternalEnergy(),
                        update_step_->getMomentum());
}

void MPMSolver::finalReport() {
  if (!isRootRank()) {
    return;
  }
  std::cout << "\n=================================================="
            << std::endl;
  std::cout << "Simulation Summary" << std::endl;
  std::cout << "=================================================="
            << std::endl;
  std::cout << "Total steps: " << step_ << std::endl;
  std::cout << "Final time: " << current_time_ << std::endl;
  std::cout << "Algorithm: " << getAlgorithmName() << std::endl;
  std::cout << "Shape function: " << getShapeFunctionName() << std::endl;

  Real ke = update_step_->getKineticEnergy();
  Real ie = update_step_->getInternalEnergy();

  std::cout << "\nFinal energies:" << std::endl;
  std::cout << "  Kinetic: " << ke << std::endl;
  std::cout << "  Internal: " << ie << std::endl;
  std::cout << "  Total: " << (ke + ie) << std::endl;

  std::cout << "=================================================="
            << std::endl;
}

std::string MPMSolver::getAlgorithmName() const {
  switch (algorithm_) {
  case AlgorithmType::USL:
    return "USL (Update Stress Last)";
  case AlgorithmType::USF:
    return "USF (Update Stress First)";
  case AlgorithmType::MUSL:
    return "MUSL (Modified USL)";
  case AlgorithmType::TLMPM:
    return "TLMPM (Total Lagrangian)";
  default:
    return "Unknown";
  }
}

std::string MPMSolver::getShapeFunctionName() const {
  switch (shape_func_type_) {
  case ShapeFunctionType::LINEAR:
    return "Linear (8-node)";
  case ShapeFunctionType::GIMP:
    return "GIMP";
  case ShapeFunctionType::BSPLINE:
    return "B-spline (64-node)";
  case ShapeFunctionType::SGMP:
    return "SGMP (auxiliary grid)";
  default:
    return "Unknown";
  }
}

} // namespace mpm3d
