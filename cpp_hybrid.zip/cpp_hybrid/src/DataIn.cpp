// DataIn.cpp - Input file parser
// Translated from DataIn.f90

#include "DataIn.hpp"
#include "FFI.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <cctype>

namespace mpm3d {

DataIn::DataIn()
    : body_counter_(0), component_counter_(0), particle_counter_(0),
      current_line_(0) {
}


// Helper to convert Fortran scientific notation (d/D to e/E)
std::string convertFortranNumber(const std::string& str) {
    std::string result = str;
    
    // Only convert 'd' or 'D' when it's surrounded by digits (scientific notation)
    for (size_t i = 0; i < result.length(); ++i) {
        if (result[i] == 'd' || result[i] == 'D') {
            // Check if it's part of a number (has digit before and +/- or digit after)
            bool isNumber = false;
            if (i > 0 && i < result.length() - 1) {
                char before = result[i-1];
                char after = result[i+1];
                // Check if it's like "1.5d-3" or "2.0d+2" or "3d5"
                if (std::isdigit(before) && (std::isdigit(after) || after == '+' || after == '-')) {
                    isNumber = true;
                }
            }
            if (isNumber) {
                result[i] = 'e';
            }
        }
    }
    return result;
}
// Helper to trim and clean line
std::string cleanLine(std::string line) {
    // Remove comments
    size_t commentPos = line.find('!');
    if (commentPos != std::string::npos) {
        line = line.substr(0, commentPos);
    }
    
    // Trim whitespace
    line.erase(0, line.find_first_not_of(" \t\r\n"));
    line.erase(line.find_last_not_of(" \t\r\n") + 1);
    
    // Convert Fortran notation
    line = convertFortranNumber(line);
    
    return line;
}

// Forward declaration for initialization function
void initializeParticleProperties(ParticleList& particles,
                                  const BodyList& bodies,
                                  const MaterialList& materials);

bool DataIn::readInputFile(const std::string& filename,
                           ParticleList& particles,
                           BodyList& bodies,
                           Grid& grid,
                           MaterialList& materials,
                           SimulationParameters& params) {
    
    std::cout << "Reading input file: " << filename << std::endl;
    
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Cannot open input file " << filename << std::endl;
        return false;
    }
    
    // Storage for grid parameters
    struct GridParams {
        Real xmin = 0, xmax = 0;
        Real ymin = 0, ymax = 0;
        Real zmin = 0, zmax = 0;
        Real cellsize = 0;
        bool has_x = false, has_y = false, has_z = false, has_cell = false;
        std::array<int, 6> fixedbc = {0,0,0,0,0,0};
    } gridparams;
    
    // Storage for EOS data to apply after all materials are read
    struct EOSData {
        int mat_id;
        int eos_type;
        std::array<Real, 10> constants;
    };
    std::vector<EOSData> pending_eos;
    
    // Helper lambda to remove commas from string
    auto removeCommas = [](std::string& str) {
        str.erase(std::remove(str.begin(), str.end(), ','), str.end());
    };
    
    std::string line;
    bool have_pending_line = false;
    
    while (have_pending_line || std::getline(file, line)) {
        if (!have_pending_line) {
            current_line_++;
        }
        have_pending_line = false;
        
        line = cleanLine(line);
        
        if (line.empty()) continue;
        
        std::istringstream iss(line);
        std::string keyword;
        iss >> keyword;
        
        // Convert to lowercase for comparison
        std::transform(keyword.begin(), keyword.end(), keyword.begin(), ::tolower);
        
        // Title line - just store it
        if (keyword.find("mpm3d") != std::string::npos || keyword.find("***") != std::string::npos) {
            params.title = line;
            std::cout << "Title: " << params.title << std::endl;
            continue;
        }
        
        // Skip unknown keywords but print them
        std::vector<std::string> skip_keywords = {"curv"};
        if (std::find(skip_keywords.begin(), skip_keywords.end(), keyword) != skip_keywords.end()) {
            std::cout << "Skipping keyword: " << keyword << std::endl;
            continue;
        }
        
        // Parse keyword commands
        if (keyword == "nbco") {
            int nbco;
            iss >> nbco;
            std::cout << "Components: " << nbco << std::endl;
            // Grid will be initialized later with proper parameters
        }
        else if (keyword == "nbbo") {
            int nbbo;
            iss >> nbbo;
            bodies.reserve(nbbo);
            std::cout << "Bodies: " << nbbo << std::endl;
        }
        else if (keyword == "nbmp") {
            int nbmp;
            iss >> nbmp;
            particles.reserve(nbmp);
            std::cout << "Expected particles: " << nbmp << std::endl;
        }
        else if (keyword == "nmat") {
            int nmat;
            iss >> nmat;
            std::cout << "Materials: " << nmat << std::endl;
        }
        else if (keyword == "deto") {
            Real x, y, z;
            iss >> x >> y >> z;
            materials.addDetonationPoint(x, y, z);
            std::cout << "Detonation: (" << x << ", " << y << ", " << z << ")" << std::endl;
        }
        else if (keyword == "material") {
            // Material definition block - read all materials until next keyword
            int materials_read = 0;
            while (std::getline(file, line)) {
                current_line_++;
                line = cleanLine(line);
                if (line.empty()) continue;
                if (line.find("!") == 0) continue;

                // Material lines in some example inputs may contain commas; strip them
                removeCommas(line);
                
                // Check if this is a new keyword (not a material definition)
                std::string first_word;
                std::istringstream test_iss(line);
                test_iss >> first_word;
                std::transform(first_word.begin(), first_word.end(), first_word.begin(), ::tolower);
                
                // List of keywords that end the material section
                std::vector<std::string> keywords = {
                    "seos", "particle", "tecp", "spx", "spy", "spz", "dcell", 
                    "fixed", "dtscale", "endt", "musl", "jaum", "outtime", 
                    "rpttime", "endi", "end", "deto", "bulk", "cont"
                };
                
                bool is_keyword = false;
                for (const auto& kw : keywords) {
                    if (first_word == kw) {
                        is_keyword = true;
                        break;
                    }
                }
                
                if (is_keyword) {
                    // Put this line back for next iteration
                    have_pending_line = true;
                    break;
                }
                
                // Parse material definition: ID type params...
                std::istringstream mss(line);
                int mat_id;
                std::string mat_type;
                
                if (!(mss >> mat_id >> mat_type)) {
                    std::cerr << "Error parsing material line: " << line << std::endl;
                    continue;
                }
                
                std::transform(mat_type.begin(), mat_type.end(), mat_type.begin(), ::tolower);
                
                Material mat;
                mat.setID(mat_id);
                
                if (mat_type == "hiex") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::HIGH_EXPLOSIVE);
                    Real rho, D;
                    mss >> rho >> D;
                    mat.setDensity(rho);
                    mat.setDetonationVelocity(D);
                    std::cout << "  High Explosive: rho=" << rho << " D=" << D << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "sjc") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::SIMPLIFIED_JC);
                    Real rho, E, nu, Y0, B, n, C, epso;
                    mss >> rho >> E >> nu >> Y0 >> B >> n >> C >> epso;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    mat.setYieldStress(Y0);
                    mat.setJC_B(B);
                    mat.setJC_n(n);
                    mat.setJC_C(C);
                    mat.setJC_epso(epso);
                    std::cout << "  Johnson-Cook: rho=" << rho << " E=" << E << " Y0=" << Y0 << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "elas") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::ELASTIC);
                    Real rho, E, nu;
                    mss >> rho >> E >> nu;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    std::cout << "  Elastic: rho=" << rho << " E=" << E << " nu=" << nu << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "pla1") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::ELASTIC_PERFECT_PLASTIC);
                    Real rho, E, nu, Y0;
                    mss >> rho >> E >> nu >> Y0;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    mat.setYieldStress(Y0);
                    std::cout << "  Elastic-perfectly plastic: rho=" << rho << " E=" << E << " Y0=" << Y0 << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "pla2") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::ISOTROPIC_HARDENING);
                    Real rho, E, nu, Y0, TangMod;
                    mss >> rho >> E >> nu >> Y0 >> TangMod;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    mat.setYieldStress(Y0);
                    mat.setTangentModulus(TangMod);
                    std::cout << "  Isotropic hardening: rho=" << rho << " E=" << E << " Y0=" << Y0 << " TangMod=" << TangMod << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "john") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::JOHNSON_COOK);
                    Real rho, E, nu, Y0, B, n, C, m, Tmelt, Troom, epso;
                    mss >> rho >> E >> nu >> Y0 >> B >> n >> C >> m >> Tmelt >> Troom >> epso;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    mat.setYieldStress(Y0);
                    mat.setJC_B(B);
                    mat.setJC_n(n);
                    mat.setJC_C(C);
                    mat.setJC_m(m);
                    mat.setRoomTemperature(Troom);
                    mat.setMeltingTemperature(Tmelt);
                    mat.setJC_epso(epso);
                    std::cout << "  Johnson-Cook: rho=" << rho << " E=" << E << " Y0=" << Y0 << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "jcf") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::JC_FAILURE);
                    Real rho, E, nu, Y0, B, n, C, m, Tmelt, Troom, epso, epf;
                    mss >> rho >> E >> nu >> Y0 >> B >> n >> C >> m >> Tmelt >> Troom >> epso >> epf;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    mat.setYieldStress(Y0);
                    mat.setJC_B(B);
                    mat.setJC_n(n);
                    mat.setJC_C(C);
                    mat.setJC_m(m);
                    mat.setRoomTemperature(Troom);
                    mat.setMeltingTemperature(Tmelt);
                    mat.setJC_epso(epso);
                    mat.setPlasticStrainAtFailure(epf);
                    std::cout << "  Johnson-Cook with failure: rho=" << rho << " E=" << E << " Y0=" << Y0 << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "sjcf") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::SIMPLIFIED_JC_FAILURE);
                    Real rho, E, nu, Y0, B, n, C, epso, epf;
                    mss >> rho >> E >> nu >> Y0 >> B >> n >> C >> epso >> epf;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    mat.setYieldStress(Y0);
                    mat.setJC_B(B);
                    mat.setJC_n(n);
                    mat.setJC_C(C);
                    mat.setJC_epso(epso);
                    mat.setPlasticStrainAtFailure(epf);
                    std::cout << "  Simplified Johnson-Cook with failure: rho=" << rho << " E=" << E << " Y0=" << Y0 << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "null") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::FLUID);
                    Real rho, bulk, miu;
                    mss >> rho >> bulk >> miu;
                    mat.setDensity(rho);
                    mat.setBulkModulus(bulk);
                    mat.setDynamicViscosity(miu);
                    std::cout << "  Null (fluid): rho=" << rho << " bulk=" << bulk << " miu=" << miu << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "dpm") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::DRUCKER_PRAGER);
                    // Match Fortran SetMaterial() for 'dpm':
                    //   Density, Young, Poisson, q_fai, k_fai, q_psi, ten_f
                    Real rho, E, nu, q_fai, k_fai, q_psi, ten_f;
                    mss >> rho >> E >> nu >> q_fai >> k_fai >> q_psi >> ten_f;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    mat.setDP_q_fai(q_fai);
                    mat.setDP_k_fai(k_fai);
                    mat.setDP_q_psi(q_psi);
                    mat.setDP_ten_f(ten_f);
                    std::cout << "  Drucker-Prager: rho=" << rho << " E=" << E
                              << " nu=" << nu << " q_fai=" << q_fai
                              << " k_fai=" << k_fai << " q_psi=" << q_psi
                              << " ten_f=" << ten_f << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else if (mat_type == "neoh") {
                    std::cout << "Material " << mat_id << " type " << mat_type << std::endl;
                    mat.setMaterialType(MaterialType::USER_MAT1);
                    Real rho, E, nu;
                    mss >> rho >> E >> nu;
                    mat.setDensity(rho);
                    mat.setYoungsModulus(E);
                    mat.setPoissonsRatio(nu);
                    std::cout << "  NeoHookean: rho=" << rho << " E=" << E << " nu=" << nu << std::endl;
                    materials.addMaterial(mat);
                    materials_read++;
                }
                else {
                    std::cerr << "Unknown material type: " << mat_type << std::endl;
                }
            }
            std::cout << "Added " << materials_read << " materials" << std::endl;
        }
        else if (keyword == "seos") {
            int mat_id, eos_type;
            iss >> mat_id >> eos_type;

            std::cout << "EOS: mat=" << mat_id << " type=" << eos_type << std::endl;

            std::array<Real, 10> eos_10 = {0};

            if (eos_type == static_cast<int>(EosType::JWL)) {
                // Fortran SetEos JWL layout:
                //   cEos(1)=A, cEos(2)=B, cEos(3)=R1, cEos(4)=R2, cEos(5)=w, cEos(10)=E0
                Real A, B, R1, R2, W, E0;
                if (!(iss >> A >> B >> R1 >> R2 >> W >> E0)) {
                    std::cerr << "Error: Invalid JWL EOS line for material "
                              << mat_id << std::endl;
                } else {
                    eos_10[0] = A;
                    eos_10[1] = B;
                    eos_10[2] = R1;
                    eos_10[3] = R2;
                    eos_10[4] = W;
                    eos_10[9] = E0;
                }
            } else if (eos_type == static_cast<int>(EosType::GRUNEISEN)) {
                // Fortran SetEos Gruneisen layout:
                //   input: c0, lambda, gamma0, E0
                //   derived:
                //     C1 = rho * c0^2
                //     C2 = C1 * (2*lambda - 1)
                //     C3 = C1 * (lambda - 1) * (3*lambda - 1)
                //     C4 = rho * gamma0
                //     C5 = gamma0
                //     cEos(10) = E0
                Real c0, lambda, gamma0, E0;
                if (!(iss >> c0 >> lambda >> gamma0 >> E0)) {
                    std::cerr << "Error: Invalid Gruneisen EOS line for material "
                              << mat_id << std::endl;
                } else {
                    const Material &mat = materials.getMaterial(mat_id);
                    Real rho = mat.getDensity();
                    Real C1 = rho * c0 * c0;
                    eos_10[0] = C1;
                    eos_10[1] = C1 * (2.0 * lambda - 1.0);
                    eos_10[2] = C1 * (lambda - 1.0) * (3.0 * lambda - 1.0);
                    eos_10[3] = rho * gamma0;
                    eos_10[4] = gamma0;
                    eos_10[9] = E0;
                }
            } else if (eos_type == static_cast<int>(EosType::LINEAR_POLYNOMIAL)) {
                // Fortran linear polynomial:
                //   cEos(1..7) = C0..C6, cEos(10)=E0
                Real C0, C1, C2, C3, C4, C5, C6, E0;
                if (!(iss >> C0 >> C1 >> C2 >> C3 >> C4 >> C5 >> C6 >> E0)) {
                    std::cerr << "Error: Invalid linear EOS line for material "
                              << mat_id << std::endl;
                } else {
                    eos_10[0] = C0;
                    eos_10[1] = C1;
                    eos_10[2] = C2;
                    eos_10[3] = C3;
                    eos_10[4] = C4;
                    eos_10[5] = C5;
                    eos_10[6] = C6;
                    eos_10[9] = E0;
                }
            } else {
                // Generic case: read up to first 6 constants verbatim
                int count = 0;
                while (count < 6 && iss >> eos_10[count]) {
                    count++;
                }
            }

            // Store for later application (after all materials are read)
            EOSData edata;
            edata.mat_id = mat_id;
            edata.eos_type = eos_type;
            edata.constants = eos_10;
            pending_eos.push_back(edata);
        }
        else if (keyword == "tecp") {
            params.write_tecplot = true;
            std::cout << "TecPlot output enabled" << std::endl;
        }
        else if (keyword == "para") {
            params.write_paraview = true;
            std::cout << "ParaView output enabled" << std::endl;
        }
        else if (keyword == "spx") {
            iss >> gridparams.xmin >> gridparams.xmax;
            gridparams.has_x = true;
            std::cout << "X span: " << gridparams.xmin << " to " << gridparams.xmax << std::endl;
        }
        else if (keyword == "spy") {
            iss >> gridparams.ymin >> gridparams.ymax;
            gridparams.has_y = true;
            std::cout << "Y span: " << gridparams.ymin << " to " << gridparams.ymax << std::endl;
        }
        else if (keyword == "spz") {
            iss >> gridparams.zmin >> gridparams.zmax;
            gridparams.has_z = true;
            std::cout << "Z span: " << gridparams.zmin << " to " << gridparams.zmax << std::endl;
        }
        else if (keyword == "dcell") {
            iss >> gridparams.cellsize;
            gridparams.has_cell = true;
            std::cout << "Cell size: " << gridparams.cellsize << " (has_cell=" << gridparams.has_cell << ")" << std::endl;
        }
        else if (keyword == "fixed") {
            for (int i = 0; i < 6; i++) {
                iss >> gridparams.fixedbc[i];
            }
            std::cout << "Fixed BC: [" << gridparams.fixedbc[0] << "," << gridparams.fixedbc[1] << ","
                      << gridparams.fixedbc[2] << "," << gridparams.fixedbc[3] << ","
                      << gridparams.fixedbc[4] << "," << gridparams.fixedbc[5] << "]" << std::endl;
        }
        else if (keyword == "dtscale" || keyword == "dtsc") {
            iss >> params.dt_scale;
            std::cout << "DT scale: " << params.dt_scale << std::endl;
        }
        else if (keyword == "endtime" || keyword == "endt") {
            iss >> params.end_time;
            std::cout << "End time: " << params.end_time << std::endl;
        }
        else if (keyword == "musl") {
            params.algorithm = AlgorithmType::MUSL;
            std::string onoff;
            if (iss >> onoff) {
                std::transform(onoff.begin(), onoff.end(), onoff.begin(), ::tolower);
            }
            std::cout << "Using MUSL algorithm" << std::endl;
        }
        else if (keyword == "usl") {
            params.algorithm = AlgorithmType::USL;
            std::cout << "Using USL algorithm" << std::endl;
        }
        else if (keyword == "usf") {
            params.algorithm = AlgorithmType::USF;
            std::cout << "Using USF algorithm" << std::endl;
        }
        else if (keyword == "jaum") {
            std::string onoff;
            iss >> onoff;
            std::transform(onoff.begin(), onoff.end(), onoff.begin(), ::tolower);
            bool use_jaum = (onoff == "on" || onoff == "true");
            materials.setUseJaumannRate(use_jaum);
            std::cout << "Jaumann rate: " << onoff << std::endl;
        }
        else if (keyword == "bulk") {
            Real bq1, bq2;
            iss >> bq1 >> bq2;
            materials.setBQ1(bq1);
            materials.setBQ2(bq2);
        }
        else if (keyword == "bimp" || keyword == "bspline") {
            params.shape_function = ShapeFunctionType::BSPLINE;
        }
        else if (keyword == "gimp") {
            params.shape_function = ShapeFunctionType::GIMP;
            std::cout << "Using GIMP shape functions" << std::endl;
        }
        else if (keyword == "sgmp") {
            params.shape_function = ShapeFunctionType::SGMP;
            std::cout << "Using SGMP (auxiliary grid)" << std::endl;
        }
        else if (keyword == "outtime" || keyword == "outt") {
            iss >> params.output_interval;
            std::cout << "Output interval: " << params.output_interval << std::endl;
        }
        else if (keyword == "rpttime" || keyword == "rptt") {
            iss >> params.report_interval;
            std::cout << "Report interval: " << params.report_interval << std::endl;
        }
        else if (keyword == "pt2d") {
            // 2D plotting parameters (matches Fortran case 24)
            Real x1, x2;
            iss >> x1 >> x2;
            params.plot2d_enabled = true;
            params.plot2d_x1 = x1;
            params.plot2d_x2 = x2;
            std::cout << "2D plotting enabled: x1=" << x1 << " x2=" << x2 << std::endl;
        }
        else if (keyword == "outr") {
            // Output result variables (matches Fortran case 21)
            std::string var_name;
            while (iss >> var_name) {
                params.output_variables.push_back(var_name);
                std::cout << "Output variable: " << var_name << std::endl;
            }
        }
        else if (keyword == "load") {
            // Fortran-compatible load block (SetLoad):
            //   load
            //   part <pid> <fx> <fy> <fz>
            //   body <bid> <fx> <fy> <fz>
            //   grav <bid> <gx> <gy> <gz>
            //   endl
            while (std::getline(file, line)) {
                current_line_++;
                line = cleanLine(line);
                if (line.empty() || line.find("!") == 0) {
                    continue;
                }

                removeCommas(line);
                std::istringstream lss(line);
                std::string mode;
                lss >> mode;
                std::transform(mode.begin(), mode.end(), mode.begin(), ::tolower);

                if (mode == "endl" || mode == "end") {
                    break;
                }

                if (mode == "part") {
                    int pid = 0;
                    Real fx = 0.0, fy = 0.0, fz = 0.0;
                    if (!(lss >> pid >> fx >> fy >> fz)) {
                        std::cerr << "Warning: Could not parse load part line: " << line << std::endl;
                        continue;
                    }
                    // Fortran particles are 1-based.
                    int pidx = pid - 1;
                    if (pidx < 0 || pidx >= static_cast<int>(particles.size())) {
                        std::cerr << "Warning: load part id out of range: " << pid << std::endl;
                        continue;
                    }
                    particles[pidx].setExternalForce({fx, fy, fz});
                } else if (mode == "body") {
                    int bid = 0;
                    Real fx = 0.0, fy = 0.0, fz = 0.0;
                    if (!(lss >> bid >> fx >> fy >> fz)) {
                        std::cerr << "Warning: Could not parse load body line: " << line << std::endl;
                        continue;
                    }
                    int bidx = bid - 1;
                    if (bidx < 0 || bidx >= static_cast<int>(bodies.size())) {
                        std::cerr << "Warning: load body id out of range: " << bid << std::endl;
                        continue;
                    }
                    const Body &body = bodies[bidx];
                    for (int p = body.getParticleBegin(); p < body.getParticleEnd(); ++p) {
                        if (p >= 0 && p < static_cast<int>(particles.size())) {
                            particles[p].setExternalForce({fx, fy, fz});
                        }
                    }
                } else if (mode == "grav") {
                    int bid = 0;
                    Real gx = 0.0, gy = 0.0, gz = 0.0;
                    if (!(lss >> bid >> gx >> gy >> gz)) {
                        std::cerr << "Warning: Could not parse load grav line: " << line << std::endl;
                        continue;
                    }
                    int bidx = bid - 1;
                    if (bidx < 0 || bidx >= static_cast<int>(bodies.size())) {
                        std::cerr << "Warning: load grav body id out of range: " << bid << std::endl;
                        continue;
                    }
                    bodies[bidx].setGravity({gx, gy, gz});
                } else {
                    std::cout << "Skipping unsupported load mode: " << mode << std::endl;
                }
            }
        }
        else if (keyword == "cont" || keyword == "contact") {
            // Contact block on a single line: type friction normbody
            int type = 0;
            Real fric = 0.0;
            int normbody = 0;
            iss >> type >> fric >> normbody;
            params.contact_type = static_cast<ContactType>(type);
            params.friction_coefficient = fric;
            params.contact_normbody = normbody;
            std::cout << "Contact enabled: type=" << type << " friction=" << fric
                      << " normbody=" << normbody << std::endl;
        }
        else if (keyword == "velo") {
            // Velocity block (matches Fortran SetVelocity)
            // Example (Taylor.mpm):
            //   velo
            //   body   1    0.0 0.0 -190.0
            //   endv
            while (std::getline(file, line)) {
                current_line_++;
                line = cleanLine(line);
                if (line.empty() || line.find("!") == 0) {
                    continue;
                }

                std::string key;
                {
                    std::istringstream vss(line);
                    vss >> key;
                    std::transform(key.begin(), key.end(), key.begin(), ::tolower);
                }

                if (key == "endv" || key == "end") {
                    break;
                }

                removeCommas(line);
                std::istringstream vss(line);
                std::string mode;
                vss >> mode;
                std::transform(mode.begin(), mode.end(), mode.begin(), ::tolower);

                if (mode == "body") {
                    int body_id = 0;
                    Real vx = 0.0, vy = 0.0, vz = 0.0;
                    if (!(vss >> body_id >> vx >> vy >> vz)) {
                        std::cerr << "Warning: Could not parse velo body line: " << line
                                  << std::endl;
                        continue;
                    }
                    // Fortran bodies are 1-based; C++ vector is 0-based
                    int bidx = body_id - 1;
                    if (bidx < 0 || bidx >= static_cast<int>(bodies.size())) {
                        std::cerr << "Warning: velo body id out of range: " << body_id
                                  << std::endl;
                        continue;
                    }

                    Body &body = bodies[bidx];
                    for (int p = body.getParticleBegin(); p < body.getParticleEnd(); ++p) {
                        particles[p].setVelocity({vx, vy, vz});
                    }
                } else {
                    // Other modes (e.g. by particle/node) can be added if needed
                    std::cout << "Skipping unsupported velo mode: " << mode << std::endl;
                }
            }
        }
        else if (keyword == "particle") {
            // Particle block definition: "Particle block <comID>"
            // Next line has: matID density dp ox oy oz nx ny nz
            
            // Read the rest of this line to get "block" and comID
            std::string block_word;
            int comID = 1;
            iss >> block_word >> comID;
            
            std::transform(block_word.begin(), block_word.end(), block_word.begin(), ::tolower);

            if (block_word == "point") {
                // Support both:
                //   Particle point <count>
                //   Particle point <comID> <count>
                // If two integers are present, treat the second as count.
                int count = 0;
                if (!(iss >> count)) {
                    std::cerr << "Error: Invalid Particle point header" << std::endl;
                    continue;
                }

                // Heuristic: if there is another integer, it's the count, and the
                // previously read value was actually comID.
                int maybe_count = 0;
                if (iss >> maybe_count) {
                    comID = count;
                    count = maybe_count;
                }
                if (count <= 0) {
                    std::cerr << "Error: Invalid Particle point count" << std::endl;
                    continue;
                }

                int start_id = particles.size();
                int first_mat_id = -1;

                int read_count = 0;
                while (read_count < count && std::getline(file, line)) {
                    current_line_++;
                    line = cleanLine(line);
                    if (line.empty() || line.find("!") == 0) continue;

                    // remove commas if any (helper exists earlier in readInputFile)
                    removeCommas(line);

                    std::istringstream pss(line);
                    int pid = 0;
                    int mat_id = 0;
                    Real mp = 0.0;
                    Real x = 0.0, y = 0.0, z = 0.0;

                    // Taylor format: ID mat Mp x y z
                    if (!(pss >> pid >> mat_id >> mp >> x >> y >> z)) {
                        std::cerr << "Warning: Could not parse Particle point line: " << line << std::endl;
                        continue;
                    }

                    if (first_mat_id < 0) first_mat_id = mat_id;

                    Particle p;
                    Vec3 pos = {x, y, z};
                    p.setPosition(pos);
                    p.setPositionPrev(pos);
                    p.setPositionInitial(pos);
                    p.setMass(mp);
                    particles.push_back(p);

                    read_count++;
                }

                int end_id = particles.size();

                if (read_count != count) {
                    std::cerr << "Warning: Particle point expected " << count
                            << " but read " << read_count << std::endl;
                }

                Body body;
                body.setMaterialID(first_mat_id > 0 ? first_mat_id : 1);
                body.setComponentID(comID);
                body.setParticleRange(start_id, end_id);
                bodies.push_back(body);
                body_counter_++;

                continue; // IMPORTANT: don't fall through to block parsing
            }
            else if (block_word == "sphere") {
                // Particle sphere <comID>
                // Next line: matID density dp ox oy oz nRadius
                std::cout << "Particle sphere " << comID << std::endl;
                
                // Read the next line with sphere data
                if (!std::getline(file, line)) {
                    std::cerr << "Error: Expected sphere data after 'Particle sphere'" << std::endl;
                    continue;
                }
                current_line_++;
                line = cleanLine(line);
                
                // Skip comments and empty lines
                while (line.empty() || line.find("!") == 0) {
                    if (!std::getline(file, line)) break;
                    current_line_++;
                    line = cleanLine(line);
                }
                
                if (line.empty()) {
                    std::cerr << "Error: No sphere data found" << std::endl;
                    continue;
                }
                
                // Parse sphere data: matID density dp ox oy oz nRadius
                std::istringstream sss(line);
                int mat_id;
                Real density, dp;
                Vec3 origin;
                Real n_radius;
                
                sss >> mat_id >> density >> dp >> origin[0] >> origin[1] >> origin[2] >> n_radius;
                
                Real pmass = density * dp * dp * dp;
                Real radius = n_radius * dp;
                Real radius2 = radius * radius;
                
                int start_id = particles.size();
                
                // Create particles in sphere pattern (matching Fortran logic)
                int particles_created = 0;
                for (int ix = 1 - static_cast<int>(n_radius); ix <= static_cast<int>(n_radius); ++ix) {
                    for (int iy = 1 - static_cast<int>(n_radius); iy <= static_cast<int>(n_radius); ++iy) {
                        for (int iz = 1 - static_cast<int>(n_radius); iz <= static_cast<int>(n_radius); ++iz) {
                            Real tx = (ix - 1) * dp + origin[0] + 0.5 * dp;
                            Real ty = (iy - 1) * dp + origin[1] + 0.5 * dp;
                            Real tz = (iz - 1) * dp + origin[2] + 0.5 * dp;
                            
                            Real dist_sq = (tx - origin[0]) * (tx - origin[0]) + 
                                          (ty - origin[1]) * (ty - origin[1]) + 
                                          (tz - origin[2]) * (tz - origin[2]);
                            
                            if (dist_sq < radius2) {
                                particles_created++;
                                Particle p;
                                Vec3 pos = {tx, ty, tz};
                                p.setPosition(pos);
                                p.setPositionPrev(pos);
                                p.setPositionInitial(pos);
                                p.setMass(pmass);
                                
                                // Set volume based on mass and density
                                Real vol = pmass / density;
                                p.setVolume(vol);
                                p.setVolumeInitial(vol);
                                
                                particles.push_back(p);
                            }
                        }
                    }
                }
                
                int end_id = particles.size();
                
                // Create body
                Body body;
                body.setMaterialID(mat_id);
                body.setComponentID(comID);
                body.setParticleRange(start_id, end_id);
                bodies.push_back(body);
                body_counter_++;
                
                continue; // IMPORTANT: don't fall through to block parsing
            }

            std::cout << "Particle block " << comID << std::endl;
            
            // Read the next line with actual particle data
            if (!std::getline(file, line)) {
                std::cerr << "Error: Expected particle data after 'Particle block'" << std::endl;
                continue;
            }
            current_line_++;
            line = cleanLine(line);
            
            // Skip comments and empty lines
            while (line.empty() || line.find("!") == 0) {
                if (!std::getline(file, line)) break;
                current_line_++;
                line = cleanLine(line);
            }
            
            if (line.empty()) {
                std::cerr << "Error: No particle data found" << std::endl;
                continue;
            }
            
            // Parse particle data: matID density dp ox oy oz nx ny nz
            // Note: Input may have commas in coordinates like "0.0,0.0, 0.0,"
            std::istringstream pss(line);
            int mat_id;
            Real density, dp;
            Vec3 origin;
            int nx, ny, nz;
            
            // Read with comma handling
            char comma;
            pss >> mat_id >> density >> dp;
            
            // Read coordinates - handle optional commas
            pss >> origin[0];
            if (pss.peek() == ',') pss >> comma;
            pss >> origin[1];
            if (pss.peek() == ',') pss >> comma;
            pss >> origin[2];
            if (pss.peek() == ',') pss >> comma;
            
            pss >> nx >> ny >> nz;
            
            // Adjust origin to first particle center (Fortran does this)
            origin[0] += dp * 0.5;
            origin[1] += dp * 0.5;
            origin[2] += dp * 0.5;
            
            Real pmass = density * dp * dp * dp;
            
            int start_id = particles.size();
            
            for (int iz = 0; iz < nz; ++iz) {
                for (int iy = 0; iy < ny; ++iy) {
                    for (int ix = 0; ix < nx; ++ix) {
                        Particle p;
                        Vec3 pos = {
                            origin[0] + ix * dp,
                            origin[1] + iy * dp,
                            origin[2] + iz * dp
                        };
                        p.setPosition(pos);
                        p.setPositionPrev(pos);
                        p.setPositionInitial(pos);
                        p.setMass(pmass);
                        
                        // Set volume based on mass and density
                        Real vol = pmass / density;
                        p.setVolume(vol);
                        p.setVolumeInitial(vol);
                        
                        particles.push_back(p);
                    }
                }
            }
            
            int end_id = particles.size();
            
            // Create body
            Body body;
            body.setMaterialID(mat_id);
            body.setComponentID(comID);
            body.setParticleRange(start_id, end_id);
            bodies.push_back(body);
            body_counter_++;
        }
        else if (keyword == "endi" || keyword == "end") {
            std::cout << "End of input" << std::endl;
            break;
        }
    }
    
    file.close();
    
    // Apply pending EOS data now that all materials are defined
    for (const auto& edata : pending_eos) {
        try {
            Material& mat = materials.getMaterial(edata.mat_id);
            mat.setEosType(static_cast<EosType>(edata.eos_type));
            mat.setEosConstants(edata.constants);
            std::cout << "Applied EOS to material " << edata.mat_id 
                      << " type=" << edata.eos_type 
                      << " E0=" << edata.constants[9] << std::endl;
        } catch (const std::exception& e) {
            std::cerr << "Warning: Could not apply EOS to material " << edata.mat_id << ": " << e.what() << std::endl;
        }
    }
    
    // Initialize grid if we have all parameters
    if (gridparams.has_x && gridparams.has_y && gridparams.has_z && gridparams.has_cell) {
        grid.initialize(
            {gridparams.xmin, gridparams.xmax},
            {gridparams.ymin, gridparams.ymax},
            {gridparams.zmin, gridparams.zmax},
            gridparams.cellsize,
            1  // num_components, can be updated
        );
        // Fortran SetGridData applies boundary constraints on 2 layers of nodes
        // when using Bspline/GIMP/SGMP due to the wider shape function support.
        bool extended_bc = (params.shape_function == ShapeFunctionType::BSPLINE ||
                            params.shape_function == ShapeFunctionType::GIMP ||
                            params.shape_function == ShapeFunctionType::SGMP);
        grid.setExtendedBoundaryLayers(extended_bc);
        grid.setFixedBoundary(gridparams.fixedbc);
    }
    
    std::cout << "\n===============================================" << std::endl;
    std::cout << "Input file read successfully!" << std::endl;
    std::cout << "  Particles: " << particles.size() << std::endl;
    std::cout << "  Bodies: " << bodies.size() << std::endl;
    std::cout << "  Materials: " << materials.getNumMaterials() << std::endl;
    std::cout << "===============================================\n" << std::endl;
    
    if (particles.size() == 0) {
        std::cerr << "ERROR: No particles generated!" << std::endl;
        return false;
    }
    
    if (params.dt_scale <= 0) {
        std::cout << "Warning: DT scale not set, using default 0.8" << std::endl;
        params.dt_scale = 0.8;
    }
    
    // Assign body ids to particles (0-based index in bodies list)
    for (size_t b = 0; b < bodies.size(); ++b) {
        Body& body = bodies[b];
        int par_begin = body.getParticleBegin();
        int par_end = body.getParticleEnd();
        for (int p = par_begin; p < par_end; ++p) {
            particles[p].setBodyId(static_cast<int>(b));
        }
    }

    // *** CRITICAL: Initialize particle properties from materials ***
    // This corresponds to the Initial() subroutine in Fortran DataIn.f90
    initializeParticleProperties(particles, bodies, materials);
    
    return true;
}

// ============================================================================
// Initialize Particle Properties
// This corresponds to the Initial() subroutine in Fortran DataIn.f90
// ============================================================================
void initializeParticleProperties(ParticleList& particles,
                                  const BodyList& bodies,
                                  const MaterialList& materials) {
    std::cout << "Initializing particle properties..." << std::endl;
    
    for (size_t b = 0; b < bodies.size(); ++b) {
        const Body& body = bodies[b];
        int mat_id = body.getMaterialID();
        int par_begin = body.getParticleBegin();
        int par_end = body.getParticleEnd();
        
        const Material& mat = materials.getMaterial(mat_id);
        MaterialType mtype = mat.getMaterialType();
        
        std::cout << "  Body " << b << ": mat=" << mat_id 
                  << " particles=" << par_begin << "-" << par_end << std::endl;
        
        // Skip rigid bodies (type 12 in Fortran)
        if (static_cast<int>(mtype) == 12) continue;
        
        for (int i = par_begin; i < par_end; ++i) {
            Particle& pt = particles[i];
            
            // Volume = mass / density
            Real vol = pt.getMass() / mat.getDensity();
            pt.setVolume(vol);
            pt.setVolumeInitial(vol);
            
            // Yield stress
            pt.setYieldStress(mat.getYieldStress());
            
            // Internal energy = E0 * VOL
            // Match Fortran: pt%ie = mat_list(m)%cEos(10) * pt%VOL
            // cEos(10) in Fortran (1-based) = eos_const[9] in C++ (0-based)
            Real E0 = mat.getEosConstants()[9];
            Real ie = E0 * vol;
            pt.setInternalEnergy(ie);
            
            // Sound speed for elastic and neohookean materials
            if (mtype == MaterialType::ELASTIC || mtype == MaterialType::USER_MAT1) {
                Real E = mat.getYoungsModulus();
                Real nu = mat.getPoissonsRatio();
                Real rho = mat.getDensity();
                Real cp = std::sqrt(E * (1.0 - nu) / ((1.0 + nu) * (1.0 - 2.0 * nu) * rho));
                pt.setSoundSpeed(cp);
            }
            
            // Sound speed for null material (water)
            if (mtype == MaterialType::USER_MAT2) {  // Null material
                pt.setSoundSpeed(mat.getWaveSpeed());
            }
            
            // Lighting time (LT) is only used by high explosives (hiex)
            // For non-explosives, keep LT as a large number.
            Real LT = 1.0e7;
            if (mtype == MaterialType::HIGH_EXPLOSIVE) {
                int nDeto = materials.getNumDetonationPoints();
                for (int j = 0; j < nDeto; ++j) {
                    Vec3 deto = materials.getDetonationPoint(j);
                    Vec3 pos = pt.getPositionPrev();
                    Real dist = std::sqrt((pos[0] - deto[0]) * (pos[0] - deto[0]) +
                                         (pos[1] - deto[1]) * (pos[1] - deto[1]) +
                                         (pos[2] - deto[2]) * (pos[2] - deto[2]));
                    Real dvel = mat.getDetonationVelocity();
                    if (dvel > EPSILON) {
                        Real time = dist / dvel;
                        LT = std::min(LT, time);
                    }
                }
            }
            pt.setLightingTime(LT);
        }
    }
    
    std::cout << "Particle properties initialized." << std::endl;
}

std::string DataIn::extractKeyword(const std::string& line) {
    // Extract first word as keyword
    std::istringstream iss(line);
    std::string keyword;
    iss >> keyword;
    
    // Convert to lowercase
    std::transform(keyword.begin(), keyword.end(), keyword.begin(), ::tolower);
    
    return keyword;
}

bool DataIn::processKeyword(const std::string& keyword,
                            std::ifstream& file,
                            ParticleList& particles,
                            BodyList& bodies,
                            Grid& grid,
                            MaterialList& materials,
                            SimulationParameters& params) {
    
    // 43 keywords from Fortran version
    if (keyword == "endi" || keyword == "end") {
        return true;  // End of input
    }
    else if (keyword == "mpm3") {
        return readTitle(file, params);
    }
    else if (keyword == "nbmp") {
        return readNumParticles(file, particles);
    }
    else if (keyword == "endt") {
        return readEndTime(file, params);
    }
    else if (keyword == "grid") {
        return readGrid(file, grid);
    }
    else if (keyword == "spx") {
        return readSpanX(file, grid);
    }
    else if (keyword == "spy") {
        return readSpanY(file, grid);
    }
    else if (keyword == "spz") {
        return readSpanZ(file, grid);
    }
    else if (keyword == "dcell") {
        return readCellSize(file, grid);
    }
    else if (keyword == "dtsc") {
        return readDTScale(file, params);
    }
    else if (keyword == "outt") {
        return readOutputTime(file, params);
    }
    else if (keyword == "rptt") {
        return readReportTime(file, params);
    }
    else if (keyword == "fixe") {
        return readFixedBoundaries(file, grid);
    }
    else if (keyword == "nmat") {
        return readNumMaterials(file, materials);
    }
    else if (keyword == "mate") {
        return readMaterial(file, materials);
    }
    else if (keyword == "part") {
        return readParticles(file, particles, bodies);
    }
    else if (keyword == "musl") {
        params.algorithm = AlgorithmType::MUSL;
        std::cout << "Using MUSL algorithm" << std::endl;
        return true;
    }
    else if (keyword == "usl") {
        params.algorithm = AlgorithmType::USL;
        std::cout << "Using USL algorithm" << std::endl;
        return true;
    }
    else if (keyword == "usf") {
        params.algorithm = AlgorithmType::USF;
        std::cout << "Using USF algorithm" << std::endl;
        return true;
    }
    else if (keyword == "tlmp") {
        params.algorithm = AlgorithmType::TLMPM;
        std::cout << "Using TLMPM algorithm" << std::endl;
        return true;
    }
    else if (keyword == "gimp") {
        params.shape_function = ShapeFunctionType::GIMP;
        std::cout << "Using GIMP shape functions" << std::endl;
        return true;
    }
    else if (keyword == "bimp" || keyword == "bspline") {
        params.shape_function = ShapeFunctionType::BSPLINE;
        std::cout << "Using B-spline shape functions" << std::endl;
        return true;
    }
    else if (keyword == "sgmp") {
        params.shape_function = ShapeFunctionType::SGMP;
        std::cout << "Using SGMP (auxiliary grid)" << std::endl;
        return true;
    }
    else if (keyword == "cont") {
        return readContact(file, params);
    }
    else if (keyword == "bulk") {
        return readBulkViscosity(file, materials);
    }
    else if (keyword == "load") {
        return readLoad(file, particles);
    }
    else if (keyword == "velo") {
        return readVelocity(file, particles);
    }
    else if (keyword == "seos") {
        return readEOS(file, materials);
    }
    else if (keyword == "deto") {
        return readDetonation(file, materials);
    }
    else if (keyword == "jaum") {
        materials.setUseJaumannRate(readBool(file));
        return true;
    }
    else if (keyword == "uvfp") {
        params.update_volume_by_F = readBool(file);
        return true;
    }
    else if (keyword == "qulo") {
        params.quasi_static = readBool(file);
        return true;
    }
    else if (keyword == "smoo") {
        params.stress_smoothing = readBool(file);
        return true;
    }
    else if (keyword == "damp") {
        params.damping_coefficient = readReal(file);
        return true;
    }
    else if (keyword == "tecp") {
        params.write_tecplot = true;
        return true;
    }
    else if (keyword == "para") {
        params.write_paraview = true;
        return true;
    }
    else {
        std::cerr << "Unknown keyword: " << keyword << std::endl;
        return true;  // Continue anyway
    }
}

bool DataIn::readTitle(std::ifstream& file, SimulationParameters& params) {
    std::string line;
    if (!std::getline(file, line)) return false;
    params.title = line;
    std::cout << "Title: " << params.title << std::endl;
    return true;
}

bool DataIn::readNumParticles(std::ifstream& file, ParticleList& particles) {
    int num = readInt(file);
    if (num <= 0) return false;
    
    particles.reserve(num);
    std::cout << "Number of particles: " << num << std::endl;
    return true;
}

bool DataIn::readEndTime(std::ifstream& file, SimulationParameters& params) {
    params.end_time = readReal(file);
    std::cout << "End time: " << params.end_time << std::endl;
    return true;
}

bool DataIn::readGrid(std::ifstream& file, Grid& grid) {
    Vec2 span_x = {readReal(file), readReal(file)};
    Vec2 span_y = {readReal(file), readReal(file)};
    Vec2 span_z = {readReal(file), readReal(file)};
    Real cell_size = readReal(file);
    
    grid.initialize({span_x[0], span_x[1], 0}, {span_y[0], span_y[1], 0}, {span_z[0], span_z[1], 0}, cell_size, 1);
    return true;
}

bool DataIn::readSpanX(std::ifstream& file, Grid& grid) {
    // Set X span only
    Real x_min = readReal(file);
    Real x_max = readReal(file);
    std::cout << "X span: [" << x_min << ", " << x_max << "]" << std::endl;
    return true;
}

bool DataIn::readSpanY(std::ifstream& file, Grid& grid) {
    Real y_min = readReal(file);
    Real y_max = readReal(file);
    std::cout << "Y span: [" << y_min << ", " << y_max << "]" << std::endl;
    return true;
}

bool DataIn::readSpanZ(std::ifstream& file, Grid& grid) {
    Real z_min = readReal(file);
    Real z_max = readReal(file);
    std::cout << "Z span: [" << z_min << ", " << z_max << "]" << std::endl;
    return true;
}

bool DataIn::readCellSize(std::ifstream& file, Grid& grid) {
    Real size = readReal(file);
    std::cout << "Cell size: " << size << std::endl;
    return true;
}

bool DataIn::readDTScale(std::ifstream& file, SimulationParameters& params) {
    params.dt_scale = readReal(file);
    std::cout << "DT scale: " << params.dt_scale << std::endl;
    return true;
}

bool DataIn::readOutputTime(std::ifstream& file, SimulationParameters& params) {
    params.output_interval = readReal(file);
    return true;
}

bool DataIn::readReportTime(std::ifstream& file, SimulationParameters& params) {
    params.report_interval = readReal(file);
    return true;
}

bool DataIn::readFixedBoundaries(std::ifstream& file, Grid& grid) {
    // Read 6 integers for fixed boundaries
    std::array<int, 6> fixed_bc = {0,0,0,0,0,0};
    for (int i = 0; i < 6; ++i) {
        fixed_bc[i] = readInt(file);
    }
    
    // Apply to grid
    grid.setFixedBoundary(fixed_bc);
    return true;
}

bool DataIn::readNumMaterials(std::ifstream& file, MaterialList& materials) {
    int num = readInt(file);
    std::cout << "Number of materials: " << num << std::endl;
    return true;
}

bool DataIn::readMaterial(std::ifstream& file, MaterialList& materials) {
    Material mat;
    
    // Read material ID
    int id = readInt(file);
    mat.setID(id);
    
    // Read material type as string
    std::string type_str;
    file >> type_str;
    std::transform(type_str.begin(), type_str.end(), type_str.begin(), ::tolower);
    
    // Map string to MaterialType
    if (type_str == "elas") {
        mat.setMaterialType(MaterialType::ELASTIC);
    } else if (type_str == "pla1") {
        mat.setMaterialType(MaterialType::ELASTIC_PERFECT_PLASTIC);
    } else if (type_str == "john") {
        mat.setMaterialType(MaterialType::JOHNSON_COOK);
    } else if (type_str == "neo") {
        mat.setMaterialType(MaterialType::USER_MAT1);
    } else if (type_str == "hiex") {
        mat.setMaterialType(MaterialType::HIGH_EXPLOSIVE);
    } else if (type_str == "sjc") {
        mat.setMaterialType(MaterialType::SIMPLIFIED_JC);
    } else {
        std::cerr << "Unknown material type: " << type_str << std::endl;
        return false;
    }
    
    // Read basic properties
    mat.setDensity(readReal(file));
    mat.setYoungsModulus(readReal(file));
    mat.setPoissonsRatio(readReal(file));
    
    // Read additional properties based on type
    if (mat.getMaterialType() == MaterialType::ELASTIC_PERFECT_PLASTIC ||
        mat.getMaterialType() == MaterialType::JOHNSON_COOK ||
        mat.getMaterialType() == MaterialType::SIMPLIFIED_JC) {
        mat.setYieldStress(readReal(file));
        mat.setTangentModulus(readReal(file));
    }
    
    materials.addMaterial(mat);
    std::cout << "Added material " << id << " (" << type_str << ")" << std::endl;
    
    return true;
}

bool DataIn::readParticles(std::ifstream& file, ParticleList& particles,
                           BodyList& bodies) {
    // Read particle generation parameters
    int mat_id = readInt(file);
    int num_x = readInt(file);
    int num_y = readInt(file);
    int num_z = readInt(file);
    
    Vec3 origin = {readReal(file), readReal(file), readReal(file)};
    Vec3 spacing = {readReal(file), readReal(file), readReal(file)};
    
    // Generate particles
    int start_id = particles.size();
    
    for (int iz = 0; iz < num_z; ++iz) {
        for (int iy = 0; iy < num_y; ++iy) {
            for (int ix = 0; ix < num_x; ++ix) {
                Particle p;
                Vec3 pos = {
                    origin[0] + ix * spacing[0],
                    origin[1] + iy * spacing[1],
                    origin[2] + iz * spacing[2]
                };
                p.setPosition(pos);
                p.setPositionPrev(pos);
                p.setPositionInitial(pos);
                
                // Set mass based on material density and particle volume
                Real vol = spacing[0] * spacing[1] * spacing[2];
                p.setVolumeInitial(vol);
                p.setVolume(vol);
                // Mass will be set from material density later
                
                particles.push_back(p);
            }
        }
    }
    
    int end_id = particles.size();
    
    // Create body
    Body body(mat_id, body_counter_ + 1, start_id, end_id);
    bodies.push_back(body);
    body_counter_++;
    
    std::cout << "Generated " << (end_id - start_id) << " particles" << std::endl;
    
    return true;
}

bool DataIn::readContact(std::ifstream& file, SimulationParameters& params) {
    int type = readInt(file);
    Real friction = readReal(file);
    
    params.contact_type = static_cast<ContactType>(type);
    params.friction_coefficient = friction;
    
    std::cout << "Contact enabled with friction = " << friction << std::endl;
    
    return true;
}

bool DataIn::readBulkViscosity(std::ifstream& file, MaterialList& materials) {
    Real bq1 = readReal(file);
    Real bq2 = readReal(file);
    materials.setBQ1(bq1);
    materials.setBQ2(bq2);
    return true;
}

bool DataIn::readLoad(std::ifstream& file, ParticleList& particles) {
    // Read external load definition
    Vec3 force = {readReal(file), readReal(file), readReal(file)};
    
    // Apply to all particles (simplified)
    for (auto& p : particles) {
        p.setExternalForce(force);
    }
    
    return true;
}

bool DataIn::readVelocity(std::ifstream& file, ParticleList& particles) {
    // Read initial velocity
    Vec3 velocity = {readReal(file), readReal(file), readReal(file)};
    
    // Apply to all particles (simplified)
    for (auto& p : particles) {
        p.setVelocity(velocity);
    }
    
    return true;
}

bool DataIn::readEOS(std::ifstream& file, MaterialList& materials) {
    // Read equation of state parameters
    int mat_id = readInt(file);
    int eos_type = readInt(file);
    
    Material& mat = materials.getMaterial(mat_id);
    mat.setEosType(static_cast<EosType>(eos_type));
    
    // Read EOS constants
    Vec6 eos_constants;
    for (int i = 0; i < 6; ++i) {
        eos_constants[i] = readReal(file);
    }
    std::array<Real, 10> eos_10 = {0};
    for (size_t i = 0; i < eos_constants.size() && i < 10; ++i) eos_10[i] = eos_constants[i];
    mat.setEosConstants(eos_10);
    
    return true;
}

bool DataIn::readDetonation(std::ifstream& file, MaterialList& materials) {
    // Read detonation point
    Vec3 deto_point = {readReal(file), readReal(file), readReal(file)};
    materials.addDetonationPoint(deto_point[0], deto_point[1], deto_point[2]);
    return true;
}

// Helper functions to read values
int DataIn::readInt(std::ifstream& file) {
    std::string line;
    std::getline(file, line);
    current_line_++;
    std::istringstream iss(line);
    int value;
    iss >> value;
    return value;
}

Real DataIn::readReal(std::ifstream& file) {
    std::string line;
    std::getline(file, line);
    current_line_++;
    std::istringstream iss(line);
    Real value;
    iss >> value;
    return value;
}

bool DataIn::readBool(std::ifstream& file) {
    std::string line;
    std::getline(file, line);
    current_line_++;
    std::transform(line.begin(), line.end(), line.begin(), ::tolower);
    return (line.find("true") != std::string::npos ||
            line.find("on") != std::string::npos ||
            line.find("yes") != std::string::npos ||
            line.find("1") != std::string::npos);
}

} // namespace mpm3d
