#include "DomainDecomp.hpp"

#include <cstdlib>
#include <sstream>
#include <vector>

#if defined(MPM3D_USE_MPI)
#include <mpi.h>
#endif

namespace mpm3d {

static std::vector<int> splitByDelim(const std::string& s, char delim) {
    std::vector<int> out;
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        if (item.empty())
            continue;
        out.push_back(std::atoi(item.c_str()));
    }
    return out;
}

bool DomainDecomp::parseDimsEnv(std::array<int, 3>& dims) {
    const char* env = std::getenv("MPM3D_DIMS");
    if (!env || std::string(env).empty())
        return false;

    std::string s(env);
    for (char& c : s) {
        if (c == 'X')
            c = 'x';
    }

    std::vector<int> parts;
    if (s.find('x') != std::string::npos) {
        parts = splitByDelim(s, 'x');
    } else if (s.find(',') != std::string::npos) {
        parts = splitByDelim(s, ',');
    }

    if (parts.size() != 3)
        return false;

    if (parts[0] <= 0 || parts[1] <= 0 || parts[2] <= 0)
        return false;

    dims = {parts[0], parts[1], parts[2]};
    return true;
}

void DomainDecomp::splitAxis(int n, int p, int coord, int& begin, int& end) {
    const int base = n / p;
    const int rem = n % p;
    const int extra = (coord < rem) ? 1 : 0;
    begin = coord * base + std::min(coord, rem);
    end = begin + base + extra;
}

int DomainDecomp::ownerCoord(int n, int p, int idx) {
    if (p <= 1) return 0;
    const int base = n / p;
    const int rem = n % p;
    const int cut = (base + 1) * rem;
    if (idx < cut) {
        return idx / (base + 1);
    }
    return rem + (idx - cut) / base;
}

int DomainDecomp::ownerRankForCell(int ix, int iy, int iz,
                                   const std::array<int, 3>& dims,
                                   int nx, int ny, int nz) {
    const int px = dims[0];
    const int py = dims[1];
    const int pz = dims[2];
    const int rx = ownerCoord(nx, px, ix);
    const int ry = ownerCoord(ny, py, iy);
    const int rz = ownerCoord(nz, pz, iz);
    return rx + px * (ry + py * rz);
}

DecompInfo DomainDecomp::compute(int world_rank, int world_size,
                                 int nx, int ny, int nz) {
    DecompInfo info;

    std::array<int, 3> dims = {1, 1, 1};
    if (!parseDimsEnv(dims)) {
#if defined(MPM3D_USE_MPI)
        int tmp[3] = {0, 0, 0};
        MPI_Dims_create(world_size, 3, tmp);
        dims = {tmp[0], tmp[1], tmp[2]};
#else
        dims = {1, 1, 1};
#endif
    }

    info.dims = dims;

    // Map rank -> (x,y,z) coordinates in a row-major ordering.
    const int px = dims[0];
    const int py = dims[1];
    const int pz = dims[2];

    const int r = world_rank;
    const int rx = r % px;
    const int ry = (r / px) % py;
    const int rz = (r / (px * py)) % pz;
    info.coords = {rx, ry, rz};

    splitAxis(nx, px, rx, info.cells.ix0, info.cells.ix1);
    splitAxis(ny, py, ry, info.cells.iy0, info.cells.iy1);
    splitAxis(nz, pz, rz, info.cells.iz0, info.cells.iz1);

    return info;
}

std::string DomainDecomp::toString(const DecompInfo& info) {
    std::ostringstream oss;
    oss << "dims=" << info.dims[0] << "x" << info.dims[1] << "x" << info.dims[2]
        << " coords=" << info.coords[0] << "," << info.coords[1] << "," << info.coords[2]
        << " cells=[" << info.cells.ix0 << "," << info.cells.ix1
        << ")x[" << info.cells.iy0 << "," << info.cells.iy1
        << ")x[" << info.cells.iz0 << "," << info.cells.iz1 << ")";
    return oss.str();
}

} // namespace mpm3d
