// Material.cpp - Material property implementations
// Note: Most methods are implemented inline in Material.hpp
// This file contains only non-inline implementations if needed

#include "Material.hpp"

namespace mpm3d {

// Material constructor - using member names from header
Material::Material()
    : MatType_(MaterialType::ELASTIC), EosType_(EosType::NONE),
      name_(""), id_(0),
      Density_(0), Young_(0), Poisson_(0), miu_(0), Mp_(0),
      BulkModulus_(0), Wavespd_(0),
      Yield0_(0), TangMod_(0),
      B_jc_(0), n_jc_(0), C_jc_(0), m_jc_(0), epso_(1.0),
      prd_(0), epf_(0),
      roomt_(293.0), Melt_(1800.0), SpecHeat_(0),
      D_(0),
      q_fai_(0), k_fai_(0), q_psi_(0), ten_f_(0) {
    cEos_.fill(0);
}

// MaterialList methods are all inline in header

} // namespace mpm3d