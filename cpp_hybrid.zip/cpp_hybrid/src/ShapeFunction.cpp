// ShapeFunction.cpp - Shape function implementations
// Translated from Grid.f90 shape function routines

#include "ShapeFunction.hpp"
#include "Particle.hpp"
#include "Grid.hpp"
#include <cmath>
#include <algorithm>

namespace mpm3d {

ShapeFunction::ShapeFunction(ShapeFunctionType type)
    : type_(type) {
}

void ShapeFunction::evaluate(const Particle& particle,
                            const Grid& grid,
                            std::vector<int>& nodes,
                            std::vector<Real>& shape_values,
                            std::vector<Vec3>& shape_gradients) {
    
    int cell_id = particle.getCell();
    if (cell_id < 0) {
        nodes.clear();
        shape_values.clear();
        shape_gradients.clear();
        return;
    }
    
    // Get cell nodes
    auto cell_nodes = grid.getCellNodes(cell_id);
    nodes.assign(cell_nodes.begin(), cell_nodes.end());
    
    // Get natural coordinates [-1, 1]^3
    Vec3 xi = particle.getNaturalCoords();
    Real cell_size = grid.getCellSize();
    
    switch (type_) {
        case ShapeFunctionType::LINEAR:
            evaluateLinear(xi, shape_values, shape_gradients, cell_size);
            break;
        case ShapeFunctionType::GIMP:
            evaluateGIMP(particle, grid, nodes, shape_values, shape_gradients);
            break;
        case ShapeFunctionType::BSPLINE:
            evaluateBspline(particle, grid, nodes, shape_values, shape_gradients);
            break;
        case ShapeFunctionType::SGMP:
            evaluateLinear(xi, shape_values, shape_gradients, cell_size);
            break;
        default:
            evaluateLinear(xi, shape_values, shape_gradients, cell_size);
            break;
    }
}

void ShapeFunction::evaluateLinear(const Vec3& xi,
                                   std::vector<Real>& shape_values,
                                   std::vector<Vec3>& shape_gradients,
                                   Real cell_size) {
    // Standard trilinear shape functions for hexahedral element
    
    // Shape function signs for 8 nodes
    const int SNX[8] = {-1, 1, 1, -1, -1, 1, 1, -1};
    const int SNY[8] = {-1, -1, 1, 1, -1, -1, 1, 1};
    const int SNZ[8] = {-1, -1, -1, -1, 1, 1, 1, 1};
    
    shape_values.resize(8);
    shape_gradients.resize(8);
    
    Real jacobi = cell_size / 2.0;
    Real inv_jacobi = 1.0 / jacobi;
    
    for (int i = 0; i < 8; ++i) {
        // Shape function
        Real Ni = 0.125 * (1.0 + SNX[i] * xi[0]) * 
                          (1.0 + SNY[i] * xi[1]) * 
                          (1.0 + SNZ[i] * xi[2]);
        shape_values[i] = Ni;
        
        // Shape function derivatives in natural coordinates
        Real dN_dxi   = 0.125 * SNX[i] * (1.0 + SNY[i] * xi[1]) * (1.0 + SNZ[i] * xi[2]);
        Real dN_deta  = 0.125 * (1.0 + SNX[i] * xi[0]) * SNY[i] * (1.0 + SNZ[i] * xi[2]);
        Real dN_dzeta = 0.125 * (1.0 + SNX[i] * xi[0]) * (1.0 + SNY[i] * xi[1]) * SNZ[i];
        
        // Transform to physical coordinates
        shape_gradients[i][0] = dN_dxi * inv_jacobi;
        shape_gradients[i][1] = dN_deta * inv_jacobi;
        shape_gradients[i][2] = dN_dzeta * inv_jacobi;
    }
}

void ShapeFunction::evaluateGIMP(const Particle& particle,
                                const Grid& grid,
                                std::vector<int>& nodes,
                                std::vector<Real>& shape_values,
                                std::vector<Vec3>& shape_gradients) {
    // Generalized Interpolation Material Point (GIMP) method
    // For simplicity, use standard 8-node with extended support consideration
    
    Vec3 xi = particle.getNaturalCoords();
    Real cell_size = grid.getCellSize();
    evaluateLinear(xi, shape_values, shape_gradients, cell_size);
}

void ShapeFunction::evaluateBspline(const Particle& particle,
                                   const Grid& grid,
                                   std::vector<int>& nodes,
                                   std::vector<Real>& shape_values,
                                   std::vector<Vec3>& shape_gradients) {

    // Fortran BSMPM implementation (Grid.f90: BFindInflNode + NShape_Bspline)
    // Influence nodes: 27 nodes, shape function definition differs from a
    // standard cubic B-spline tensor product.

    nodes.clear();
    shape_values.clear();
    shape_gradients.clear();

    const int cell_id = particle.getCell();
    if (cell_id < 0) {
        return;
    }

    const auto cell_nodes = grid.getCellNodes(cell_id);
    const int NGx = grid.getNumCellsX() + 1;
    const int NGy = grid.getNumCellsY() + 1;
    const int NGxy = NGx * NGy;
    const int num_nodes = grid.getNumNodes();

    // BFindInflNode(icell) in Fortran uses 1-based node numbering.
    // Do the arithmetic in 1-based space and convert back to 0-based indices.
    std::array<int, 27> infl1;
    for (int i = 0; i < 8; ++i) infl1[i] = cell_nodes[i] + 1;

    infl1[8]  = infl1[0] - NGxy;
    infl1[9]  = infl1[1] - NGxy;
    infl1[10] = infl1[2] - NGxy;
    infl1[11] = infl1[3] - NGxy;

    infl1[12] = infl1[8] - NGx;
    infl1[13] = infl1[9] - NGx;
    infl1[14] = infl1[0] - NGx;
    infl1[15] = infl1[1] - NGx;
    infl1[16] = infl1[4] - NGx;
    infl1[17] = infl1[5] - NGx;

    infl1[18] = infl1[0] - 1;
    infl1[19] = infl1[3] - 1;
    infl1[20] = infl1[4] - 1;
    infl1[21] = infl1[7] - 1;
    infl1[22] = infl1[8] - 1;
    infl1[23] = infl1[11] - 1;
    infl1[24] = infl1[12] - 1;
    infl1[25] = infl1[14] - 1;
    infl1[26] = infl1[16] - 1;

    std::array<int, 27> infl;
    for (int i = 0; i < 27; ++i) infl[i] = infl1[i] - 1;

    // NShape_Bspline(p)
    // r = (Xp - node_list(InflNode(1))%Xg) * iDCell*0.2 + 0.4
    const Vec3 pos = particle.getPositionPrev();
    const Real cell_size = grid.getCellSize();
    const Real iDCell = 1.0 / cell_size;

    if (infl[0] < 0 || infl[0] >= num_nodes) {
        return;
    }

    const Vec3 xg0 = grid.getNode(infl[0]).getPosition();
    Vec3 r;
    r[0] = (pos[0] - xg0[0]) * iDCell * 0.2 + 0.4;
    r[1] = (pos[1] - xg0[1]) * iDCell * 0.2 + 0.4;
    r[2] = (pos[2] - xg0[2]) * iDCell * 0.2 + 0.4;

    Real sh[3][3] = {{0.0}};
    Real dn[3][3] = {{0.0}};

    for (int d = 0; d < 3; ++d) {
        const Real rd = r[d];
        sh[0][d] = 0.5 * std::pow(3.0 - 5.0 * rd, 2);
        sh[1][d] = -25.0 * rd * rd + 25.0 * rd - 5.5;
        sh[2][d] = 0.5 * std::pow(5.0 * rd - 2.0, 2);

        dn[0][d] = (5.0 * rd - 3.0) * 5.0 * 0.2 * iDCell;
        dn[1][d] = (-50.0 * rd + 25.0) * 0.2 * iDCell;
        dn[2][d] = (5.0 * rd - 2.0) * 5.0 * 0.2 * iDCell;
    }

    std::array<Real, 27> SHP;
    std::array<Real, 27> DNDX;
    std::array<Real, 27> DNDY;
    std::array<Real, 27> DNDZ;

    // SHP(1..27)
    SHP[0]  = sh[1][0]*sh[1][1]*sh[1][2];
    SHP[1]  = sh[2][0]*sh[1][1]*sh[1][2];
    SHP[2]  = sh[2][0]*sh[2][1]*sh[1][2];
    SHP[3]  = sh[1][0]*sh[2][1]*sh[1][2];
    SHP[4]  = sh[1][0]*sh[1][1]*sh[2][2];
    SHP[5]  = sh[2][0]*sh[1][1]*sh[2][2];
    SHP[6]  = sh[2][0]*sh[2][1]*sh[2][2];
    SHP[7]  = sh[1][0]*sh[2][1]*sh[2][2];
    SHP[8]  = sh[1][0]*sh[1][1]*sh[0][2];
    SHP[9]  = sh[2][0]*sh[1][1]*sh[0][2];
    SHP[10] = sh[2][0]*sh[2][1]*sh[0][2];
    SHP[11] = sh[1][0]*sh[2][1]*sh[0][2];
    SHP[12] = sh[1][0]*sh[0][1]*sh[0][2];
    SHP[13] = sh[2][0]*sh[0][1]*sh[0][2];
    SHP[14] = sh[1][0]*sh[0][1]*sh[1][2];
    SHP[15] = sh[2][0]*sh[0][1]*sh[1][2];
    SHP[16] = sh[1][0]*sh[0][1]*sh[2][2];
    SHP[17] = sh[2][0]*sh[0][1]*sh[2][2];
    SHP[18] = sh[0][0]*sh[1][1]*sh[1][2];
    SHP[19] = sh[0][0]*sh[2][1]*sh[1][2];
    SHP[20] = sh[0][0]*sh[1][1]*sh[2][2];
    SHP[21] = sh[0][0]*sh[2][1]*sh[2][2];
    SHP[22] = sh[0][0]*sh[1][1]*sh[0][2];
    SHP[23] = sh[0][0]*sh[2][1]*sh[0][2];
    SHP[24] = sh[0][0]*sh[0][1]*sh[0][2];
    SHP[25] = sh[0][0]*sh[0][1]*sh[1][2];
    SHP[26] = sh[0][0]*sh[0][1]*sh[2][2];

    // DNDX(1..27)
    DNDX[0]  = dn[1][0]*sh[1][1]*sh[1][2];
    DNDX[1]  = dn[2][0]*sh[1][1]*sh[1][2];
    DNDX[2]  = dn[2][0]*sh[2][1]*sh[1][2];
    DNDX[3]  = dn[1][0]*sh[2][1]*sh[1][2];
    DNDX[4]  = dn[1][0]*sh[1][1]*sh[2][2];
    DNDX[5]  = dn[2][0]*sh[1][1]*sh[2][2];
    DNDX[6]  = dn[2][0]*sh[2][1]*sh[2][2];
    DNDX[7]  = dn[1][0]*sh[2][1]*sh[2][2];
    DNDX[8]  = dn[1][0]*sh[1][1]*sh[0][2];
    DNDX[9]  = dn[2][0]*sh[1][1]*sh[0][2];
    DNDX[10] = dn[2][0]*sh[2][1]*sh[0][2];
    DNDX[11] = dn[1][0]*sh[2][1]*sh[0][2];
    DNDX[12] = dn[1][0]*sh[0][1]*sh[0][2];
    DNDX[13] = dn[2][0]*sh[0][1]*sh[0][2];
    DNDX[14] = dn[1][0]*sh[0][1]*sh[1][2];
    DNDX[15] = dn[2][0]*sh[0][1]*sh[1][2];
    DNDX[16] = dn[1][0]*sh[0][1]*sh[2][2];
    DNDX[17] = dn[2][0]*sh[0][1]*sh[2][2];
    DNDX[18] = dn[0][0]*sh[1][1]*sh[1][2];
    DNDX[19] = dn[0][0]*sh[2][1]*sh[1][2];
    DNDX[20] = dn[0][0]*sh[1][1]*sh[2][2];
    DNDX[21] = dn[0][0]*sh[2][1]*sh[2][2];
    DNDX[22] = dn[0][0]*sh[1][1]*sh[0][2];
    DNDX[23] = dn[0][0]*sh[2][1]*sh[0][2];
    DNDX[24] = dn[0][0]*sh[0][1]*sh[0][2];
    DNDX[25] = dn[0][0]*sh[0][1]*sh[1][2];
    DNDX[26] = dn[0][0]*sh[0][1]*sh[2][2];

    // DNDY(1..27)
    DNDY[0]  = sh[1][0]*dn[1][1]*sh[1][2];
    DNDY[1]  = sh[2][0]*dn[1][1]*sh[1][2];
    DNDY[2]  = sh[2][0]*dn[2][1]*sh[1][2];
    DNDY[3]  = sh[1][0]*dn[2][1]*sh[1][2];
    DNDY[4]  = sh[1][0]*dn[1][1]*sh[2][2];
    DNDY[5]  = sh[2][0]*dn[1][1]*sh[2][2];
    DNDY[6]  = sh[2][0]*dn[2][1]*sh[2][2];
    DNDY[7]  = sh[1][0]*dn[2][1]*sh[2][2];
    DNDY[8]  = sh[1][0]*dn[1][1]*sh[0][2];
    DNDY[9]  = sh[2][0]*dn[1][1]*sh[0][2];
    DNDY[10] = sh[2][0]*dn[2][1]*sh[0][2];
    DNDY[11] = sh[1][0]*dn[2][1]*sh[0][2];
    DNDY[12] = sh[1][0]*dn[0][1]*sh[0][2];
    DNDY[13] = sh[2][0]*dn[0][1]*sh[0][2];
    DNDY[14] = sh[1][0]*dn[0][1]*sh[1][2];
    DNDY[15] = sh[2][0]*dn[0][1]*sh[1][2];
    DNDY[16] = sh[1][0]*dn[0][1]*sh[2][2];
    DNDY[17] = sh[2][0]*dn[0][1]*sh[2][2];
    DNDY[18] = sh[0][0]*dn[1][1]*sh[1][2];
    DNDY[19] = sh[0][0]*dn[2][1]*sh[1][2];
    DNDY[20] = sh[0][0]*dn[1][1]*sh[2][2];
    DNDY[21] = sh[0][0]*dn[2][1]*sh[2][2];
    DNDY[22] = sh[0][0]*dn[1][1]*sh[0][2];
    DNDY[23] = sh[0][0]*dn[2][1]*sh[0][2];
    DNDY[24] = sh[0][0]*dn[0][1]*sh[0][2];
    DNDY[25] = sh[0][0]*dn[0][1]*sh[1][2];
    DNDY[26] = sh[0][0]*dn[0][1]*sh[2][2];

    // DNDZ(1..27)
    DNDZ[0]  = sh[1][0]*sh[1][1]*dn[1][2];
    DNDZ[1]  = sh[2][0]*sh[1][1]*dn[1][2];
    DNDZ[2]  = sh[2][0]*sh[2][1]*dn[1][2];
    DNDZ[3]  = sh[1][0]*sh[2][1]*dn[1][2];
    DNDZ[4]  = sh[1][0]*sh[1][1]*dn[2][2];
    DNDZ[5]  = sh[2][0]*sh[1][1]*dn[2][2];
    DNDZ[6]  = sh[2][0]*sh[2][1]*dn[2][2];
    DNDZ[7]  = sh[1][0]*sh[2][1]*dn[2][2];
    DNDZ[8]  = sh[1][0]*sh[1][1]*dn[0][2];
    DNDZ[9]  = sh[2][0]*sh[1][1]*dn[0][2];
    DNDZ[10] = sh[2][0]*sh[2][1]*dn[0][2];
    DNDZ[11] = sh[1][0]*sh[2][1]*dn[0][2];
    DNDZ[12] = sh[1][0]*sh[0][1]*dn[0][2];
    DNDZ[13] = sh[2][0]*sh[0][1]*dn[0][2];
    DNDZ[14] = sh[1][0]*sh[0][1]*dn[1][2];
    DNDZ[15] = sh[2][0]*sh[0][1]*dn[1][2];
    DNDZ[16] = sh[1][0]*sh[0][1]*dn[2][2];
    DNDZ[17] = sh[2][0]*sh[0][1]*dn[2][2];
    DNDZ[18] = sh[0][0]*sh[1][1]*dn[1][2];
    DNDZ[19] = sh[0][0]*sh[2][1]*dn[1][2];
    DNDZ[20] = sh[0][0]*sh[1][1]*dn[2][2];
    DNDZ[21] = sh[0][0]*sh[2][1]*dn[2][2];
    DNDZ[22] = sh[0][0]*sh[1][1]*dn[0][2];
    DNDZ[23] = sh[0][0]*sh[2][1]*dn[0][2];
    DNDZ[24] = sh[0][0]*sh[0][1]*dn[0][2];
    DNDZ[25] = sh[0][0]*sh[0][1]*dn[1][2];
    DNDZ[26] = sh[0][0]*sh[0][1]*dn[2][2];

    nodes.reserve(27);
    shape_values.reserve(27);
    shape_gradients.reserve(27);
    for (int k = 0; k < 27; ++k) {
        const int nid = infl[k];
        if (nid < 0 || nid >= num_nodes) {
            continue;
        }
        nodes.push_back(nid);
        shape_values.push_back(SHP[k]);
        Vec3 grad = {DNDX[k], DNDY[k], DNDZ[k]};
        shape_gradients.push_back(grad);
    }
}

void ShapeFunction::evaluateSGMP(const Vec3& xi,
                                std::vector<Real>& N,
                                std::vector<Vec3>& dN,
                                Real cell_size) {
    // SGMP uses linear shape functions on auxiliary grid
    evaluateLinear(xi, N, dN, cell_size);
}

Real ShapeFunction::bsplineShape(Real xi) const {
    // 1D cubic B-spline shape function
    Real ax = std::abs(xi);
    
    if (ax < 1.0) {
        return 0.5 * ax * ax * ax - ax * ax + 2.0/3.0;
    } else if (ax < 2.0) {
        return -1.0/6.0 * ax * ax * ax + ax * ax - 2.0 * ax + 4.0/3.0;
    } else {
        return 0.0;
    }
}

Real ShapeFunction::bsplineShapeGrad(Real xi) const {
    // Derivative of 1D cubic B-spline
    Real ax = std::abs(xi);
    
    if (ax < 1.0) {
        return 1.5 * xi * ax - 2.0 * xi;
    } else if (ax < 2.0) {
        Real sign = (xi > 0) ? 1.0 : -1.0;
        return sign * (-0.5 * ax * ax + 2.0 * ax - 2.0);
    } else {
        return 0.0;
    }
}

void ShapeFunction::evaluateAuxiliary(const Particle& particle,
                                     const Grid& grid,
                                     std::vector<int>& center_nodes,
                                     std::vector<Real>& shape_values,
                                     std::vector<Vec3>& shape_gradients) {
    // Evaluate shape functions on auxiliary grid (for SGMP)
    
    int center_cell = particle.getCenterCell();
    if (center_cell < 0) {
        center_nodes.clear();
        shape_values.clear();
        shape_gradients.clear();
        return;
    }
    
    // Get auxiliary grid nodes (which are actually cell centers)
    auto aux_nodes = grid.getCenterCellNodes(center_cell);
    center_nodes.assign(aux_nodes.begin(), aux_nodes.end());
    
    // Use linear shape functions on auxiliary grid
    Vec3 xi = particle.getNaturalCoordsAux();
    Real cell_size = grid.getCellSize();
    
    evaluateLinear(xi, shape_values, shape_gradients, cell_size);
}

void ShapeFunction::findGIMPInfluenceNodes(const Particle& particle,
                                          const Grid& grid,
                                          int base_cell,
                                          std::vector<int>& nodes) {
    // Find nodes influenced by GIMP particle domain
    // Simplified implementation
    auto cell_nodes = grid.getCellNodes(base_cell);
    nodes.assign(cell_nodes.begin(), cell_nodes.end());
}

} // namespace mpm3d