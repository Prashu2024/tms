// Main.cpp - Program entry point

#include "MPMSolver.hpp"
#include <iostream>
#include <string>

#if defined(MPM3D_USE_MPI)
#include <mpi.h>
#include <cstdlib>
#endif

int main(int argc, char** argv) {
#if defined(MPM3D_USE_MPI)
    int mpi_rank = 0;
    int mpi_size = 1;
    bool mpi_active = false;
#endif
    try {
        std::string input_file = "input.dat";

#if defined(MPM3D_USE_MPI)
        auto env_set = [](const char* name) {
            const char* v = std::getenv(name);
            return v && *v != '\0';
        };
        const bool mpi_enabled =
            env_set("MPM3D_MPI_ENABLE") ||
            env_set("OMPI_COMM_WORLD_SIZE") ||
            env_set("PMI_SIZE") ||
            env_set("SLURM_NTASKS");

        if (mpi_enabled) {
            MPI_Init(&argc, &argv);
            mpi_active = true;
            MPI_Comm_rank(MPI_COMM_WORLD, &mpi_rank);
            MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);
        }
#endif

        if (argc > 1) {
            input_file = argv[1];
        }

#if defined(MPM3D_USE_MPI)
        if (mpi_rank == 0) {
#endif
            std::cout << "MPM3D-Faithful - Material Point Method Solver" << std::endl;
            std::cout << "Faithful C++ conversion of MPM3D-F90" << std::endl;
            std::cout << std::endl;
#if defined(MPM3D_USE_MPI)
            if (mpi_size > 1) {
                std::cout << "MPI enabled: " << mpi_size << " ranks" << std::endl;
            }
        }
#endif

        mpm3d::MPMSolver solver;

        solver.initialize(input_file);
        solver.solve();

#if defined(MPM3D_USE_MPI)
        if (mpi_rank == 0) {
#endif
            std::cout << "\nSimulation completed successfully!" << std::endl;
#if defined(MPM3D_USE_MPI)
        }
        if (mpi_active) {
            MPI_Finalize();
        }
#endif

        return 0;

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
#if defined(MPM3D_USE_MPI)
        if (mpi_active) {
            MPI_Finalize();
        }
#endif
        return 1;
    }
}
