// Body.cpp - Body implementations

#include "Body.hpp"

namespace mpm3d {

// Body class methods are all inline in the header
// No implementation needed here since all methods are defined in Body.hpp

// BodyList is just a typedef to std::vector<Body>
// All vector operations are available directly

} // namespace mpm3d