// Contact.cpp - Multi-body contact implementation
// Translated from update_step.f90 contact routines

#include "Contact.hpp"
#include "UpdateStep.hpp"
#include "Grid.hpp"
#include "Particle.hpp"
#include "Body.hpp"
#include <cmath>
#include <algorithm>
#include <iostream>

namespace mpm3d {

Contact::Contact()
    : type_(ContactType::NONE),
      friction_coefficient_(0),
      penalty_stiffness_(1.0e6),
      normal_body_(0) {
}

void Contact::initialize(ContactType type, Real friction, Real penalty_k) {
    type_ = type;
    friction_coefficient_ = friction;
    penalty_stiffness_ = penalty_k;
}

void Contact::detectAndResolve(Grid& grid, const ParticleList& particles,
                               const BodyList& bodies, Real dt) {
    if (type_ == ContactType::NONE) return;
    
    switch (type_) {
        case ContactType::LAGRANGIAN:
            lagrangianContact(grid, particles, bodies, dt);
            break;
        case ContactType::PENALTY:
            penaltyContact(grid, particles, bodies, dt);
            break;
        default:
            break;
    }
}

void Contact::lagrangianContact(Grid& grid, const ParticleList& particles,
                                const BodyList& bodies, Real dt) {
    // Lagrangian contact at grid nodes
    // References: update_step.f90 Lagr_NodContact
    
    int num_components = grid.getNumComponents();
    if (num_components <= 1) return;  // No contact with single body
    
    total_contact_force_ = {0, 0, 0};
    
    // Loop over all grid nodes
    for (int i = 0; i < grid.getNumNodes(); ++i) {
        // Check if multiple components have mass at this node
        int active_components = 0;
        for (int comp = 1; comp <= num_components; ++comp) {
            const auto& node_prop = grid.getNodeProperty(comp, i);
            if (node_prop.getMass() > grid.getCutOff()) {
                active_components++;
            }
        }
        
        if (active_components <= 1) continue;  // No contact at this node
        
        // Calculate total momentum at node
        Vec3 total_momentum = {0, 0, 0};
        Real total_mass = 0;
        
        for (int comp = 1; comp <= num_components; ++comp) {
            const auto& node_prop = grid.getNodeProperty(comp, i);
            if (node_prop.getMass() > grid.getCutOff()) {
                total_momentum += node_prop.getMomentum();
                total_mass += node_prop.getMass();
            }
        }
        
        // Average velocity
        Vec3 v_avg = total_momentum / total_mass;
        
        // Calculate contact normal (simplified - points from body 1 to body 2)
        Vec3 normal = calculateContactNormal(i, grid, particles, bodies);
        Real normal_mag = norm(normal);
        if (normal_mag < EPSILON) continue;
        normal = normal / normal_mag;
        
        // Calculate tangent directions
        Vec3 tangent1, tangent2;
        calculateTangents(normal, tangent1, tangent2);
        
        // Apply contact constraints
        for (int comp = 1; comp <= num_components; ++comp) {
            auto& node_prop = grid.getNodeProperty(comp, i);
            if (node_prop.getMass() < grid.getCutOff()) continue;
            
            Vec3 v_old = node_prop.getVelocity();
            
            // Calculate relative velocity in normal direction
            Real v_n = dot(v_old - v_avg, normal);
            
            // If separating, no contact
            if (v_n > 0) continue;
            
            // Apply normal constraint (no penetration)
            Vec3 v_new = v_old - v_n * normal;
            
            // Apply friction
            Vec3 v_tangent = v_new - dot(v_new, normal) * normal;
            Real v_t = norm(v_tangent);
            
            if (v_t > EPSILON) {
                // Coulomb friction
                Real friction_force = friction_coefficient_ * std::abs(v_n) * 
                                     node_prop.getMass() / dt;
                Real tangent_force = node_prop.getMass() * v_t / dt;
                
                if (tangent_force > friction_force) {
                    // Sliding
                    v_new = v_new - friction_force * dt / node_prop.getMass() * 
                           (v_tangent / v_t);
                } else {
                    // Sticking
                    v_new = dot(v_new, normal) * normal;
                }
            }
            
            // Update momentum
            Vec3 momentum_new = node_prop.getMass() * v_new;
            node_prop.setMomentum(momentum_new);
            
            // Track contact force
            Vec3 force = (momentum_new - node_prop.getMass() * v_old) / dt;
            total_contact_force_ += force;
        }
    }
}

void Contact::penaltyContact(Grid& grid, const ParticleList& particles,
                             const BodyList& bodies, Real dt) {
    // Penalty-based contact
    // Apply penalty forces at nodes where bodies overlap
    
    int num_components = grid.getNumComponents();
    if (num_components <= 1) return;
    
    total_contact_force_ = {0, 0, 0};
    
    for (int i = 0; i < grid.getNumNodes(); ++i) {
        // Check for multi-body presence
        std::vector<int> active_comps;
        for (int comp = 1; comp <= num_components; ++comp) {
            const auto& node_prop = grid.getNodeProperty(comp, i);
            if (node_prop.getMass() > grid.getCutOff()) {
                active_comps.push_back(comp);
            }
        }
        
        if (active_comps.size() <= 1) continue;
        
        // Calculate contact normal and penetration
        Vec3 normal = calculateContactNormal(i, grid, particles, bodies);
        Real penetration = calculatePenetration(i, grid, particles, bodies);
        
        if (penetration < 0) continue;  // No penetration
        
        // Calculate penalty force
        Vec3 penalty_force = penalty_stiffness_ * penetration * normal;
        
        // Apply to all bodies at this node
        for (int comp : active_comps) {
            auto& node_prop = grid.getNodeProperty(comp, i);
            
            // Body 1 gets positive force, body 2 gets negative
            Vec3 force = (comp == 1) ? penalty_force : Vec3{-penalty_force[0], -penalty_force[1], -penalty_force[2]};
            node_prop.addForce(force);
            
            total_contact_force_ += force;
        }
    }
}

Vec3 Contact::calculateContactNormal(int node_id, const Grid& grid,
                                     const ParticleList& particles,
                                     const BodyList& bodies) {
    // Calculate contact normal at node
    // Simplified: vector from centroid of body 1 to body 2
    
    Vec3 centroid1 = {0, 0, 0};
    Vec3 centroid2 = {0, 0, 0};
    int count1 = 0, count2 = 0;
    
    // Find centroids (very simplified - should use particles near contact)
    for (size_t p = 0; p < particles.size(); ++p) {
        const Particle& pt = particles[p];
        
        // Determine which body
        int body_id = 0;
        for (size_t b = 0; b < bodies.size(); ++b) {
            if (p >= static_cast<size_t>(bodies[b].getParticleBegin()) &&
                p < static_cast<size_t>(bodies[b].getParticleEnd())) {
                body_id = bodies[b].getComponentID();
                break;
            }
        }
        
        if (body_id == 1) {
            centroid1 += pt.getPosition();
            count1++;
        } else if (body_id == 2) {
            centroid2 += pt.getPosition();
            count2++;
        }
    }
    
    if (count1 > 0) centroid1 = centroid1 / static_cast<Real>(count1);
    if (count2 > 0) centroid2 = centroid2 / static_cast<Real>(count2);
    
    Vec3 normal = centroid2 - centroid1;
    Real mag = norm(normal);
    if (mag > EPSILON) {
        normal = normal / mag;
    } else {
        normal = {0, 0, 1};  // Default normal
    }
    
    return normal;
}

Real Contact::calculatePenetration(int node_id, const Grid& grid,
                                   const ParticleList& particles,
                                   const BodyList& bodies) {
    // Calculate penetration depth (simplified)
    // Real implementation would track surfaces
    
    return 0.0;  // Placeholder
}

void Contact::calculateTangents(const Vec3& normal, Vec3& tangent1, Vec3& tangent2) {
    // Calculate two orthogonal tangent vectors given normal
    
    // Find direction least aligned with normal
    Vec3 temp = {1, 0, 0};
    if (std::abs(dot(normal, temp)) > 0.9) {
        temp = {0, 1, 0};
    }
    
    // First tangent: orthogonal to normal
    tangent1 = cross(normal, temp);
    Real mag1 = norm(tangent1);
    if (mag1 > EPSILON) {
        tangent1 = tangent1 / mag1;
    }
    
    // Second tangent: orthogonal to both
    tangent2 = cross(normal, tangent1);
    Real mag2 = norm(tangent2);
    if (mag2 > EPSILON) {
        tangent2 = tangent2 / mag2;
    }
}

void Contact::setContactNodeProperty(int node_id, const Vec3& normal,
                                     const Vec3& tangent) {
    // Store normal and tangent at contact node
    ContactNodeProperty prop;
    prop.normal = normal;
    prop.tangent = tangent;
    contact_properties_[node_id] = prop;
}

} // namespace mpm3d
