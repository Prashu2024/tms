// Grid.cpp - Grid and cell operations implementation
// Translated from Grid.f90

#include "Grid.hpp"
#include <cmath>
#include <algorithm>
#include <iostream>
#include <vector>
#if defined(MPM3D_USE_MPI)
#include <mpi.h>
#endif

namespace mpm3d {

namespace {
struct SlabRange {
    int ix0, ix1;
    int iy0, iy1;
    int iz0, iz1;
};

int neighborRank(const DecompInfo& info, int dx, int dy, int dz) {
    const int nx = info.dims[0];
    const int ny = info.dims[1];
    const int nz = info.dims[2];
    const int cx = info.coords[0] + dx;
    const int cy = info.coords[1] + dy;
    const int cz = info.coords[2] + dz;
    if (cx < 0 || cy < 0 || cz < 0 || cx >= nx || cy >= ny || cz >= nz) {
        return MPI_PROC_NULL;
    }
    return (cz * ny + cy) * nx + cx;
}

void slabRangesForDir(const Subdomain3D& owned, int ghost,
                      int dx, int dy, int dz,
                      SlabRange& ghost_slab,
                      SlabRange& owned_slab) {
    ghost_slab.ix0 = owned.ix0;
    ghost_slab.ix1 = owned.ix1;
    ghost_slab.iy0 = owned.iy0;
    ghost_slab.iy1 = owned.iy1;
    ghost_slab.iz0 = owned.iz0;
    ghost_slab.iz1 = owned.iz1;

    owned_slab.ix0 = owned.ix0;
    owned_slab.ix1 = owned.ix1;
    owned_slab.iy0 = owned.iy0;
    owned_slab.iy1 = owned.iy1;
    owned_slab.iz0 = owned.iz0;
    owned_slab.iz1 = owned.iz1;

    if (dx != 0) {
        if (dx < 0) {
            ghost_slab.ix0 = owned.ix0 - ghost;
            ghost_slab.ix1 = owned.ix0;
            owned_slab.ix0 = owned.ix0;
            owned_slab.ix1 = owned.ix0 + ghost;
        } else {
            ghost_slab.ix0 = owned.ix1;
            ghost_slab.ix1 = owned.ix1 + ghost;
            owned_slab.ix0 = owned.ix1 - ghost;
            owned_slab.ix1 = owned.ix1;
        }
    }
    if (dy != 0) {
        if (dy < 0) {
            ghost_slab.iy0 = owned.iy0 - ghost;
            ghost_slab.iy1 = owned.iy0;
            owned_slab.iy0 = owned.iy0;
            owned_slab.iy1 = owned.iy0 + ghost;
        } else {
            ghost_slab.iy0 = owned.iy1;
            ghost_slab.iy1 = owned.iy1 + ghost;
            owned_slab.iy0 = owned.iy1 - ghost;
            owned_slab.iy1 = owned.iy1;
        }
    }
    if (dz != 0) {
        if (dz < 0) {
            ghost_slab.iz0 = owned.iz0 - ghost;
            ghost_slab.iz1 = owned.iz0;
            owned_slab.iz0 = owned.iz0;
            owned_slab.iz1 = owned.iz0 + ghost;
        } else {
            ghost_slab.iz0 = owned.iz1;
            ghost_slab.iz1 = owned.iz1 + ghost;
            owned_slab.iz0 = owned.iz1 - ghost;
            owned_slab.iz1 = owned.iz1;
        }
    }
}

int slabNodeCount(const SlabRange& s) {
    const int nx = std::max(0, s.ix1 - s.ix0);
    const int ny = std::max(0, s.iy1 - s.iy0);
    const int nz = std::max(0, s.iz1 - s.iz0);
    return nx * ny * nz;
}
} // namespace

Grid::Grid()
    : SpanX_({0, 0}), SpanY_({0, 0}), SpanZ_({0, 0}),
      DCell_(0), CutOff_(1.0e-15),
      NumCellx_(0), NumCelly_(0), NumCellz_(0),
      NumCell_(0), NumCellxy_(0),
      CenterNumCellx_(0), CenterNumCelly_(0), CenterNumCellz_(0),
      CenterNumCell_(0), CenterNumCellxy_(0),
      NGx_(0), NGy_(0), NGz_(0),
      nb_gridnode_(0), NGxy_(0),
      nb_component_(1),
      use_SGMP_(false),
      nb_centernode_(0),
      fricfa_(0),
      normbody_(0),
      tot_cont_for_({0, 0, 0}) {
    FixS_.fill(0);
}

void Grid::initialize(const Vec3& span_x, const Vec3& span_y, const Vec3& span_z,
                     Real cell_size, int num_components) {
    SpanX_[0] = span_x[0];
    SpanX_[1] = span_x[1];
    SpanY_[0] = span_y[0];
    SpanY_[1] = span_y[1];
    SpanZ_[0] = span_z[0];
    SpanZ_[1] = span_z[1];
    DCell_ = cell_size;
    nb_component_ = num_components;
    
    // Calculate number of cells
    // Match Fortran SetGridData(): NumCell* = int(sp*/DCell + 0.5)
    const Real spx = SpanX_[1] - SpanX_[0];
    const Real spy = SpanY_[1] - SpanY_[0];
    const Real spz = SpanZ_[1] - SpanZ_[0];
    NumCellx_ = static_cast<int>(spx / DCell_ + 0.5);
    NumCelly_ = static_cast<int>(spy / DCell_ + 0.5);
    NumCellz_ = static_cast<int>(spz / DCell_ + 0.5);

    // Snap the upper bounds to the grid, matching:
    //   SpanX(2) = SpanX(1) + NumCellx*DCell  (same for y,z)
    SpanX_[1] = SpanX_[0] + NumCellx_ * DCell_;
    SpanY_[1] = SpanY_[0] + NumCelly_ * DCell_;
    SpanZ_[1] = SpanZ_[0] + NumCellz_ * DCell_;
    
    NumCellxy_ = NumCellx_ * NumCelly_;
    NumCell_ = NumCellx_ * NumCelly_ * NumCellz_;
    
    // Calculate number of nodes
    NGx_ = NumCellx_ + 1;
    NGy_ = NumCelly_ + 1;
    NGz_ = NumCellz_ + 1;
    
    NGxy_ = NGx_ * NGy_;
    nb_gridnode_ = NGx_ * NGy_ * NGz_;
    
    // Calculate auxiliary grid (cell centers)
    // Match Fortran SetGridData:
    //   CenterNumCellx = NumCellx - 1; if ==0 -> 1 (same for y,z)
    //   CenterNumCell   = CenterNumCellxy * CenterNumCellz
    //   nb_centernode   = NumCell
    CenterNumCellx_ = std::max(NumCellx_ - 1, 1);
    CenterNumCelly_ = std::max(NumCelly_ - 1, 1);
    CenterNumCellz_ = std::max(NumCellz_ - 1, 1);
    
    CenterNumCellxy_ = CenterNumCellx_ * CenterNumCelly_;
    CenterNumCell_ = CenterNumCellxy_ * CenterNumCellz_;
    nb_centernode_ = NumCell_;
    
    // Create nodes
    createGridNodes();
    
    // Create cell connectivity
    createCellConnectivity();
    
    // Create auxiliary grid
    createAuxiliaryGrid();
    
    // Allocate grid properties for each component
    grid_list_.resize(nb_component_ * nb_gridnode_);
    
    // Allocate contact properties
    CP_list_.resize(nb_component_ * nb_gridnode_);
    
    std::cout << "Grid initialized:" << std::endl;
    std::cout << "  Domain: [" << SpanX_[0] << ", " << SpanX_[1] << "] x ["
              << SpanY_[0] << ", " << SpanY_[1] << "] x ["
              << SpanZ_[0] << ", " << SpanZ_[1] << "]" << std::endl;
    std::cout << "  Cell size: " << DCell_ << std::endl;
    std::cout << "  Cells: " << NumCellx_ << " x " << NumCelly_ << " x " 
              << NumCellz_ << " = " << NumCell_ << std::endl;
    std::cout << "  Nodes: " << NGx_ << " x " << NGy_ << " x " 
              << NGz_ << " = " << nb_gridnode_ << std::endl;
    std::cout << "  Components: " << nb_component_ << std::endl;
}

void Grid::cellIdToIndices(int cell_id, int& ix, int& iy, int& iz) const {
    iz = cell_id / NumCellxy_;
    const int rem = cell_id - iz * NumCellxy_;
    iy = rem / NumCellx_;
    ix = rem - iy * NumCellx_;
}

void Grid::nodeIdToIndices(int node_id, int& ix, int& iy, int& iz) const {
    iz = node_id / NGxy_;
    const int rem = node_id - iz * NGxy_;
    iy = rem / NGx_;
    ix = rem - iy * NGx_;
}

void Grid::setDecomposition(const DecompInfo& info, int world_rank, int world_size,
                            int ghost_layers) {
    decomp_active_ = true;
    decomp_rank_ = world_rank;
    decomp_size_ = world_size;
    decomp_ghost_ = std::max(ghost_layers, 0);
    decomp_info_ = info;
    decomp_cells_owned_ = info.cells;

    // Local cell region = owned region expanded by ghost layers and clipped to domain.
    decomp_cells_local_.ix0 = std::max(0, decomp_cells_owned_.ix0 - decomp_ghost_);
    decomp_cells_local_.iy0 = std::max(0, decomp_cells_owned_.iy0 - decomp_ghost_);
    decomp_cells_local_.iz0 = std::max(0, decomp_cells_owned_.iz0 - decomp_ghost_);
    decomp_cells_local_.ix1 = std::min(NumCellx_, decomp_cells_owned_.ix1 + decomp_ghost_);
    decomp_cells_local_.iy1 = std::min(NumCelly_, decomp_cells_owned_.iy1 + decomp_ghost_);
    decomp_cells_local_.iz1 = std::min(NumCellz_, decomp_cells_owned_.iz1 + decomp_ghost_);

    // Nodes are one more than cells along each axis. To avoid overlap between
    // neighboring ranks, only the last rank in each direction owns the upper
    // boundary node on that axis.
    decomp_nodes_owned_.ix0 = decomp_cells_owned_.ix0;
    decomp_nodes_owned_.iy0 = decomp_cells_owned_.iy0;
    decomp_nodes_owned_.iz0 = decomp_cells_owned_.iz0;
    if (decomp_info_.coords[0] < decomp_info_.dims[0] - 1) {
        decomp_nodes_owned_.ix1 = std::min(NGx_, decomp_cells_owned_.ix1);
    } else {
        decomp_nodes_owned_.ix1 = std::min(NGx_, decomp_cells_owned_.ix1 + 1);
    }
    if (decomp_info_.coords[1] < decomp_info_.dims[1] - 1) {
        decomp_nodes_owned_.iy1 = std::min(NGy_, decomp_cells_owned_.iy1);
    } else {
        decomp_nodes_owned_.iy1 = std::min(NGy_, decomp_cells_owned_.iy1 + 1);
    }
    if (decomp_info_.coords[2] < decomp_info_.dims[2] - 1) {
        decomp_nodes_owned_.iz1 = std::min(NGz_, decomp_cells_owned_.iz1);
    } else {
        decomp_nodes_owned_.iz1 = std::min(NGz_, decomp_cells_owned_.iz1 + 1);
    }

    decomp_nodes_local_.ix0 = std::max(0, decomp_nodes_owned_.ix0 - decomp_ghost_);
    decomp_nodes_local_.iy0 = std::max(0, decomp_nodes_owned_.iy0 - decomp_ghost_);
    decomp_nodes_local_.iz0 = std::max(0, decomp_nodes_owned_.iz0 - decomp_ghost_);
    decomp_nodes_local_.ix1 = std::min(NGx_, decomp_nodes_owned_.ix1 + decomp_ghost_);
    decomp_nodes_local_.iy1 = std::min(NGy_, decomp_nodes_owned_.iy1 + decomp_ghost_);
    decomp_nodes_local_.iz1 = std::min(NGz_, decomp_nodes_owned_.iz1 + decomp_ghost_);
}

bool Grid::isCellOwned(int cell_id) const {
    if (!decomp_active_) return true;
    int ix, iy, iz;
    cellIdToIndices(cell_id, ix, iy, iz);
    return (ix >= decomp_cells_owned_.ix0 && ix < decomp_cells_owned_.ix1 &&
            iy >= decomp_cells_owned_.iy0 && iy < decomp_cells_owned_.iy1 &&
            iz >= decomp_cells_owned_.iz0 && iz < decomp_cells_owned_.iz1);
}

bool Grid::isNodeOwned(int node_id) const {
    if (!decomp_active_) return true;
    int ix, iy, iz;
    nodeIdToIndices(node_id, ix, iy, iz);
    return (ix >= decomp_nodes_owned_.ix0 && ix < decomp_nodes_owned_.ix1 &&
            iy >= decomp_nodes_owned_.iy0 && iy < decomp_nodes_owned_.iy1 &&
            iz >= decomp_nodes_owned_.iz0 && iz < decomp_nodes_owned_.iz1);
}

bool Grid::isNodeLocal(int node_id) const {
    if (!decomp_active_) return true;
    int ix, iy, iz;
    nodeIdToIndices(node_id, ix, iy, iz);
    return (ix >= decomp_nodes_local_.ix0 && ix < decomp_nodes_local_.ix1 &&
            iy >= decomp_nodes_local_.iy0 && iy < decomp_nodes_local_.iy1 &&
            iz >= decomp_nodes_local_.iz0 && iz < decomp_nodes_local_.iz1);
}

int Grid::ownerRankForCell(int cell_id) const {
    if (!decomp_active_) return 0;
    int ix, iy, iz;
    cellIdToIndices(cell_id, ix, iy, iz);
    return DomainDecomp::ownerRankForCell(ix, iy, iz,
                                          decomp_info_.dims,
                                          NumCellx_, NumCelly_, NumCellz_);
}

void Grid::createGridNodes() {
    node_list_.resize(nb_gridnode_);
    
    for (int iz = 0; iz < NGz_; ++iz) {
        for (int iy = 0; iy < NGy_; ++iy) {
            for (int ix = 0; ix < NGx_; ++ix) {
                int node_id = iz * NGxy_ + iy * NGx_ + ix;
                
                GridNode& node = node_list_[node_id];
                node.setPosition({
                    SpanX_[0] + ix * DCell_,
                    SpanY_[0] + iy * DCell_,
                    SpanZ_[0] + iz * DCell_
                });
                
                // Set boundary types
                if (ix == 0) node.setBoundaryType(0, 1);              // Left boundary
                if (ix == NGx_ - 1) node.setBoundaryType(0, 2);       // Right boundary
                if (iy == 0) node.setBoundaryType(1, 1);
                if (iy == NGy_ - 1) node.setBoundaryType(1, 2);
                if (iz == 0) node.setBoundaryType(2, 1);
                if (iz == NGz_ - 1) node.setBoundaryType(2, 2);
            }
        }
    }
}

void Grid::createCellConnectivity() {
    CellsNode_.resize(NumCell_);
    
    for (int iz = 0; iz < NumCellz_; ++iz) {
        for (int iy = 0; iy < NumCelly_; ++iy) {
            for (int ix = 0; ix < NumCellx_; ++ix) {
                int cell_id = iz * NumCellxy_ + iy * NumCellx_ + ix;
                
                // 8 nodes of hexahedral cell (standard numbering)
                std::array<int, 8> nodes;
                nodes[0] = iz * NGxy_ + iy * NGx_ + ix;
                nodes[1] = iz * NGxy_ + iy * NGx_ + (ix + 1);
                nodes[2] = iz * NGxy_ + (iy + 1) * NGx_ + (ix + 1);
                nodes[3] = iz * NGxy_ + (iy + 1) * NGx_ + ix;
                nodes[4] = (iz + 1) * NGxy_ + iy * NGx_ + ix;
                nodes[5] = (iz + 1) * NGxy_ + iy * NGx_ + (ix + 1);
                nodes[6] = (iz + 1) * NGxy_ + (iy + 1) * NGx_ + (ix + 1);
                nodes[7] = (iz + 1) * NGxy_ + (iy + 1) * NGx_ + ix;
                
                CellsNode_[cell_id] = nodes;
            }
        }
    }
}

void Grid::createAuxiliaryGrid() {
    // Auxiliary grid nodes are at cell centers
    cell_list_.resize(NumCell_);
    
    for (int iz = 0; iz < NumCellz_; ++iz) {
        for (int iy = 0; iy < NumCelly_; ++iy) {
            for (int ix = 0; ix < NumCellx_; ++ix) {
                int cell_id = iz * NumCellxy_ + iy * NumCellx_ + ix;
                
                cell_list_[cell_id].setCenterPosition({
                    SpanX_[0] + (ix + 0.5) * DCell_,
                    SpanY_[0] + (iy + 0.5) * DCell_,
                    SpanZ_[0] + (iz + 0.5) * DCell_
                });
            }
        }
    }
    
    // Auxiliary grid cell connectivity (center cells)
    // NOTE: CenterCellNode_ size is CenterNumCell (not NumCell)
    CenterCellNode_.resize(CenterNumCell_);
    
    for (int iz = 0; iz < CenterNumCellz_; ++iz) {
        for (int iy = 0; iy < CenterNumCelly_; ++iy) {
            for (int ix = 0; ix < CenterNumCellx_; ++ix) {
                int center_id = iz * CenterNumCellxy_ + iy * CenterNumCellx_ + ix;
                
                // The 8 background cells surrounding this center cell
                std::array<int, 8> cells;

                // Match Fortran Grid.f90 construction:
                // CenterCellNode(i,:) are background-cell ids. In 1D/2D cases,
                // some of these can be out of range; Fortran later skips them
                // via bounds checks. Do NOT clamp, mark invalid as -1.
                const int ix0 = ix;
                const int iy0 = iy;
                const int iz0 = iz;
                const int ix1 = ix + 1;
                const int iy1 = iy + 1;
                const int iz1 = iz + 1;

                auto to_cell = [&](int cx, int cy, int cz) -> int {
                    if (cx < 0 || cy < 0 || cz < 0) return -1;
                    if (cx >= NumCellx_ || cy >= NumCelly_ || cz >= NumCellz_) return -1;
                    const int cid = cz * NumCellxy_ + cy * NumCellx_ + cx;
                    if (cid < 0 || cid >= NumCell_) return -1;
                    return cid;
                };

                cells[0] = to_cell(ix0, iy0, iz0);
                cells[1] = to_cell(ix1, iy0, iz0);
                cells[2] = to_cell(ix1, iy1, iz0);
                cells[3] = to_cell(ix0, iy1, iz0);
                cells[4] = to_cell(ix0, iy0, iz1);
                cells[5] = to_cell(ix1, iy0, iz1);
                cells[6] = to_cell(ix1, iy1, iz1);
                cells[7] = to_cell(ix0, iy1, iz1);
                
                CenterCellNode_[center_id] = cells;
            }
        }
    }
    
    // Allocate auxiliary grid properties (Fortran allocates to nb_centernode = NumCell)
    cellp_list_.resize(nb_centernode_);
}

int Grid::findCell(const Vec3& position) const {
    // Check if position is inside domain
    if (position[0] < SpanX_[0] || position[0] > SpanX_[1] ||
        position[1] < SpanY_[0] || position[1] > SpanY_[1] ||
        position[2] < SpanZ_[0] || position[2] > SpanZ_[1]) {
        return -1;
    }
    
    int ix = static_cast<int>((position[0] - SpanX_[0]) / DCell_);
    int iy = static_cast<int>((position[1] - SpanY_[0]) / DCell_);
    int iz = static_cast<int>((position[2] - SpanZ_[0]) / DCell_);
    
    int cell_id = iz * NumCellxy_ + iy * NumCellx_ + ix;
    
    if (cell_id >= NumCell_ || cell_id < 0) {
        return -1;
    }
    
    return cell_id;
}

int Grid::findCenterCell(const Vec3& position) const {
    // For auxiliary grid (cell centers)
    
    int ix = static_cast<int>((position[0] - SpanX_[0] - 0.5 * DCell_) / DCell_);
    int iy = static_cast<int>((position[1] - SpanY_[0] - 0.5 * DCell_) / DCell_);
    int iz = static_cast<int>((position[2] - SpanZ_[0] - 0.5 * DCell_) / DCell_);
    
    int center_id = iz * CenterNumCellxy_ + iy * CenterNumCellx_ + ix;
    
    // NOTE: center_id is an index into CenterCellNode_ whose size is CenterNumCell_
    if (ix < 0 || iy < 0 || iz < 0 || center_id >= CenterNumCell_ || center_id < 0) {
        return -1;
    }
    
    return center_id;
}

Vec3 Grid::calculateNaturalCoords(const Vec3& position, int cell_id) const {
    // Calculate natural coordinates [-1, 1]^3 within cell
    
    if (cell_id < 0 || cell_id >= NumCell_) {
        return {0, 0, 0};
    }
    
    Vec3 cell_center = cell_list_[cell_id].getCenterPosition();
    Real half_size = 0.5 * DCell_;
    
    Vec3 natural_coords;
    natural_coords[0] = (position[0] - cell_center[0]) / half_size;
    natural_coords[1] = (position[1] - cell_center[1]) / half_size;
    natural_coords[2] = (position[2] - cell_center[2]) / half_size;
    
    return natural_coords;
}

void Grid::resetGridProperties() {
    for (auto& prop : grid_list_) {
        prop.reset();
    }
}

void Grid::resetAuxiliaryGrid() {
    for (auto& prop : cellp_list_) {
        prop.reset();
    }
}

void Grid::setFixedBoundary(const std::array<int, 6>& fixed) {
    FixS_ = fixed;
    
    // Apply boundary conditions to nodes
    for (int iz = 0; iz < NGz_; ++iz) {
        for (int iy = 0; iy < NGy_; ++iy) {
            for (int ix = 0; ix < NGx_; ++ix) {
                int node_id = iz * NGxy_ + iy * NGx_ + ix;
                GridNode& node = node_list_[node_id];

                const bool on_xmin = (ix == 0) || (extended_bc_layers_ && ix == 1);
                const bool on_xmax = (ix == NGx_ - 1) || (extended_bc_layers_ && ix == NGx_ - 2);
                const bool on_ymin = (iy == 0) || (extended_bc_layers_ && iy == 1);
                const bool on_ymax = (iy == NGy_ - 1) || (extended_bc_layers_ && iy == NGy_ - 2);
                const bool on_zmin = (iz == 0) || (extended_bc_layers_ && iz == 1);
                const bool on_zmax = (iz == NGz_ - 1) || (extended_bc_layers_ && iz == NGz_ - 2);

                // Convention matches Fortran: 0 = interior, 1 = min-side boundary, 2 = max-side boundary
                node.setBoundaryType(0, 0);
                node.setBoundaryType(1, 0);
                node.setBoundaryType(2, 0);

                // Match Fortran Grid.f90: only set bd_type on faces where FixS is nonzero.
                // For SGMP, Fortran also marks the second layer (ix==2 / NGx-1 in 1-based indexing).
                const bool sgmp_bd_layer2 = use_SGMP_;

                if (fixed[0] != 0) {
                    if (ix == 0) node.setBoundaryType(0, 1);
                    if (sgmp_bd_layer2 && ix == 1) node.setBoundaryType(0, 1);
                }
                if (fixed[1] != 0) {
                    if (ix == NGx_ - 1) node.setBoundaryType(0, 2);
                    if (sgmp_bd_layer2 && ix == NGx_ - 2) node.setBoundaryType(0, 2);
                }
                if (fixed[2] != 0) {
                    if (iy == 0) node.setBoundaryType(1, 1);
                    if (sgmp_bd_layer2 && iy == 1) node.setBoundaryType(1, 1);
                }
                if (fixed[3] != 0) {
                    if (iy == NGy_ - 1) node.setBoundaryType(1, 2);
                    if (sgmp_bd_layer2 && iy == NGy_ - 2) node.setBoundaryType(1, 2);
                }
                if (fixed[4] != 0) {
                    if (iz == 0) node.setBoundaryType(2, 1);
                    if (sgmp_bd_layer2 && iz == 1) node.setBoundaryType(2, 1);
                }
                if (fixed[5] != 0) {
                    if (iz == NGz_ - 1) node.setBoundaryType(2, 2);
                    if (sgmp_bd_layer2 && iz == NGz_ - 2) node.setBoundaryType(2, 2);
                }
                
                // Check each face
                if (on_xmin && fixed[0] > 0) {
                    if (fixed[0] == 1) {
                        // Fully fixed (all directions)
                        node.setFixedX(true);
                        node.setFixedY(true);
                        node.setFixedZ(true);
                    } else if (fixed[0] == 2) {
                        // Roller/Slip boundary - only fix normal direction (X)
                        node.setFixedX(true);
                    }
                }
                if (on_xmax && fixed[1] > 0) {
                    if (fixed[1] == 1) {
                        // Fully fixed (all directions)
                        node.setFixedX(true);
                        node.setFixedY(true);
                        node.setFixedZ(true);
                    } else if (fixed[1] == 2) {
                        // Roller/Slip boundary - only fix normal direction (X)
                        node.setFixedX(true);
                    }
                }
                if (on_ymin && fixed[2] > 0) {
                    if (fixed[2] == 1) {
                        // Fully fixed (all directions)
                        node.setFixedX(true);
                        node.setFixedY(true);
                        node.setFixedZ(true);
                    } else if (fixed[2] == 2) {
                        // Roller/Slip boundary - only fix normal direction (Y)
                        node.setFixedY(true);
                    }
                }
                if (on_ymax && fixed[3] > 0) {
                    if (fixed[3] == 1) {
                        // Fully fixed (all directions)
                        node.setFixedX(true);
                        node.setFixedY(true);
                        node.setFixedZ(true);
                    } else if (fixed[3] == 2) {
                        // Roller/Slip boundary - only fix normal direction (Y)
                        node.setFixedY(true);
                    }
                }
                if (on_zmin && fixed[4] > 0) {
                    if (fixed[4] == 1) {
                        // Fully fixed (all directions)
                        node.setFixedX(true);
                        node.setFixedY(true);
                        node.setFixedZ(true);
                    } else if (fixed[4] == 2) {
                        // Roller/Slip boundary - only fix normal direction (Z)
                        node.setFixedZ(true);
                    }
                }
                if (on_zmax && fixed[5] > 0) {
                    if (fixed[5] == 1) {
                        // Fully fixed (all directions)
                        node.setFixedX(true);
                        node.setFixedY(true);
                        node.setFixedZ(true);
                    } else if (fixed[5] == 2) {
                        // Roller/Slip boundary - only fix normal direction (Z)
                        node.setFixedZ(true);
                    }
                }
            }
        }
    }
}

void Grid::allreduceNodeFields(bool reduce_mass_mom,
                               bool reduce_force,
                               bool reduce_pressure_volume) {
#if defined(MPM3D_USE_MPI)
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (!mpi_initialized) return;

    int mpi_size = 1;
    MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);
    if (mpi_size <= 1) return;

    const int fields = 8; // mass, px, py, pz, fx, fy, fz, pressure, volume
    const int stride = 9; // 9 entries to include volume
    std::vector<double> buf(static_cast<size_t>(nb_component_) * nb_gridnode_ * stride, 0.0);
    std::vector<double> out(buf.size(), 0.0);

    for (int comp = 1; comp <= nb_component_; ++comp) {
        const int comp_idx = comp - 1;
        for (int node = 0; node < nb_gridnode_; ++node) {
            const auto &gp = getNodeProperty(comp, node);
            const size_t base = (static_cast<size_t>(comp_idx) * nb_gridnode_ + node) * stride;
            if (reduce_mass_mom) {
                buf[base + 0] = gp.getMass();
                const Vec3 mom = gp.getMomentum();
                buf[base + 1] = mom[0];
                buf[base + 2] = mom[1];
                buf[base + 3] = mom[2];
            }
            if (reduce_force) {
                const Vec3 f = gp.getForce();
                buf[base + 4] = f[0];
                buf[base + 5] = f[1];
                buf[base + 6] = f[2];
            }
            if (reduce_pressure_volume) {
                buf[base + 7] = gp.getPressure();
                buf[base + 8] = gp.getVolume();
            }
        }
    }

    MPI_Allreduce(buf.data(), out.data(), static_cast<int>(out.size()),
                  MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

    for (int comp = 1; comp <= nb_component_; ++comp) {
        const int comp_idx = comp - 1;
        for (int node = 0; node < nb_gridnode_; ++node) {
            auto &gp = getNodeProperty(comp, node);
            const size_t base = (static_cast<size_t>(comp_idx) * nb_gridnode_ + node) * stride;
            if (reduce_mass_mom) {
                gp.setMass(static_cast<Real>(out[base + 0]));
                gp.setMomentum({static_cast<Real>(out[base + 1]),
                                static_cast<Real>(out[base + 2]),
                                static_cast<Real>(out[base + 3])});
            }
            if (reduce_force) {
                gp.setForce({static_cast<Real>(out[base + 4]),
                             static_cast<Real>(out[base + 5]),
                             static_cast<Real>(out[base + 6])});
            }
            if (reduce_pressure_volume) {
                gp.setPressure(static_cast<Real>(out[base + 7]));
                gp.setVolume(static_cast<Real>(out[base + 8]));
            }
        }
    }
#else
    (void)reduce_mass_mom;
    (void)reduce_force;
    (void)reduce_pressure_volume;
#endif
}

void Grid::allreduceNodeMomentum() {
#if defined(MPM3D_USE_MPI)
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (!mpi_initialized) return;

    int mpi_size = 1;
    MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);
    if (mpi_size <= 1) return;

    const int stride = 3; // px, py, pz
    std::vector<double> buf(static_cast<size_t>(nb_component_) * nb_gridnode_ * stride, 0.0);
    std::vector<double> out(buf.size(), 0.0);

    for (int comp = 1; comp <= nb_component_; ++comp) {
        const int comp_idx = comp - 1;
        for (int node = 0; node < nb_gridnode_; ++node) {
            const auto &gp = getNodeProperty(comp, node);
            const size_t base = (static_cast<size_t>(comp_idx) * nb_gridnode_ + node) * stride;
            const Vec3 mom = gp.getMomentum();
            buf[base + 0] = mom[0];
            buf[base + 1] = mom[1];
            buf[base + 2] = mom[2];
        }
    }

    MPI_Allreduce(buf.data(), out.data(), static_cast<int>(out.size()),
                  MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

    for (int comp = 1; comp <= nb_component_; ++comp) {
        const int comp_idx = comp - 1;
        for (int node = 0; node < nb_gridnode_; ++node) {
            auto &gp = getNodeProperty(comp, node);
            const size_t base = (static_cast<size_t>(comp_idx) * nb_gridnode_ + node) * stride;
            gp.setMomentum({static_cast<Real>(out[base + 0]),
                            static_cast<Real>(out[base + 1]),
                            static_cast<Real>(out[base + 2])});
        }
    }
#endif
}

void Grid::exchangeNodeFields(bool reduce_mass_mom,
                              bool reduce_force,
                              bool reduce_pressure_volume) {
#if defined(MPM3D_USE_MPI)
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (!mpi_initialized) return;

    int mpi_size = 1;
    MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);
    if (mpi_size <= 1) return;

    const int ghost = decomp_ghost_;
    if (ghost <= 0) return;

    const int fields =
        (reduce_mass_mom ? 4 : 0) + (reduce_force ? 3 : 0) + (reduce_pressure_volume ? 2 : 0);

    auto exchange_dir = [&](int dx, int dy, int dz) {
        const int neigh = neighborRank(decomp_info_, dx, dy, dz);
        if (neigh == MPI_PROC_NULL) return;

        SlabRange ghost_slab, owned_slab;
        slabRangesForDir(decomp_nodes_owned_, ghost, dx, dy, dz, ghost_slab, owned_slab);

        const int slab_nodes = slabNodeCount(ghost_slab);
        if (slab_nodes <= 0) return;

        std::vector<double> sendbuf(static_cast<size_t>(nb_component_) * slab_nodes * fields, 0.0);
        std::vector<double> recvbuf(static_cast<size_t>(nb_component_) * slab_nodes * fields, 0.0);

        // Pack ghost slab to send to owner neighbor
        for (int comp = 1; comp <= nb_component_; ++comp) {
            const int comp_idx = comp - 1;
            size_t idx = 0;
            for (int iz = ghost_slab.iz0; iz < ghost_slab.iz1; ++iz) {
                for (int iy = ghost_slab.iy0; iy < ghost_slab.iy1; ++iy) {
                    for (int ix = ghost_slab.ix0; ix < ghost_slab.ix1; ++ix) {
                        const int node_id = iz * NGxy_ + iy * NGx_ + ix;
                        const auto &gp = getNodeProperty(comp, node_id);
                        size_t base = (static_cast<size_t>(comp_idx) * slab_nodes + idx) * fields;
                        int o = 0;
                        if (reduce_mass_mom) {
                            const Vec3 mom = gp.getMomentum();
                            sendbuf[base + o++] = gp.getMass();
                            sendbuf[base + o++] = mom[0];
                            sendbuf[base + o++] = mom[1];
                            sendbuf[base + o++] = mom[2];
                        }
                        if (reduce_force) {
                            const Vec3 f = gp.getForce();
                            sendbuf[base + o++] = f[0];
                            sendbuf[base + o++] = f[1];
                            sendbuf[base + o++] = f[2];
                        }
                        if (reduce_pressure_volume) {
                            sendbuf[base + o++] = gp.getPressure();
                            sendbuf[base + o++] = gp.getVolume();
                        }
                        ++idx;
                    }
                }
            }
        }

        MPI_Sendrecv(sendbuf.data(), static_cast<int>(sendbuf.size()), MPI_DOUBLE, neigh, 100,
                     recvbuf.data(), static_cast<int>(recvbuf.size()), MPI_DOUBLE, neigh, 100,
                     MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        // Reduce received ghost contributions into owned boundary
        for (int comp = 1; comp <= nb_component_; ++comp) {
            const int comp_idx = comp - 1;
            size_t idx = 0;
            for (int iz = owned_slab.iz0; iz < owned_slab.iz1; ++iz) {
                for (int iy = owned_slab.iy0; iy < owned_slab.iy1; ++iy) {
                    for (int ix = owned_slab.ix0; ix < owned_slab.ix1; ++ix) {
                        const int node_id = iz * NGxy_ + iy * NGx_ + ix;
                        auto &gp = getNodeProperty(comp, node_id);
                        size_t base = (static_cast<size_t>(comp_idx) * slab_nodes + idx) * fields;
                        int o = 0;
                        if (reduce_mass_mom) {
                            const Real mass = static_cast<Real>(recvbuf[base + o++]);
                            const Vec3 mom = {static_cast<Real>(recvbuf[base + o++]),
                                              static_cast<Real>(recvbuf[base + o++]),
                                              static_cast<Real>(recvbuf[base + o++])};
                            gp.setMass(gp.getMass() + mass);
                            gp.setMomentum(gp.getMomentum() + mom);
                        }
                        if (reduce_force) {
                            const Vec3 f = {static_cast<Real>(recvbuf[base + o++]),
                                            static_cast<Real>(recvbuf[base + o++]),
                                            static_cast<Real>(recvbuf[base + o++])};
                            gp.setForce(gp.getForce() + f);
                        }
                        if (reduce_pressure_volume) {
                            const Real p = static_cast<Real>(recvbuf[base + o++]);
                            const Real v = static_cast<Real>(recvbuf[base + o++]);
                            gp.setPressure(gp.getPressure() + p);
                            gp.setVolume(gp.getVolume() + v);
                        }
                        ++idx;
                    }
                }
            }
        }

        // Sync back owned boundary to neighbor ghost
        std::vector<double> sendbuf2(static_cast<size_t>(nb_component_) * slab_nodes * fields, 0.0);
        std::vector<double> recvbuf2(static_cast<size_t>(nb_component_) * slab_nodes * fields, 0.0);

        for (int comp = 1; comp <= nb_component_; ++comp) {
            const int comp_idx = comp - 1;
            size_t idx = 0;
            for (int iz = owned_slab.iz0; iz < owned_slab.iz1; ++iz) {
                for (int iy = owned_slab.iy0; iy < owned_slab.iy1; ++iy) {
                    for (int ix = owned_slab.ix0; ix < owned_slab.ix1; ++ix) {
                        const int node_id = iz * NGxy_ + iy * NGx_ + ix;
                        const auto &gp = getNodeProperty(comp, node_id);
                        size_t base = (static_cast<size_t>(comp_idx) * slab_nodes + idx) * fields;
                        int o = 0;
                        if (reduce_mass_mom) {
                            const Vec3 mom = gp.getMomentum();
                            sendbuf2[base + o++] = gp.getMass();
                            sendbuf2[base + o++] = mom[0];
                            sendbuf2[base + o++] = mom[1];
                            sendbuf2[base + o++] = mom[2];
                        }
                        if (reduce_force) {
                            const Vec3 f = gp.getForce();
                            sendbuf2[base + o++] = f[0];
                            sendbuf2[base + o++] = f[1];
                            sendbuf2[base + o++] = f[2];
                        }
                        if (reduce_pressure_volume) {
                            sendbuf2[base + o++] = gp.getPressure();
                            sendbuf2[base + o++] = gp.getVolume();
                        }
                        ++idx;
                    }
                }
            }
        }

        MPI_Sendrecv(sendbuf2.data(), static_cast<int>(sendbuf2.size()), MPI_DOUBLE, neigh, 200,
                     recvbuf2.data(), static_cast<int>(recvbuf2.size()), MPI_DOUBLE, neigh, 200,
                     MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        for (int comp = 1; comp <= nb_component_; ++comp) {
            const int comp_idx = comp - 1;
            size_t idx = 0;
            for (int iz = ghost_slab.iz0; iz < ghost_slab.iz1; ++iz) {
                for (int iy = ghost_slab.iy0; iy < ghost_slab.iy1; ++iy) {
                    for (int ix = ghost_slab.ix0; ix < ghost_slab.ix1; ++ix) {
                        const int node_id = iz * NGxy_ + iy * NGx_ + ix;
                        auto &gp = getNodeProperty(comp, node_id);
                        size_t base = (static_cast<size_t>(comp_idx) * slab_nodes + idx) * fields;
                        int o = 0;
                        if (reduce_mass_mom) {
                            const Real mass = static_cast<Real>(recvbuf2[base + o++]);
                            const Vec3 mom = {static_cast<Real>(recvbuf2[base + o++]),
                                              static_cast<Real>(recvbuf2[base + o++]),
                                              static_cast<Real>(recvbuf2[base + o++])};
                            gp.setMass(mass);
                            gp.setMomentum(mom);
                        }
                        if (reduce_force) {
                            const Vec3 f = {static_cast<Real>(recvbuf2[base + o++]),
                                            static_cast<Real>(recvbuf2[base + o++]),
                                            static_cast<Real>(recvbuf2[base + o++])};
                            gp.setForce(f);
                        }
                        if (reduce_pressure_volume) {
                            const Real p = static_cast<Real>(recvbuf2[base + o++]);
                            const Real v = static_cast<Real>(recvbuf2[base + o++]);
                            gp.setPressure(p);
                            gp.setVolume(v);
                        }
                        ++idx;
                    }
                }
            }
        }
    };

    exchange_dir(-1, 0, 0);
    exchange_dir(1, 0, 0);
    exchange_dir(0, -1, 0);
    exchange_dir(0, 1, 0);
    exchange_dir(0, 0, -1);
    exchange_dir(0, 0, 1);
#else
    (void)reduce_mass_mom;
    (void)reduce_force;
    (void)reduce_pressure_volume;
#endif
}

void Grid::exchangeNodeMomentum() {
#if defined(MPM3D_USE_MPI)
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (!mpi_initialized) return;

    int mpi_size = 1;
    MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);
    if (mpi_size <= 1) return;

    const int ghost = decomp_ghost_;
    if (ghost <= 0) return;

    const int fields = 3; // px, py, pz

    auto exchange_dir = [&](int dx, int dy, int dz) {
        const int neigh = neighborRank(decomp_info_, dx, dy, dz);
        if (neigh == MPI_PROC_NULL) return;

        SlabRange ghost_slab, owned_slab;
        slabRangesForDir(decomp_nodes_owned_, ghost, dx, dy, dz, ghost_slab, owned_slab);

        const int slab_nodes = slabNodeCount(ghost_slab);
        if (slab_nodes <= 0) return;

        std::vector<double> sendbuf(static_cast<size_t>(nb_component_) * slab_nodes * fields, 0.0);
        std::vector<double> recvbuf(static_cast<size_t>(nb_component_) * slab_nodes * fields, 0.0);

        for (int comp = 1; comp <= nb_component_; ++comp) {
            const int comp_idx = comp - 1;
            size_t idx = 0;
            for (int iz = ghost_slab.iz0; iz < ghost_slab.iz1; ++iz) {
                for (int iy = ghost_slab.iy0; iy < ghost_slab.iy1; ++iy) {
                    for (int ix = ghost_slab.ix0; ix < ghost_slab.ix1; ++ix) {
                        const int node_id = iz * NGxy_ + iy * NGx_ + ix;
                        const auto &gp = getNodeProperty(comp, node_id);
                        const Vec3 mom = gp.getMomentum();
                        size_t base = (static_cast<size_t>(comp_idx) * slab_nodes + idx) * fields;
                        sendbuf[base + 0] = mom[0];
                        sendbuf[base + 1] = mom[1];
                        sendbuf[base + 2] = mom[2];
                        ++idx;
                    }
                }
            }
        }

        MPI_Sendrecv(sendbuf.data(), static_cast<int>(sendbuf.size()), MPI_DOUBLE, neigh, 110,
                     recvbuf.data(), static_cast<int>(recvbuf.size()), MPI_DOUBLE, neigh, 110,
                     MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        for (int comp = 1; comp <= nb_component_; ++comp) {
            const int comp_idx = comp - 1;
            size_t idx = 0;
            for (int iz = owned_slab.iz0; iz < owned_slab.iz1; ++iz) {
                for (int iy = owned_slab.iy0; iy < owned_slab.iy1; ++iy) {
                    for (int ix = owned_slab.ix0; ix < owned_slab.ix1; ++ix) {
                        const int node_id = iz * NGxy_ + iy * NGx_ + ix;
                        auto &gp = getNodeProperty(comp, node_id);
                        size_t base = (static_cast<size_t>(comp_idx) * slab_nodes + idx) * fields;
                        Vec3 mom = {static_cast<Real>(recvbuf[base + 0]),
                                    static_cast<Real>(recvbuf[base + 1]),
                                    static_cast<Real>(recvbuf[base + 2])};
                        gp.setMomentum(gp.getMomentum() + mom);
                        ++idx;
                    }
                }
            }
        }

        std::vector<double> sendbuf2(static_cast<size_t>(nb_component_) * slab_nodes * fields, 0.0);
        std::vector<double> recvbuf2(static_cast<size_t>(nb_component_) * slab_nodes * fields, 0.0);

        for (int comp = 1; comp <= nb_component_; ++comp) {
            const int comp_idx = comp - 1;
            size_t idx = 0;
            for (int iz = owned_slab.iz0; iz < owned_slab.iz1; ++iz) {
                for (int iy = owned_slab.iy0; iy < owned_slab.iy1; ++iy) {
                    for (int ix = owned_slab.ix0; ix < owned_slab.ix1; ++ix) {
                        const int node_id = iz * NGxy_ + iy * NGx_ + ix;
                        const auto &gp = getNodeProperty(comp, node_id);
                        const Vec3 mom = gp.getMomentum();
                        size_t base = (static_cast<size_t>(comp_idx) * slab_nodes + idx) * fields;
                        sendbuf2[base + 0] = mom[0];
                        sendbuf2[base + 1] = mom[1];
                        sendbuf2[base + 2] = mom[2];
                        ++idx;
                    }
                }
            }
        }

        MPI_Sendrecv(sendbuf2.data(), static_cast<int>(sendbuf2.size()), MPI_DOUBLE, neigh, 210,
                     recvbuf2.data(), static_cast<int>(recvbuf2.size()), MPI_DOUBLE, neigh, 210,
                     MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        for (int comp = 1; comp <= nb_component_; ++comp) {
            const int comp_idx = comp - 1;
            size_t idx = 0;
            for (int iz = ghost_slab.iz0; iz < ghost_slab.iz1; ++iz) {
                for (int iy = ghost_slab.iy0; iy < ghost_slab.iy1; ++iy) {
                    for (int ix = ghost_slab.ix0; ix < ghost_slab.ix1; ++ix) {
                        const int node_id = iz * NGxy_ + iy * NGx_ + ix;
                        auto &gp = getNodeProperty(comp, node_id);
                        size_t base = (static_cast<size_t>(comp_idx) * slab_nodes + idx) * fields;
                        Vec3 mom = {static_cast<Real>(recvbuf2[base + 0]),
                                    static_cast<Real>(recvbuf2[base + 1]),
                                    static_cast<Real>(recvbuf2[base + 2])};
                        gp.setMomentum(mom);
                        ++idx;
                    }
                }
            }
        }
    };

    exchange_dir(-1, 0, 0);
    exchange_dir(1, 0, 0);
    exchange_dir(0, -1, 0);
    exchange_dir(0, 1, 0);
    exchange_dir(0, 0, -1);
    exchange_dir(0, 0, 1);
#endif
}

} // namespace mpm3d
