// UpdateStep.cpp - Core MPM Algorithm Implementation
// Translated from update_step.f90

#include "UpdateStep.hpp"
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <type_traits>
#if defined(MPM3D_USE_MPI)
#include <mpi.h>
#endif
#if defined(MPM3D_USE_OPENMP)
#include <omp.h>
#endif

namespace mpm3d {

UpdateStep::UpdateStep()
    : particles_(nullptr), bodies_(nullptr), grid_(nullptr),
      materials_(nullptr), shape_func_(nullptr), constitution_(nullptr),
      dt_(0.0), dt_scale_(1.0), current_time_(0.0),
      cutoff_(1.0e-15), // Will be recalculated during initialization
      kinetic_energy_(0.0), internal_energy_(0.0), momentum_({0, 0, 0}),
      last_max_vp_(0.0), last_dt_min_(0.0), last_max_vg_(0.0),
      USL_(true), USF_(false), MUSL_(false), TLMPM_(false), GIMP_(false),
      Bspline_(false), SGMP_(false), contact_enabled_(false), UpdateVbyFp_(false),
      QuasiLoad_(false), dd_filter_particles_(false), dd_allreduce_(false),
      dd_migrate_particles_(false), dd_strict_(false),
      dd_exchange_nodes_(false), dd_repro_mode_(false),
      dd_balance_replica_(false) {
  
  // Pre-allocate arrays for performance
  infl_nodes_.reserve(MAX_INFL_NODES);
  shape_values_.reserve(MAX_INFL_NODES);
  shape_gradients_.reserve(MAX_INFL_NODES);
  const size_t soa_hint = 4096;
  soa_pid_.reserve(soa_hint);
  soa_comp_off_.reserve(soa_hint);
  soa_mass_.reserve(soa_hint);
  soa_vx_.reserve(soa_hint);
  soa_vy_.reserve(soa_hint);
  soa_vz_.reserve(soa_hint);
  soa_fx0_.reserve(soa_hint);
  soa_fx1_.reserve(soa_hint);
  soa_fx2_.reserve(soa_hint);
  soa_s0_.reserve(soa_hint);
  soa_s1_.reserve(soa_hint);
  soa_s2_.reserve(soa_hint);
  soa_s3_.reserve(soa_hint);
  soa_s4_.reserve(soa_hint);
  soa_s5_.reserve(soa_hint);
  soa_vol_.reserve(soa_hint);
  
  // Initialize influence domain
  influence_domain_.reserve(MAX_INFL_NODES);
}

void UpdateStep::calculateCutoff() {
  // Calculate cutoff value using the same formula as Fortran's SetMaterial
  // CutOff = (sum of all material densities) * DCell^3 * 1e-5 /
  // number_of_materials

  if (!materials_ || !grid_) {
    std::cerr << "Warning: Cannot calculate cutoff - materials or grid not "
                 "initialized"
              << std::endl;
    return;
  }

  if (materials_->getNumMaterials() == 0) {
    std::cerr << "Warning: No materials defined for cutoff calculation"
              << std::endl;
    return;
  }

  // Sum all material densities
  Real density_sum = 0.0;
  for (size_t i = 0; i < materials_->getNumMaterials(); ++i) {
    density_sum += materials_->getMaterial(static_cast<int>(i + 1)).getDensity();
  }

  // Get cell volume (DCell^3)
  Real cell_size = grid_->getCellSize();
  Real cell_volume = cell_size * cell_size * cell_size;

  // Calculate cutoff using Fortran formula
  int num_materials = static_cast<int>(materials_->getNumMaterials());
  cutoff_ = density_sum * cell_volume * 1.0e-5 / num_materials;
}

void UpdateStep::initialize(ParticleList &particles, BodyList &bodies,
                            Grid &grid, MaterialList &materials,
                            ShapeFunction &shape_func,
                            ConstitutionModel &constitution) {
  particles_ = &particles;
  bodies_ = &bodies;
  grid_ = &grid;
  materials_ = &materials;
  shape_func_ = &shape_func;
  constitution_ = &constitution;

  // Calculate cutoff value using Fortran formula
  calculateCutoff();

  const char *dd_env = std::getenv("MPM3D_MPI_DD");
  dd_filter_particles_ = (dd_env && std::string(dd_env) != "0");
  const char *ar_env = std::getenv("MPM3D_MPI_ALLREDUCE");
  dd_allreduce_ = (ar_env && std::string(ar_env) != "0");
  const char *strict_env = std::getenv("MPM3D_MPI_STRICT");
  dd_strict_ = (strict_env && std::string(strict_env) != "0");
  const char *mig_env = std::getenv("MPM3D_MPI_MIGRATE");
  if (mig_env) {
    dd_migrate_particles_ = (std::string(mig_env) != "0");
  } else {
    // Default to no migration for deterministic/stable DD behavior.
    // Enable explicitly with MPM3D_MPI_MIGRATE=1.
    dd_migrate_particles_ = false;
  }
  const char *ex_env = std::getenv("MPM3D_MPI_EXCHANGE");
  dd_exchange_nodes_ = (ex_env && std::string(ex_env) != "0");
  const char *repro_env = std::getenv("MPM3D_MPI_REPRO");
  if (repro_env) {
    dd_repro_mode_ = (std::string(repro_env) != "0");
  } else {
    // Default to performance mode; enable deterministic reductions explicitly
    // with MPM3D_MPI_REPRO=1 when exact serial matching is required.
    dd_repro_mode_ = false;
  }
  const char *bal_env = std::getenv("MPM3D_MPI_BALANCE_REPLICA");
  dd_balance_replica_ = (bal_env && std::string(bal_env) != "0");
#if defined(MPM3D_USE_MPI)
  if (dd_strict_) {
    dd_filter_particles_ = false;
    dd_allreduce_ = false;
    dd_migrate_particles_ = false;
    dd_exchange_nodes_ = false;
    dd_repro_mode_ = false;
    dd_balance_replica_ = false;
  }
#endif
#if defined(MPM3D_USE_MPI)
  int mpi_initialized = 0;
  MPI_Initialized(&mpi_initialized);
  if (mpi_initialized) {
    int mpi_rank = 0;
    int mpi_size = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &mpi_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);
    if (mpi_size <= 1) {
      dd_filter_particles_ = false;
      dd_allreduce_ = false;
      dd_migrate_particles_ = false;
      dd_exchange_nodes_ = false;
      dd_repro_mode_ = false;
      dd_balance_replica_ = false;
    }
    const char *diag_env = std::getenv("MPM3D_MPI_DEBUG");
    const bool mpi_diag = (diag_env && std::string(diag_env) != "0");
    if (mpi_diag) {
      std::cout << "MPI_DEBUG rank=" << mpi_rank
                << " size=" << mpi_size
                << " dd_filter=" << (dd_filter_particles_ ? 1 : 0)
                << " dd_allreduce=" << (dd_allreduce_ ? 1 : 0)
                << " dd_migrate=" << (dd_migrate_particles_ ? 1 : 0)
                << " dd_exchange=" << (dd_exchange_nodes_ ? 1 : 0)
                << " dd_repro=" << (dd_repro_mode_ ? 1 : 0)
                << " dd_balance_replica=" << (dd_balance_replica_ ? 1 : 0)
                << " dd_strict=" << (dd_strict_ ? 1 : 0)
                << std::endl;
    }
  }
#endif
}

void UpdateStep::resetGridData() {
  // Reset grid momentum AND mass to test which is correct
  for (int comp = 1; comp <= grid_->getNumComponents(); ++comp) {
#if defined(MPM3D_USE_OPENMP)
    #pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < grid_->getNumNodes(); ++i) {
      auto &node_prop = grid_->getNodeProperty(comp, i);
      node_prop.setMass(0.0);
      node_prop.setMomentum({0, 0, 0});
      node_prop.setForce({0, 0, 0});
    }
  }
}

// Grid Momentum Initial - P2G Transfer

// ============================================================================
// Grid Momentum Initial - P2G Transfer
// ============================================================================

void UpdateStep::gridMomentumInitial() {
  // Purpose: Map particle mass and momentum to grid nodes
  // Matches Fortran GridMomentumInitial in update_step.f90
  if (dd_migrate_particles_) {
    migrateParticles(false);
  }

  // Reset grid data (equivalent to Fortran lines 310-314)
  // Note: This is the ONLY place where grid data should be reset
  // for standard MPM steps. Do NOT call resetGridData() elsewhere.
  resetGridData();

  // Reset internal energy accumulator (matches Fortran line 74: EngInternal = 0.0)
  internal_energy_ = 0.0;

  if (SGMP_) {
    grid_->resetAuxiliaryGrid();
  }

  // Calculate particle grid coordinates
  particleInitial();

  if (SGMP_) {
#if defined(MPM3D_USE_OPENMP)
    struct LocalCellP2G {
      long double mass = 0.0L;
      long double mom[3] = {0.0L, 0.0L, 0.0L};
    };
    const int ncenter = grid_->getNumCenterCells();
    const int nthreads = dd_repro_mode_ ? 1 : omp_get_max_threads();
    std::vector<LocalCellP2G> accum(static_cast<size_t>(nthreads) * ncenter);

    #pragma omp parallel num_threads(nthreads)
    {
      const int tid = omp_get_thread_num();
      LocalCellP2G* local = accum.data() + static_cast<size_t>(tid) * ncenter;
      InfluenceDomain influence;
      influence.reserve(MAX_INFL_NODES);

      for (size_t b = 0; b < bodies_->size(); ++b) {
        const Body &body = (*bodies_)[b];
        int par_begin = body.getParticleBegin();
        int par_end = body.getParticleEnd();

        #pragma omp for schedule(static)
        for (int p = par_begin; p < par_end; ++p) {
          Particle &pt = (*particles_)[p];
          if (!isParticleLocal(pt)) {
            continue;
          }

          int center_cell = pt.getCenterCell();
          if (center_cell < 0)
            continue;

          Real mp = pt.getMass();
          Vec3 vxp = pt.getVelocity();

          influence.clear();
          shape_func_->evaluateAuxiliary(pt, *grid_, influence.node_indices,
                                         influence.shape_values,
                                         influence.shape_gradients);

          for (size_t n = 0; n < influence.size(); ++n) {
            int node_id = influence.node_indices[n];
            if (node_id < 0 || node_id >= ncenter)
              continue;

            Real shm = influence.shape_values[n] * mp;
            LocalCellP2G &cell = local[node_id];
            cell.mass += static_cast<long double>(shm);
            cell.mom[0] += static_cast<long double>(shm * vxp[0]);
            cell.mom[1] += static_cast<long double>(shm * vxp[1]);
            cell.mom[2] += static_cast<long double>(shm * vxp[2]);
          }
        }
      }
    }

    #pragma omp parallel for schedule(static)
    for (int i = 0; i < ncenter; ++i) {
      long double mass = 0.0L;
      long double mom0 = 0.0L, mom1 = 0.0L, mom2 = 0.0L;
      for (int t = 0; t < nthreads; ++t) {
        const LocalCellP2G &cell = accum[static_cast<size_t>(t) * ncenter + i];
        mass += cell.mass;
        mom0 += cell.mom[0];
        mom1 += cell.mom[1];
        mom2 += cell.mom[2];
      }
      if (mass == 0.0L && mom0 == 0.0L && mom1 == 0.0L && mom2 == 0.0L)
        continue;
      auto &cell_prop = grid_->getCellProperty(i);
      Real cur_mass = cell_prop.getMass();
      Vec3 cur_mom = cell_prop.getMomentum();
      cell_prop.setMass(cur_mass + static_cast<Real>(mass));
      cell_prop.setMomentum({cur_mom[0] + static_cast<Real>(mom0),
                             cur_mom[1] + static_cast<Real>(mom1),
                             cur_mom[2] + static_cast<Real>(mom2)});
    }
#else
    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      int par_begin = body.getParticleBegin();
      int par_end = body.getParticleEnd();

      InfluenceDomain influence;
      influence.reserve(MAX_INFL_NODES);
      for (int p = par_begin; p < par_end; ++p) {
        Particle &pt = (*particles_)[p];
        if (!isParticleLocal(pt)) {
          continue;
        }

        int center_cell = pt.getCenterCell();
        if (center_cell < 0)
          continue;

        Real mp = pt.getMass();
        Vec3 vxp = pt.getVelocity();

        influence.clear();
        shape_func_->evaluateAuxiliary(pt, *grid_, influence.node_indices,
                                       influence.shape_values,
                                       influence.shape_gradients);

        for (size_t n = 0; n < influence.size(); ++n) {
          int node_id = influence.node_indices[n];
          if (node_id < 0 || node_id >= grid_->getNumCenterCells())
            continue;

          Real shm = influence.shape_values[n] * mp;
          auto &cell_prop = grid_->getCellProperty(node_id);
          cell_prop.addMass(shm);
          cell_prop.addMomentum(shm * vxp);
        }
      }
    }
#endif
  } else {
#if defined(MPM3D_USE_OPENMP)
    struct LocalNodeP2G {
      long double mass = 0.0L;
      long double mom[3] = {0.0L, 0.0L, 0.0L};
    };
    const int nnode = grid_->getNumNodes();
    const int ncomp = grid_->getNumComponents();
    const int nthreads = dd_repro_mode_ ? 1 : omp_get_max_threads();
    std::vector<LocalNodeP2G> accum(
        static_cast<size_t>(nthreads) * ncomp * nnode);

    soa_pid_.clear();
    soa_comp_off_.clear();
    soa_mass_.clear();
    soa_vx_.clear();
    soa_vy_.clear();
    soa_vz_.clear();
    soa_pid_.reserve(particles_->size());
    soa_comp_off_.reserve(particles_->size());
    soa_mass_.reserve(particles_->size());
    soa_vx_.reserve(particles_->size());
    soa_vy_.reserve(particles_->size());
    soa_vz_.reserve(particles_->size());

    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      int par_begin = body.getParticleBegin();
      int par_end = body.getParticleEnd();
      int com_id = contact_enabled_ ? body.getComponentID() : 1;
      const int comp_off = (com_id - 1) * nnode;

      for (int p = par_begin; p < par_end; ++p) {
        const Particle &pt = (*particles_)[p];
        if (!isParticleLocal(pt)) {
          continue;
        }
        int icell = pt.getCell();
        if (icell < 0) {
          continue;
        }
        const Vec3 vxp = pt.getVelocity();
        soa_pid_.push_back(p);
        soa_comp_off_.push_back(comp_off);
        soa_mass_.push_back(pt.getMass());
        soa_vx_.push_back(vxp[0]);
        soa_vy_.push_back(vxp[1]);
        soa_vz_.push_back(vxp[2]);
      }
    }

    const int nactive = static_cast<int>(soa_pid_.size());
    if (nactive > 0) {
      #pragma omp parallel num_threads(nthreads)
      {
        const int tid = omp_get_thread_num();
        LocalNodeP2G *local =
            accum.data() + static_cast<size_t>(tid) * ncomp * nnode;
        InfluenceDomain influence;
        influence.reserve(MAX_INFL_NODES);

        #pragma omp for schedule(static)
        for (int k = 0; k < nactive; ++k) {
          const size_t ks = static_cast<size_t>(k);
          const int p = soa_pid_[ks];
          const int comp_off = soa_comp_off_[ks];
          const Particle &pt = (*particles_)[p];
          const Real mp = soa_mass_[ks];
          const Real vxp0 = soa_vx_[ks];
          const Real vxp1 = soa_vy_[ks];
          const Real vxp2 = soa_vz_[ks];

          influence.clear();
          shape_func_->evaluate(pt, *grid_, influence.node_indices,
                                influence.shape_values,
                                influence.shape_gradients);

          for (size_t n = 0; n < influence.size(); ++n) {
            int node_id = influence.node_indices[n];
            if (node_id < 0 || node_id >= nnode) {
              continue;
            }

            Real shm = influence.shape_values[n] * mp;
            LocalNodeP2G &cell = local[comp_off + node_id];
            cell.mass += static_cast<long double>(shm);
            cell.mom[0] += static_cast<long double>(shm * vxp0);
            cell.mom[1] += static_cast<long double>(shm * vxp1);
            cell.mom[2] += static_cast<long double>(shm * vxp2);
          }
        }
      }
    }

    #pragma omp parallel for schedule(static)
    for (int comp = 1; comp <= ncomp; ++comp) {
      const int comp_idx = comp - 1;
      for (int i = 0; i < nnode; ++i) {
        long double mass = 0.0L;
        long double mom0 = 0.0L, mom1 = 0.0L, mom2 = 0.0L;
        const int idx = comp_idx * nnode + i;
        for (int t = 0; t < nthreads; ++t) {
          const LocalNodeP2G &cell =
              accum[static_cast<size_t>(t) * ncomp * nnode + idx];
          mass += cell.mass;
          mom0 += cell.mom[0];
          mom1 += cell.mom[1];
          mom2 += cell.mom[2];
        }
        if (mass == 0.0L && mom0 == 0.0L && mom1 == 0.0L && mom2 == 0.0L) {
          continue;
        }
        auto &node_prop = grid_->getNodeProperty(comp, i);
        node_prop.addMass(static_cast<Real>(mass));
        node_prop.addMomentum({static_cast<Real>(mom0), static_cast<Real>(mom1),
                               static_cast<Real>(mom2)});
      }
    }
#else
    InfluenceDomain influence;
    influence.reserve(MAX_INFL_NODES);
    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      int par_begin = body.getParticleBegin();
      int par_end = body.getParticleEnd();
      int com_id = contact_enabled_ ? body.getComponentID() : 1;

      for (int p = par_begin; p < par_end; ++p) {
        Particle &pt = (*particles_)[p];
        if (!isParticleLocal(pt)) {
          continue;
        }

        int icell = pt.getCell();
        if (icell < 0)
          continue;

        Real mp = pt.getMass();
        Vec3 vxp = pt.getVelocity();

        influence.clear();
        shape_func_->evaluate(pt, *grid_, influence.node_indices,
                              influence.shape_values,
                              influence.shape_gradients);

        for (size_t n = 0; n < influence.size(); ++n) {
          int node_id = influence.node_indices[n];
          if (node_id < 0 || node_id >= grid_->getNumNodes())
            continue;

          Real shm = influence.shape_values[n] * mp;
          auto &node_prop = grid_->getNodeProperty(com_id, node_id);
          node_prop.addMass(shm);
          node_prop.addMomentum(shm * vxp);
        }
      }
    }
#endif
  }


  // If SGMP, transfer from auxiliary grid to background grid
  if (SGMP_) {
    SGMPTransfer();
  }

  if (dd_allreduce_) {
    if (dd_exchange_nodes_ && dd_filter_particles_ &&
        grid_->getDecompSize() > 1 && grid_->getDecompGhost() > 0) {
      grid_->exchangeNodeFields(true, false, false);
    } else {
      grid_->allreduceNodeFields(true, false, false);
    }
  }
}

// ============================================================================
// Particle Initial - Calculate Grid Coordinates
// ============================================================================

void UpdateStep::particleInitial() {
  // Purpose: Calculate particle natural coordinates and closest node

#if defined(MPM3D_USE_OPENMP)
  #pragma omp parallel for schedule(static)
#endif
  for (size_t b = 0; b < bodies_->size(); ++b) {
    const Body &body = (*bodies_)[b];
    int par_begin = body.getParticleBegin();
    int par_end = body.getParticleEnd();

    for (int p = par_begin; p < par_end; ++p) {
      Particle &pt = (*particles_)[p];

      // Find which cell contains the particle
      // Fortran: call FindCell(XX(1,p), XX(2,p), XX(3,p), icell)
      Vec3 pos = pt.getPositionPrev();

      int icell = grid_->findCell(pos);
      pt.setCell(icell);
      if (grid_->isDecompositionActive()) {
        // In DD mode without migration, particle storage remains replicated
        // across ranks, so owner must be refreshed from current cell each step
        // to balance filtered work. With migration enabled, owner is maintained
        // by the migration path and should not be overwritten here.
        const bool refresh_owner =
            (!dd_filter_particles_) || (!dd_migrate_particles_ && dd_balance_replica_);
        if (refresh_owner) {
          if (icell >= 0) {
            pt.setOwnerRank(grid_->ownerRankForCell(icell));
          } else {
            pt.setOwnerRank(grid_->getDecompRank());
          }
        }
      }

      // Calculate natural coordinates in cell
      if (icell >= 0) {
        Vec3 natural_coords = grid_->calculateNaturalCoords(pos, icell);
        pt.setNaturalCoords(natural_coords);
      }

      if (SGMP_) {
        // For SGMP, also calculate auxiliary grid coordinates
        int center_cell = grid_->findCenterCell(pos);
        pt.setCenterCell(center_cell);

        // Match Fortran ParticleInitial/TLParticleInitial SGMP branch:
        //   ix = int((Xp(1)-SpanX(1))/DCell + 0.5) + 1  (1-based)
        //   inode = (iz-1)*NGxy + (iy-1)*NGx + ix
        //   XXN = (Xp - node_list(inode)%Xg) * iJacobi, iJacobi = 2/DCell
        //   clamp XXN(i) to +/-1 if node is on boundary in that direction.
        const Real h = grid_->getCellSize();
        const Real iJacobi = 2.0 / h;

        const Vec3 spanx = grid_->getSpanX();
        const Vec3 spany = grid_->getSpanY();
        const Vec3 spanz = grid_->getSpanZ();

        const int NGx = grid_->getNumCellsX() + 1;
        const int NGy = grid_->getNumCellsY() + 1;
        const int NGz = grid_->getNumCellsZ() + 1;
        const int NGxy = NGx * NGy;

        // 0-based indices using the same rounding intent as Fortran (+0.5 then int)
        const int ix = static_cast<int>(((pos[0] - spanx[0]) / h) + 0.5);
        const int iy = static_cast<int>(((pos[1] - spany[0]) / h) + 0.5);
        const int iz = static_cast<int>(((pos[2] - spanz[0]) / h) + 0.5);

        if (ix >= 0 && ix < NGx && iy >= 0 && iy < NGy && iz >= 0 && iz < NGz) {
          const int inode = iz * NGxy + iy * NGx + ix;
          pt.setNode(inode);

          const GridNode &node = grid_->getNode(inode);
          const Vec3 xg = node.getPosition();

          Vec3 xxn = {(pos[0] - xg[0]) * iJacobi,
                      (pos[1] - xg[1]) * iJacobi,
                      (pos[2] - xg[2]) * iJacobi};

          const auto bd = node.getBoundaryType();
          for (int d = 0; d < 3; ++d) {
            if (bd[d] != 0) {
              if (xxn[d] > 0)
                xxn[d] = 1.0;
              else if (xxn[d] < 0)
                xxn[d] = -1.0;
            }
          }

          pt.setNaturalCoordsAux(xxn);
        } else {
          // Out of grid
          pt.setNode(-1);
          pt.setNaturalCoordsAux({0.0, 0.0, 0.0});
        }
      }
    }
  }
}

// ============================================================================
// Particle Stress Update
// ============================================================================

void UpdateStep::particleStressUpdate() {
  // Purpose: Calculate strain rate and update stresses

  // Reset auxiliary grid strain if SGMP
  if (SGMP_) {
 #if defined(MPM3D_USE_OPENMP)
    #pragma omp parallel for schedule(static)
 #endif
    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      auto &cell_prop = grid_->getCellProperty(i);
      cell_prop.setStrainIncrement({0, 0, 0, 0, 0, 0});
      cell_prop.setVorticity({0, 0, 0});
      cell_prop.setDefGradIncrement(zero_mat3());
    }

    // Calculate strain at auxiliary grid
 #if defined(MPM3D_USE_OPENMP)
    #pragma omp parallel for schedule(static)
 #endif
    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      auto &cell_prop = grid_->getCellProperty(i);

      // Get cell nodes
      auto cell_nodes = grid_->getCellNodes(i);

      // Calculate velocity gradient from grid velocities
      // Simplified implementation for SGMP algorithm
      // Using basic central differences
      
      // Initialize velocity gradient
      Mat3 vel_grad = zero_mat3();
      
      // Simple approximation: use neighboring node velocities
      for (int n = 0; n < 8; ++n) {
        const int node_id = cell_nodes[n];
        if (node_id >= 0 && node_id < grid_->getNumNodes()) {
          auto& node_prop = grid_->getNodeProperty(1, node_id);
          Vec3 node_vel = node_prop.getVelocity();
          
          // Simple gradient approximation
          Real weight = 0.125; // Shape function weight at center
          vel_grad[0][0] += weight * node_vel[0] * 0.25; // dvx/dx
          vel_grad[1][1] += weight * node_vel[1] * 0.25; // dvy/dy
          vel_grad[2][2] += weight * node_vel[2] * 0.25; // dvz/dz
        }
      }
      
      // Store velocity gradient for particle (simplified - just store in cell)
      // Particle &pt = (*particles_)[i];
      // pt.setVelocityGradient(vel_grad);
      
      const Real inv4h = 1.0 / (4.0 * grid_->getCellSize());

      Vec6 co = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
      Vec3 cw = {0.0, 0.0, 0.0};
      Mat3 cdef = zero_mat3();

      for (int j = 0; j < 8; ++j) {
        const int node_id = cell_nodes[j];
        if (node_id < 0 || node_id >= grid_->getNumNodes()) {
          continue;
        }
        const auto &gd = grid_->getNodeProperty(1, node_id);
        if (gd.getMass() <= cutoff_) {
          continue;
        }

        const Vec3 vgx = gd.getMomentum() / gd.getMass();

        // CNShape gradients at xi=eta=zeta=0
        const Real cdndx = SNX[j] * inv4h;
        const Real cdndy = SNY[j] * inv4h;
        const Real cdndz = SNZ[j] * inv4h;

        // Strain-rate (Voigt): D11, D22, D33, 2*D23, 2*D13, 2*D12
        co[0] += cdndx * vgx[0];
        co[1] += cdndy * vgx[1];
        co[2] += cdndz * vgx[2];
        co[3] += cdndz * vgx[1] + cdndy * vgx[2];
        co[4] += cdndz * vgx[0] + cdndx * vgx[2];
        co[5] += cdndy * vgx[0] + cdndx * vgx[1];

        // Vorticity-rate (W32, W13, W21)
        cw[0] += cdndy * vgx[2] - cdndz * vgx[1];
        cw[1] += cdndz * vgx[0] - cdndx * vgx[2];
        cw[2] += cdndx * vgx[1] - cdndy * vgx[0];

        // Velocity gradient for F update
        for (int n = 0; n < 3; ++n) {
          cdef[n][0] += cdndx * vgx[n];
          cdef[n][1] += cdndy * vgx[n];
          cdef[n][2] += cdndz * vgx[n];
        }
      }

      cell_prop.setStrainIncrement(co);
      cell_prop.setVorticity(cw);
      cell_prop.setDefGradIncrement(cdef);
    }
  }

  // Loop over all particles
#if defined(MPM3D_USE_OPENMP)
  #pragma omp parallel
  {
    InfluenceDomain influence;
    influence.reserve(MAX_INFL_NODES);
    ConstitutionModel local_constitution;
    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      int par_begin = body.getParticleBegin();
      int par_end = body.getParticleEnd();
      int com_id = contact_enabled_ ? body.getComponentID() : 1;

      #pragma omp for schedule(static)
      for (int p = par_begin; p < par_end; ++p) {
        Particle &pt = (*particles_)[p];
        if (!isParticleStateLocal(pt)) {
          continue;
        }

        const Vec3 pos_prev = pt.getPositionPrev();
        const int icell = grid_->findCell(pos_prev);
        pt.setCell(icell);
        if (icell < 0)
          continue;
        pt.setNaturalCoords(grid_->calculateNaturalCoords(pos_prev, icell));
        if (SGMP_) {
          pt.setCenterCell(grid_->findCenterCell(pos_prev));
        }

        Vec6 de = {0, 0, 0, 0, 0, 0};
        Vec3 vort = {0, 0, 0};
        Mat3 deFp = zero_mat3();

        if (SGMP_) {
          const int center_cell = pt.getCenterCell();
          if (center_cell < 0)
            continue;

          influence.clear();
          shape_func_->evaluateAuxiliary(pt, *grid_, influence.node_indices,
                                         influence.shape_values,
                                         influence.shape_gradients);

          for (size_t n = 0; n < influence.size(); ++n) {
            const int node_id = influence.node_indices[n];
            if (node_id < 0 || node_id >= grid_->getNumCenterCells())
              continue;

            const auto &cell_prop = grid_->getCellProperty(node_id);
            const Real shp = influence.shape_values[n];

            const Vec6 cell_strain = cell_prop.getStrainIncrement();
            const Vec3 cell_vort = cell_prop.getVorticity();
            const Mat3 cell_defgrad = cell_prop.getDefGradIncrement();

            for (int i = 0; i < 6; ++i)
              de[i] += shp * cell_strain[i];
            for (int i = 0; i < 3; ++i)
              vort[i] += shp * cell_vort[i];
            for (int i = 0; i < 3; ++i)
              for (int j = 0; j < 3; ++j)
                deFp[i][j] += shp * cell_defgrad[i][j];
          }

        } else {
          influence.clear();
          shape_func_->evaluate(pt, *grid_, influence.node_indices,
                                influence.shape_values,
                                influence.shape_gradients);

          for (size_t n = 0; n < influence.size(); ++n) {
            const int node_id = influence.node_indices[n];
            if (node_id < 0 || node_id >= grid_->getNumNodes())
              continue;

            const auto &node_prop = grid_->getNodeProperty(com_id, node_id);
            if (node_prop.getMass() <= cutoff_)
              continue;

            const Vec3 vgx = node_prop.getMomentum() / node_prop.getMass();
            const Vec3 grad = influence.shape_gradients[n];

            de[0] += grad[0] * vgx[0];
            de[1] += grad[1] * vgx[1];
            de[2] += grad[2] * vgx[2];
            de[3] += grad[1] * vgx[2] + grad[2] * vgx[1];
            de[4] += grad[2] * vgx[0] + grad[0] * vgx[2];
            de[5] += grad[0] * vgx[1] + grad[1] * vgx[0];

            vort[0] += grad[1] * vgx[2] - grad[2] * vgx[1];
            vort[1] += grad[2] * vgx[0] - grad[0] * vgx[2];
            vort[2] += grad[0] * vgx[1] - grad[1] * vgx[0];

            for (int i = 0; i < 3; ++i) {
              deFp[i][0] += grad[0] * vgx[i];
              deFp[i][1] += grad[1] * vgx[i];
              deFp[i][2] += grad[2] * vgx[i];
            }
          }
        }

        for (int i = 0; i < 6; ++i)
          de[i] *= dt_;
        for (int i = 0; i < 3; ++i)
          vort[i] *= dt_ / 2.0;
        for (int i = 0; i < 3; ++i) {
          for (int j = 0; j < 3; ++j) {
            deFp[i][j] *= dt_;
          }
        }

        if (UpdateVbyFp_) {
          Mat3 F_old = pt.getDeformationGradient();
          Mat3 F_new = F_old;

          for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
              F_new[i][j] += deFp[i][j];
              for (int k = 0; k < 3; ++k) {
                F_new[i][j] += deFp[i][k] * F_old[k][j];
              }
            }
          }
          pt.setDeformationGradient(F_new);
        }

        if (TLMPM_) {
          local_constitution.TLConstitution(de, vort, deFp, b, p, *bodies_,
                                            *particles_, *materials_, dt_,
                                            grid_->getCellSize());
        } else {
          local_constitution.constitution(de, vort, deFp, b, p, *bodies_, *particles_,
                                          *materials_, dt_, current_time_,
                                          grid_->getCellSize());
        }

        if (!USF_) {
          pt.setPositionPrev(pt.getPosition());
        }
      }
    }
  }
#else
  for (size_t b = 0; b < bodies_->size(); ++b) {
    const Body &body = (*bodies_)[b];
    int par_begin = body.getParticleBegin();
    int par_end = body.getParticleEnd();
    int com_id = contact_enabled_ ? body.getComponentID() : 1;

    for (int p = par_begin; p < par_end; ++p) {
      Particle &pt = (*particles_)[p];
      if (!isParticleStateLocal(pt)) {
        continue;
      }

      // Match Fortran ParticleStressUpdate:
      //   pt%icell = InWhichCell(pt%Xp)
      //   pt%XN = (pt%Xp - cell_list(pt%icell)%Cxg) * iJacobi
      // We compute XN via calculateNaturalCoords (center-based), equivalent to
      // (Xp - Cxg) * (2/DCell).
      const Vec3 pos_prev = pt.getPositionPrev();
      const int icell = grid_->findCell(pos_prev);
      pt.setCell(icell);
      if (icell < 0)
        continue;
      pt.setNaturalCoords(grid_->calculateNaturalCoords(pos_prev, icell));
      if (SGMP_) {
        pt.setCenterCell(grid_->findCenterCell(pos_prev));
      }

      Vec6 de = {0, 0, 0, 0, 0, 0}; // Strain increment
      Vec3 vort = {0, 0, 0};        // Vorticity
      Mat3 deFp = zero_mat3();      // Deformation gradient increment

      if (SGMP_) {
        // Use auxiliary grid
        const int center_cell = pt.getCenterCell();
        if (center_cell < 0)
          continue;

        infl_nodes_.clear();
        shape_values_.clear();
        shape_gradients_.clear();

        shape_func_->evaluateAuxiliary(pt, *grid_, infl_nodes_, shape_values_,
                                       shape_gradients_);

        // Interpolate strain/vorticity/vel-grad from auxiliary grid
        for (size_t n = 0; n < infl_nodes_.size(); ++n) {
          const int node_id = infl_nodes_[n];
          if (node_id < 0 || node_id >= grid_->getNumCenterCells())
            continue;

          const auto &cell_prop = grid_->getCellProperty(node_id);
          const Real shp = shape_values_[n];

          const Vec6 cell_strain = cell_prop.getStrainIncrement();
          const Vec3 cell_vort = cell_prop.getVorticity();
          const Mat3 cell_defgrad = cell_prop.getDefGradIncrement();

          for (int i = 0; i < 6; ++i)
            de[i] += shp * cell_strain[i];
          for (int i = 0; i < 3; ++i)
            vort[i] += shp * cell_vort[i];
          for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
              deFp[i][j] += shp * cell_defgrad[i][j];
        }

      } else {
        // Standard MPM - calculate directly from grid velocities
        infl_nodes_.clear();
        shape_values_.clear();
        shape_gradients_.clear();

        shape_func_->evaluate(pt, *grid_, infl_nodes_, shape_values_,
                              shape_gradients_);

        for (size_t n = 0; n < infl_nodes_.size(); ++n) {
          const int node_id = infl_nodes_[n];
          if (node_id < 0 || node_id >= grid_->getNumNodes())
            continue;

          const auto &node_prop = grid_->getNodeProperty(com_id, node_id);
          if (node_prop.getMass() <= cutoff_)
            continue;

          // Fortran: vgx = gd%PXg / gd%Mg
          const Vec3 vgx = node_prop.getMomentum() / node_prop.getMass();
          const Vec3 grad = shape_gradients_[n];

          // Strain-rate (Voigt): D11, D22, D33, 2*D23, 2*D13, 2*D12
          de[0] += grad[0] * vgx[0];
          de[1] += grad[1] * vgx[1];
          de[2] += grad[2] * vgx[2];
          de[3] += grad[1] * vgx[2] + grad[2] * vgx[1];
          de[4] += grad[2] * vgx[0] + grad[0] * vgx[2];
          de[5] += grad[0] * vgx[1] + grad[1] * vgx[0];

          // Vorticity-rate (W32, W13, W21)
          vort[0] += grad[1] * vgx[2] - grad[2] * vgx[1];
          vort[1] += grad[2] * vgx[0] - grad[0] * vgx[2];
          vort[2] += grad[0] * vgx[1] - grad[1] * vgx[0];

          // Velocity gradient for F update
          for (int i = 0; i < 3; ++i) {
            deFp[i][0] += grad[0] * vgx[i];
            deFp[i][1] += grad[1] * vgx[i];
            deFp[i][2] += grad[2] * vgx[i];
          }
        }
      }

      // Scale by time step
      for (int i = 0; i < 6; ++i)
        de[i] *= dt_;
      for (int i = 0; i < 3; ++i)
        vort[i] *= dt_ / 2.0;
      for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
          deFp[i][j] *= dt_;
        }
      }

      // Update deformation gradient if requested
      if (UpdateVbyFp_) {
        Mat3 F_old = pt.getDeformationGradient();
        Mat3 F_new = F_old;

        // F_new = F_old + dF + dF * F_old
        for (int i = 0; i < 3; ++i) {
          for (int j = 0; j < 3; ++j) {
            F_new[i][j] += deFp[i][j];
            for (int k = 0; k < 3; ++k) {
              F_new[i][j] += deFp[i][k] * F_old[k][j];
            }
          }
        }
        pt.setDeformationGradient(F_new);
      }

      // Update stress using constitutive model
      if (TLMPM_) {
        constitution_->TLConstitution(de, vort, deFp, b, p, *bodies_,
                                      *particles_, *materials_, dt_,
                                      grid_->getCellSize());
      } else {
        constitution_->constitution(de, vort, deFp, b, p, *bodies_, *particles_,
                                    *materials_, dt_, current_time_,
                                    grid_->getCellSize());
      }

      // Match Fortran: if(.NOT.USF) pt%Xp = pt%XX     ! the next particle position
      if (!USF_) {
        pt.setPositionPrev(pt.getPosition());
      }
    }
  }
#endif

}

// Grid Momentum Update - Calculate Forces
// ============================================================================

void UpdateStep::gridMomentumUpdate() {
  // Calculate internal forces from particle stresses

  // SGMP: reset auxiliary grid force accumulators (matches Fortran SGMP branch)
  if (SGMP_) {
 #if defined(MPM3D_USE_OPENMP)
    #pragma omp parallel for schedule(static)
 #endif
    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      auto &cell_prop = grid_->getCellProperty(i);
      cell_prop.setTotalForce({0.0, 0.0, 0.0});
      cell_prop.setInternalForce({0.0, 0.0, 0.0, 0.0, 0.0, 0.0});
      cell_prop.setExternalForce({0.0, 0.0, 0.0});
    }
  }

  // CRITICAL: Reset forces before calculation to match Fortran behavior
  // Fortran recalculates forces from scratch each step, doesn't accumulate
  for (int comp = 1; comp <= grid_->getNumComponents(); ++comp) {
 #if defined(MPM3D_USE_OPENMP)
    #pragma omp parallel for schedule(static)
 #endif
    for (int i = 0; i < grid_->getNumNodes(); ++i) {
      auto &node_prop = grid_->getNodeProperty(comp, i);
      node_prop.setForce({0, 0, 0});
    }
  }

  // Loop over all particles
  if (SGMP_) {
 #if defined(MPM3D_USE_OPENMP)
    struct LocalCellForce {
      long double ext[3] = {0.0L, 0.0L, 0.0L};
      long double intl[6] = {0.0L, 0.0L, 0.0L, 0.0L, 0.0L, 0.0L};
    };
    const int ncenter = grid_->getNumCenterCells();
    const int nthreads = dd_repro_mode_ ? 1 : omp_get_max_threads();
    std::vector<LocalCellForce> accum(static_cast<size_t>(nthreads) * ncenter);

    #pragma omp parallel num_threads(nthreads)
    {
      const int tid = omp_get_thread_num();
      LocalCellForce* local = accum.data() + static_cast<size_t>(tid) * ncenter;
      InfluenceDomain influence;
      influence.reserve(MAX_INFL_NODES);

      for (size_t b = 0; b < bodies_->size(); ++b) {
        const Body &body = (*bodies_)[b];
        int par_begin = body.getParticleBegin();
        int par_end = body.getParticleEnd();

        #pragma omp for schedule(static)
        for (int p = par_begin; p < par_end; ++p) {
          const Particle &pt = (*particles_)[p];
          if (!isParticleLocal(pt)) {
            continue;
          }

          Vec3 fx = pt.getExternalForce();
          {
            const Body &body_g = (*bodies_)[b];
            fx = fx + pt.getMass() * body_g.getGravity();
          }

          const int center_cell = pt.getCenterCell();
          if (center_cell < 0)
            continue;

          const Real sxx = pt.getMeanStress() - pt.getBulkViscosity() + pt.getSDxx();
          const Real syy = pt.getMeanStress() - pt.getBulkViscosity() + pt.getSDyy();
          const Real szz = pt.getMeanStress() - pt.getBulkViscosity() + pt.getSDzz();
          const Real sxy = pt.getSDxy();
          const Real syz = pt.getSDyz();
          const Real sxz = pt.getSDxz();

          const Real vol = pt.getVolume();

          influence.clear();
          shape_func_->evaluateAuxiliary(pt, *grid_, influence.node_indices,
                                         influence.shape_values,
                                         influence.shape_gradients);

          for (size_t n = 0; n < influence.size(); ++n) {
            const int aux_id = influence.node_indices[n];
            if (aux_id < 0 || aux_id >= ncenter)
              continue;
            const Real shp = influence.shape_values[n];

            LocalCellForce &cell = local[aux_id];
            cell.ext[0] += static_cast<long double>(shp * fx[0]);
            cell.ext[1] += static_cast<long double>(shp * fx[1]);
            cell.ext[2] += static_cast<long double>(shp * fx[2]);
            cell.intl[0] += static_cast<long double>(shp * sxx * vol);
            cell.intl[1] += static_cast<long double>(shp * syy * vol);
            cell.intl[2] += static_cast<long double>(shp * szz * vol);
            cell.intl[3] += static_cast<long double>(shp * sxy * vol);
            cell.intl[4] += static_cast<long double>(shp * syz * vol);
            cell.intl[5] += static_cast<long double>(shp * sxz * vol);
          }
        }
      }
    }

    #pragma omp parallel for schedule(static)
    for (int i = 0; i < ncenter; ++i) {
      long double ext0 = 0.0L, ext1 = 0.0L, ext2 = 0.0L;
      long double int0 = 0.0L, int1 = 0.0L, int2 = 0.0L, int3 = 0.0L, int4 = 0.0L, int5 = 0.0L;
      for (int t = 0; t < nthreads; ++t) {
        const LocalCellForce &cell = accum[static_cast<size_t>(t) * ncenter + i];
        ext0 += cell.ext[0];
        ext1 += cell.ext[1];
        ext2 += cell.ext[2];
        int0 += cell.intl[0];
        int1 += cell.intl[1];
        int2 += cell.intl[2];
        int3 += cell.intl[3];
        int4 += cell.intl[4];
        int5 += cell.intl[5];
      }
      if (ext0 == 0.0L && ext1 == 0.0L && ext2 == 0.0L &&
          int0 == 0.0L && int1 == 0.0L && int2 == 0.0L &&
          int3 == 0.0L && int4 == 0.0L && int5 == 0.0L) {
        continue;
      }
      auto &cd = grid_->getCellProperty(i);
      cd.setExternalForce({static_cast<Real>(ext0),
                           static_cast<Real>(ext1),
                           static_cast<Real>(ext2)});
      cd.setInternalForce({static_cast<Real>(int0),
                           static_cast<Real>(int1),
                           static_cast<Real>(int2),
                           static_cast<Real>(int3),
                           static_cast<Real>(int4),
                           static_cast<Real>(int5)});
    }
 #else
    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      int par_begin = body.getParticleBegin();
      int par_end = body.getParticleEnd();

      InfluenceDomain influence;
      influence.reserve(MAX_INFL_NODES);
      for (int p = par_begin; p < par_end; ++p) {
        const Particle &pt = (*particles_)[p];
        if (!isParticleLocal(pt)) {
          continue;
        }

        Vec3 fx = pt.getExternalForce();
        {
          const Body &body_g = (*bodies_)[b];
          fx = fx + pt.getMass() * body_g.getGravity();
        }

        const int center_cell = pt.getCenterCell();
        if (center_cell < 0)
          continue;

        const Real sxx = pt.getMeanStress() - pt.getBulkViscosity() + pt.getSDxx();
        const Real syy = pt.getMeanStress() - pt.getBulkViscosity() + pt.getSDyy();
        const Real szz = pt.getMeanStress() - pt.getBulkViscosity() + pt.getSDzz();
        const Real sxy = pt.getSDxy();
        const Real syz = pt.getSDyz();
        const Real sxz = pt.getSDxz();

        const Real vol = pt.getVolume();

        influence.clear();
        shape_func_->evaluateAuxiliary(pt, *grid_, influence.node_indices,
                                       influence.shape_values,
                                       influence.shape_gradients);

        for (size_t n = 0; n < influence.size(); ++n) {
          const int aux_id = influence.node_indices[n];
          if (aux_id < 0 || aux_id >= grid_->getNumCenterCells())
            continue;
          const Real shp = influence.shape_values[n];

          auto &cd = grid_->getCellProperty(aux_id);
          cd.addExternalForce(shp * fx);
          cd.addInternalForce({shp * sxx * vol,
                               shp * syy * vol,
                               shp * szz * vol,
                               shp * sxy * vol,
                               shp * syz * vol,
                               shp * sxz * vol});
        }
      }
    }
 #endif
  } else {
#if defined(MPM3D_USE_OPENMP)
    struct LocalNodeForce {
      long double f[3] = {0.0L, 0.0L, 0.0L};
    };
    const int nnode = grid_->getNumNodes();
    const int ncomp = grid_->getNumComponents();
    const int nthreads = dd_repro_mode_ ? 1 : omp_get_max_threads();
    std::vector<LocalNodeForce> accum(
        static_cast<size_t>(nthreads) * ncomp * nnode);

    soa_pid_.clear();
    soa_comp_off_.clear();
    soa_fx0_.clear();
    soa_fx1_.clear();
    soa_fx2_.clear();
    soa_s0_.clear();
    soa_s1_.clear();
    soa_s2_.clear();
    soa_s3_.clear();
    soa_s4_.clear();
    soa_s5_.clear();
    soa_vol_.clear();
    soa_pid_.reserve(particles_->size());
    soa_comp_off_.reserve(particles_->size());
    soa_fx0_.reserve(particles_->size());
    soa_fx1_.reserve(particles_->size());
    soa_fx2_.reserve(particles_->size());
    soa_s0_.reserve(particles_->size());
    soa_s1_.reserve(particles_->size());
    soa_s2_.reserve(particles_->size());
    soa_s3_.reserve(particles_->size());
    soa_s4_.reserve(particles_->size());
    soa_s5_.reserve(particles_->size());
    soa_vol_.reserve(particles_->size());

    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      int par_begin = body.getParticleBegin();
      int par_end = body.getParticleEnd();
      int com_id = contact_enabled_ ? body.getComponentID() : 1;
      const int comp_off = (com_id - 1) * nnode;

      for (int p = par_begin; p < par_end; ++p) {
        const Particle &pt = (*particles_)[p];
        if (!isParticleLocal(pt)) {
          continue;
        }
        int icell = pt.getCell();
        if (icell < 0) {
          continue;
        }
        Vec3 fx = pt.getExternalForce();
        fx = fx + pt.getMass() * body.getGravity();
        const Vec6 stress = pt.getCauchyStress();
        soa_pid_.push_back(p);
        soa_comp_off_.push_back(comp_off);
        soa_fx0_.push_back(fx[0]);
        soa_fx1_.push_back(fx[1]);
        soa_fx2_.push_back(fx[2]);
        soa_s0_.push_back(stress[0]);
        soa_s1_.push_back(stress[1]);
        soa_s2_.push_back(stress[2]);
        soa_s3_.push_back(stress[3]);
        soa_s4_.push_back(stress[4]);
        soa_s5_.push_back(stress[5]);
        soa_vol_.push_back(pt.getVolume());
      }
    }

    const int nactive = static_cast<int>(soa_pid_.size());
    if (nactive > 0) {
      #pragma omp parallel num_threads(nthreads)
      {
        const int tid = omp_get_thread_num();
        LocalNodeForce *local =
            accum.data() + static_cast<size_t>(tid) * ncomp * nnode;
        InfluenceDomain influence;
        influence.reserve(MAX_INFL_NODES);

        #pragma omp for schedule(static)
        for (int k = 0; k < nactive; ++k) {
          const size_t ks = static_cast<size_t>(k);
          const int p = soa_pid_[ks];
          const int comp_off = soa_comp_off_[ks];
          const Particle &pt = (*particles_)[p];
          const Real f0 = soa_fx0_[ks];
          const Real f1 = soa_fx1_[ks];
          const Real f2 = soa_fx2_[ks];
          const Real c0 = soa_s0_[ks];
          const Real c1 = soa_s1_[ks];
          const Real c2 = soa_s2_[ks];
          const Real c3 = soa_s3_[ks];
          const Real c4 = soa_s4_[ks];
          const Real c5 = soa_s5_[ks];
          const Real v = soa_vol_[ks];

          influence.clear();
          shape_func_->evaluate(pt, *grid_, influence.node_indices,
                                influence.shape_values,
                                influence.shape_gradients);

          for (size_t n = 0; n < influence.size(); ++n) {
            int node_id = influence.node_indices[n];
            if (node_id < 0 || node_id >= nnode) {
              continue;
            }

            const Vec3 grad = influence.shape_gradients[n];
            const Real fint0 = -(c0 * grad[0] + c5 * grad[1] + c4 * grad[2]) * v;
            const Real fint1 = -(c5 * grad[0] + c1 * grad[1] + c3 * grad[2]) * v;
            const Real fint2 = -(c4 * grad[0] + c3 * grad[1] + c2 * grad[2]) * v;
            LocalNodeForce &cell = local[comp_off + node_id];
            cell.f[0] += static_cast<long double>(fint0);
            cell.f[1] += static_cast<long double>(fint1);
            cell.f[2] += static_cast<long double>(fint2);
          }

          if (std::abs(f0) > EPSILON || std::abs(f1) > EPSILON || std::abs(f2) > EPSILON) {
            for (size_t n = 0; n < influence.size(); ++n) {
              int node_id = influence.node_indices[n];
              if (node_id < 0 || node_id >= nnode) {
                continue;
              }
              const Real shp = influence.shape_values[n];
              LocalNodeForce &cell = local[comp_off + node_id];
              cell.f[0] += static_cast<long double>(shp * f0);
              cell.f[1] += static_cast<long double>(shp * f1);
              cell.f[2] += static_cast<long double>(shp * f2);
            }
          }
        }
      }
    }

    #pragma omp parallel for schedule(static)
    for (int comp = 1; comp <= ncomp; ++comp) {
      const int comp_idx = comp - 1;
      for (int i = 0; i < nnode; ++i) {
        long double f0 = 0.0L, f1 = 0.0L, f2 = 0.0L;
        const int idx = comp_idx * nnode + i;
        for (int t = 0; t < nthreads; ++t) {
          const LocalNodeForce &cell =
              accum[static_cast<size_t>(t) * ncomp * nnode + idx];
          f0 += cell.f[0];
          f1 += cell.f[1];
          f2 += cell.f[2];
        }
        if (f0 == 0.0L && f1 == 0.0L && f2 == 0.0L) {
          continue;
        }
        auto &node_prop = grid_->getNodeProperty(comp, i);
        node_prop.addForce({static_cast<Real>(f0), static_cast<Real>(f1),
                            static_cast<Real>(f2)});
      }
    }
#else
    InfluenceDomain influence;
    influence.reserve(MAX_INFL_NODES);
    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      int par_begin = body.getParticleBegin();
      int par_end = body.getParticleEnd();
      int com_id = contact_enabled_ ? body.getComponentID() : 1;

      for (int p = par_begin; p < par_end; ++p) {
        const Particle &pt = (*particles_)[p];
        if (!isParticleLocal(pt)) {
          continue;
        }

        Vec3 fx = pt.getExternalForce();
        {
          const Body &body_g = (*bodies_)[b];
          fx = fx + pt.getMass() * body_g.getGravity();
        }

        int icell = pt.getCell();
        if (icell < 0)
          continue;

        Vec6 stress = pt.getCauchyStress();
        Real vol = pt.getVolume();

        influence.clear();
        shape_func_->evaluate(pt, *grid_, influence.node_indices,
                              influence.shape_values,
                              influence.shape_gradients);

        for (size_t n = 0; n < influence.size(); ++n) {
          int node_id = influence.node_indices[n];
          if (node_id < 0 || node_id >= grid_->getNumNodes())
            continue;

          Vec3 grad = influence.shape_gradients[n];
          Vec3 f_int;
          f_int[0] =
              -(stress[0] * grad[0] + stress[5] * grad[1] + stress[4] * grad[2]) *
              vol;
          f_int[1] =
              -(stress[5] * grad[0] + stress[1] * grad[1] + stress[3] * grad[2]) *
              vol;
          f_int[2] =
              -(stress[4] * grad[0] + stress[3] * grad[1] + stress[2] * grad[2]) *
              vol;

          auto &node_prop = grid_->getNodeProperty(com_id, node_id);
          node_prop.addForce(f_int);
        }

        if (norm(fx) > EPSILON) {
          for (size_t n = 0; n < influence.size(); ++n) {
            int node_id = influence.node_indices[n];
            if (node_id < 0 || node_id >= grid_->getNumNodes())
              continue;
            Real shp = influence.shape_values[n];
            auto &node_prop = grid_->getNodeProperty(com_id, node_id);
            node_prop.addForce(shp * fx);
          }
        }
      }
    }
#endif
  }

  // SGMP: transfer auxiliary forces to background grid forces (matches Fortran)
  if (SGMP_) {
    const Real inv4h = 1.0 / (4.0 * grid_->getCellSize());
    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      const auto &cd = grid_->getCellProperty(i);
      if (cd.getMass() < cutoff_)
        continue;

      // Fortran uses InflNode(1:8)=CellsNode(i,:) where i is a cell id
      const auto infl = grid_->getCellNodes(i);

      const Vec6 cfint = cd.getInternalForce();
      const Vec3 cfext = cd.getExternalForce();

      for (int j = 0; j < 8; ++j) {
        const int node_id = infl[j];
        if (node_id < 0 || node_id >= grid_->getNumNodes())
          continue;

        // CNShape gradients at xi=eta=zeta=0
        const Real dndx = SNX[j] * inv4h;
        const Real dndy = SNY[j] * inv4h;
        const Real dndz = SNZ[j] * inv4h;

        Vec3 f_int;
        f_int[0] = -(cfint[0] * dndx + cfint[3] * dndy + cfint[5] * dndz);
        f_int[1] = -(cfint[3] * dndx + cfint[1] * dndy + cfint[4] * dndz);
        f_int[2] = -(cfint[5] * dndx + cfint[4] * dndy + cfint[2] * dndz);

        auto &gd = grid_->getNodeProperty(1, node_id);
        gd.addForce(0.125 * cfext + f_int);
      }
    }
  }

  if (dd_allreduce_) {
    if (dd_exchange_nodes_ && dd_filter_particles_ &&
        grid_->getDecompSize() > 1 && grid_->getDecompGhost() > 0) {
      grid_->exchangeNodeFields(false, true, false);
    } else {
      grid_->allreduceNodeFields(false, true, false);
    }
  }
}

// ============================================================================
// Integrate Momentum - Explicit Time Integration
// ============================================================================

void UpdateStep::integrateMomentum(int step) {
  // Purpose: Explicit time integration of momentum

  static int call_count = 0;
  Real max_v = 0.0;
  Real max_f = 0.0;
  Real effective_dt = (step == 1) ? (dt_ * 0.5) : dt_;
  for (int comp = 1; comp <= grid_->getNumComponents(); ++comp) {
 #if defined(MPM3D_USE_OPENMP)
    #pragma omp parallel for schedule(static) reduction(max:max_v,max_f)
 #endif
    for (int i = 0; i < grid_->getNumNodes(); ++i) {
      const GridNode &node = grid_->getNode(i); // Get node for BC check
      auto &node_prop = grid_->getNodeProperty(comp, i);

      if (node_prop.getMass() > cutoff_) {
        Vec3 momentum = node_prop.getMomentum();
        Vec3 force = node_prop.getForce();
        Real mass = node_prop.getMass();


        // Integrate momentum: p_new = p_old + f * dt
        Vec3 momentum_new = momentum + force * effective_dt;

        // Apply boundary conditions (matching Fortran line 1222-1235)
        if (node.isFixedX()) {
          momentum_new[0] = 0.0;
          force[0] = 0.0;
        }
        if (node.isFixedY()) {
          momentum_new[1] = 0.0;
          force[1] = 0.0;
        }
        if (node.isFixedZ()) {
          momentum_new[2] = 0.0;
          force[2] = 0.0;
        }

        node_prop.setMomentum(momentum_new);
        node_prop.setForce(force); // Update force after BC

        // CRITICAL: Update velocity
        Vec3 velocity_new = momentum_new / mass;
        node_prop.setVelocity(velocity_new);


        // Track max values
        // Match Fortran UpdateDT style: maxval(abs(vg(1:3))) i.e. component-wise max
        Real v_mag = std::max({std::abs(velocity_new[0]), std::abs(velocity_new[1]),
                               std::abs(velocity_new[2])});
        Real f_mag = norm(force);
        max_v = std::max(max_v, v_mag);
        max_f = std::max(max_f, f_mag);
      }
    }
  }

  // Save diagnostic for comparing grid-level peak velocity to Fortran
  last_max_vg_ = max_v;

  call_count++;

  // In MPI DD ghost-exchange mode, sync updated nodal momentum/force so G2P
  // sees consistent values near subdomain boundaries.
  // In allreduce mode, nodal values are already globally consistent before
  // integrate, and each rank applies the same update, so re-reducing here
  // would incorrectly amplify momentum/force by the number of ranks.
  if (dd_allreduce_ && dd_exchange_nodes_ && dd_filter_particles_ &&
      grid_->getDecompSize() > 1 && grid_->getDecompGhost() > 0) {
    grid_->exchangeNodeMomentum();
    grid_->exchangeNodeFields(false, true, false);

    // Recompute nodal velocities after exchange (derived from momentum/mass).
    for (int comp = 1; comp <= grid_->getNumComponents(); ++comp) {
      for (int i = 0; i < grid_->getNumNodes(); ++i) {
        auto &node_prop = grid_->getNodeProperty(comp, i);
        Real mass = node_prop.getMass();
        if (mass > cutoff_) {
          node_prop.setVelocity(node_prop.getMomentum() / mass);
        } else {
          node_prop.setVelocity({0.0, 0.0, 0.0});
        }
      }
    }
  }

}

// ============================================================================
// Particle Position Update - G2P Transfer
// ============================================================================

void UpdateStep::particlePositionUpdate(int step) {
  // Purpose: Map grid velocities to particles and update positions

  const char *dbg_env = std::getenv("MPM3D_SGMP_DEBUG");
  const bool sgmp_dbg = (dbg_env && std::string(dbg_env) != "0");
  const char *dbg_pid_env = std::getenv("MPM3D_DBG_PID");
  const int dbg_pid = dbg_pid_env ? std::atoi(dbg_pid_env) : -1;

  auto sgn_shape = [](const Vec3 &xi, std::array<Real, 8> &N) {
    const Real x = xi[0];
    const Real y = xi[1];
    const Real z = xi[2];
    for (int i = 0; i < 8; ++i) {
      N[i] = 0.125 * (1.0 + SNX[i] * x) * (1.0 + SNY[i] * y) *
             (1.0 + SNZ[i] * z);
    }
  };

  auto auxiliary_grid_shp = [](const Vec3 &XN, const Vec3 &XXN,
                               const std::array<int, 3> &p_type) -> Vec3 {
    Vec3 xinb = XXN;
    for (int i = 0; i < 3; ++i) {
      if (p_type[i] != 0) {
        if (XN[i] < 0.0)
          xinb[i] = 1.0 + 2.0 * XN[i];
        else
          xinb[i] = 2.0 * XN[i] - 1.0;
      } else {
        xinb[i] = XXN[i];
      }
    }
    return xinb;
  };

  auto boundary_auxiliary_node_update = [&]() {
    const auto &fix = grid_->getFixedBoundary();
    const int NumCellx = grid_->getNumCellsX();
    const int NumCelly = grid_->getNumCellsY();
    const int NumCellz = grid_->getNumCellsZ();
    const int NumCellxy = NumCellx * NumCelly;

    auto update_cell = [&](int ix, int iy, int iz, const Vec3 &cxx) {
      const int n = ix + iy * NumCellx + iz * NumCellxy;
      if (n < 0 || n >= grid_->getNumCenterCells())
        return;
      const auto infl = grid_->getCellNodes(n);
      std::array<Real, 8> N;
      sgn_shape(cxx, N);
      Vec3 vx = {0.0, 0.0, 0.0};
      Vec3 ax = {0.0, 0.0, 0.0};
      for (int j = 0; j < 8; ++j) {
        const int node_id = infl[j];
        if (node_id < 0 || node_id >= grid_->getNumNodes())
          continue;
        const auto &gd = grid_->getNodeProperty(1, node_id);
        if (gd.getMass() > cutoff_) {
          const Real shp = N[j];
          vx += shp * (gd.getMomentum() / gd.getMass());
          ax += shp * (gd.getForce() / gd.getMass());
        }
      }
      auto &cd = grid_->getCellProperty(n);
      cd.setVelocity(vx);
      cd.setAcceleration(ax);
    };

    if (NumCellx > 1) {
      for (int side = 0; side < 2; ++side) {
        const bool active = (side == 0) ? (fix[0] != 0) : (fix[1] != 0);
        if (!active)
          continue;
        const int ix = (side == 0) ? 0 : (NumCellx - 1);
        for (int iz = 0; iz < NumCellz; ++iz) {
          for (int iy = 0; iy < NumCelly; ++iy) {
            Vec3 cxx = {0.0, 0.0, 0.0};
            cxx[0] = (ix == 0) ? 1.0 : -1.0;
            if (NumCelly > 1) {
              if (iy == 0)
                cxx[1] = 1.0;
              if (iy == NumCelly - 1)
                cxx[1] = -1.0;
            }
            if (NumCellz > 1) {
              if (iz == 0)
                cxx[2] = 1.0;
              if (iz == NumCellz - 1)
                cxx[2] = -1.0;
            }
            update_cell(ix, iy, iz, cxx);
          }
        }
      }
    }

    if (NumCelly > 1) {
      for (int side = 0; side < 2; ++side) {
        const bool active = (side == 0) ? (fix[2] != 0) : (fix[3] != 0);
        if (!active)
          continue;
        const int iy = (side == 0) ? 0 : (NumCelly - 1);
        for (int iz = 0; iz < NumCellz; ++iz) {
          for (int ix = 0; ix < NumCellx; ++ix) {
            Vec3 cxx = {0.0, 0.0, 0.0};
            cxx[1] = (iy == 0) ? 1.0 : -1.0;
            if (NumCellx > 1) {
              if (ix == 0)
                cxx[0] = 1.0;
              if (ix == NumCellx - 1)
                cxx[0] = -1.0;
            }
            if (NumCellz > 1) {
              if (iz == 0)
                cxx[2] = 1.0;
              if (iz == NumCellz - 1)
                cxx[2] = -1.0;
            }
            update_cell(ix, iy, iz, cxx);
          }
        }
      }
    }

    if (NumCellz > 1) {
      for (int side = 0; side < 2; ++side) {
        const bool active = (side == 0) ? (fix[4] != 0) : (fix[5] != 0);
        if (!active)
          continue;
        const int iz = (side == 0) ? 0 : (NumCellz - 1);
        for (int iy = 0; iy < NumCelly; ++iy) {
          for (int ix = 0; ix < NumCellx; ++ix) {
            Vec3 cxx = {0.0, 0.0, 0.0};
            cxx[2] = (iz == 0) ? 1.0 : -1.0;
            if (NumCellx > 1) {
              if (ix == 0)
                cxx[0] = 1.0;
              if (ix == NumCellx - 1)
                cxx[0] = -1.0;
            }
            if (NumCelly > 1) {
              if (iy == 0)
                cxx[1] = 1.0;
              if (iy == NumCelly - 1)
                cxx[1] = -1.0;
            }
            update_cell(ix, iy, iz, cxx);
          }
        }
      }
    }
  };

  if (SGMP_) {
    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      auto &cd = grid_->getCellProperty(i);
      cd.setVelocity({0.0, 0.0, 0.0});
      cd.setAcceleration({0.0, 0.0, 0.0});
    }

    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      auto &cd = grid_->getCellProperty(i);
      const auto infl = grid_->getCellNodes(i);
      for (int j = 0; j < 8; ++j) {
        const int node_id = infl[j];
        if (node_id < 0 || node_id >= grid_->getNumNodes())
          continue;
        const auto &gd = grid_->getNodeProperty(1, node_id);
        if (gd.getMass() > cutoff_) {
          cd.setVelocity(cd.getVelocity() + 0.125 * (gd.getMomentum() / gd.getMass()));
          cd.setAcceleration(cd.getAcceleration() +
                             0.125 * (gd.getForce() / gd.getMass()));
        }
      }
    }

    boundary_auxiliary_node_update();
  }

#if defined(MPM3D_USE_OPENMP)
  #pragma omp parallel
  {
    InfluenceDomain influence;
    influence.reserve(MAX_INFL_NODES);
    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      int par_begin = body.getParticleBegin();
      int par_end = body.getParticleEnd();
      int com_id = contact_enabled_ ? body.getComponentID() : 1;

      #pragma omp for schedule(static)
      for (int p = par_begin; p < par_end; ++p) {
        Particle &pt = (*particles_)[p];
        if (!isParticleStateLocal(pt)) {
          continue;
        }

        if (SGMP_) {
          const int center_cell = pt.getCenterCell();
          if (center_cell < 0)
            continue;

          const auto center_infl = grid_->getCenterCellNodes(center_cell);

          Vec3 xx = pt.getPositionPrev();
          Vec3 vx = {0.0, 0.0, 0.0};
          Vec3 ax = {0.0, 0.0, 0.0};

          bool isinternal = true;
          std::array<int, 3> p_type = {0, 0, 0};
          const int inode = pt.getNode();
          if (inode >= 0 && inode < grid_->getNumNodes()) {
            const GridNode &node = grid_->getNode(inode);
            p_type = node.getBoundaryType();
            for (int i = 0; i < 3; ++i) {
              if (p_type[i] != 0) {
                isinternal = false;
                break;
              }
            }
          }

          Vec3 xi = pt.getNaturalCoordsAux();
          if (!isinternal) {
            xi = auxiliary_grid_shp(pt.getNaturalCoords(), pt.getNaturalCoordsAux(),
                                    p_type);
          }

          std::array<Real, 8> N;
          sgn_shape(xi, N);

          for (int n = 0; n < 8; ++n) {
            const int cell_id = center_infl[n];
            if (cell_id < 0 || cell_id >= grid_->getNumCenterCells())
              continue;

            const Real shp = N[n];
            const auto &cd = grid_->getCellProperty(cell_id);
            vx += shp * cd.getVelocity();
            ax += shp * cd.getAcceleration();
          }

          if (sgmp_dbg && dbg_pid >= 0 && p == dbg_pid) {
#if defined(MPM3D_USE_OPENMP)
            #pragma omp critical
#endif
            {
              std::cout << std::scientific << std::setprecision(6);
              std::cout << "SGMP_G2P_DBG step=" << step << " pid=" << p
                        << " time=" << current_time_ << " dt=" << dt_
                        << " center_cell=" << center_cell << " inode=" << inode
                        << " LT=" << pt.getLightingTime()
                        << " burned=" << ((current_time_ > pt.getLightingTime()) ? 1 : 0)
                        << " isinternal=" << (isinternal ? 1 : 0)
                        << " ptype=" << p_type[0] << "," << p_type[1] << "," << p_type[2]
                        << " xi=" << xi[0] << "," << xi[1] << "," << xi[2]
                        << " xx_prev=" << xx[0] << "," << xx[1] << "," << xx[2];

              std::cout << " N=";
              for (int n = 0; n < 8; ++n) {
                std::cout << N[n];
                if (n != 7)
                  std::cout << ",";
              }

              std::cout << " cells=";
              for (int n = 0; n < 8; ++n) {
                const int cell_id = center_infl[n];
                if (cell_id < 0 || cell_id >= grid_->getNumCenterCells())
                  continue;
                const auto &cd = grid_->getCellProperty(cell_id);
                const Vec3 cvx = cd.getVelocity();
                const Vec3 cax = cd.getAcceleration();
                std::cout << "(" << n << ":" << cell_id << ";cvx=" << cvx[0] << "," << cvx[1]
                          << "," << cvx[2] << ";cax=" << cax[0] << "," << cax[1] << "," << cax[2]
                          << ";nodes=";

                const auto infl = grid_->getCellNodes(cell_id);
                for (int j = 0; j < 8; ++j) {
                  const int nid = infl[j];
                  if (nid < 0 || nid >= grid_->getNumNodes())
                    continue;
                  const auto &gd = grid_->getNodeProperty(1, nid);
                  const Real mg = gd.getMass();
                  const Real axg = (mg > cutoff_) ? (gd.getForce()[0] / mg) : 0.0;
                  std::cout << "[" << nid << ":mg=" << mg << ",ax=" << axg << "]";
                }

                std::cout << ")";
              }

              const Real dt_factor = (step == 1) ? (dt_ * 0.5) : dt_;
              std::cout << " vx=" << vx[0] << "," << vx[1] << "," << vx[2]
                        << " ax=" << ax[0] << "," << ax[1] << "," << ax[2]
                        << " dt_factor=" << dt_factor;
              std::cout << std::endl;
              std::cout.unsetf(std::ios::scientific);
            }
          }

          pt.setPosition(xx + vx * dt_);
          Real dt_factor = (step == 1) ? (dt_ * 0.5) : dt_;
          pt.setVelocity(pt.getVelocity() + ax * dt_factor);
          if (USF_) {
            pt.setPositionPrev(pt.getPosition());
          }
          continue;
        }

        int icell = pt.getCell();
        if (icell < 0)
          continue;

        influence.clear();
        shape_func_->evaluate(pt, *grid_, influence.node_indices,
                              influence.shape_values,
                              influence.shape_gradients);

        Vec3 vel_pic = {0, 0, 0};
        Vec3 acc = {0, 0, 0};

        for (size_t n = 0; n < influence.size(); ++n) {
          int node_id = influence.node_indices[n];
          if (node_id < 0 || node_id >= grid_->getNumNodes())
            continue;

          const auto &node_prop = grid_->getNodeProperty(com_id, node_id);

          if (node_prop.getMass() > cutoff_) {
            Real shp = influence.shape_values[n];
            Vec3 f_grid = node_prop.getForce();
            Real m_grid = node_prop.getMass();

            Vec3 v_grid = node_prop.getMomentum() / m_grid;
            vel_pic += shp * v_grid;
            acc += shp * (f_grid / m_grid);
          }
        }

        Vec3 pos_new = pt.getPositionPrev() + vel_pic * dt_;
        pt.setPosition(pos_new);

        if (USF_) {
          pt.setPositionPrev(pos_new);
        }
        Real dt_factor = (step == 1) ? (dt_ * 0.5) : dt_;
        pt.setVelocity(pt.getVelocity() + acc * dt_factor);
      }
    }
  }
#else
  InfluenceDomain influence;
  influence.reserve(MAX_INFL_NODES);
  for (size_t b = 0; b < bodies_->size(); ++b) {
    const Body &body = (*bodies_)[b];
    int par_begin = body.getParticleBegin();
    int par_end = body.getParticleEnd();
    int com_id = contact_enabled_ ? body.getComponentID() : 1;

    for (int p = par_begin; p < par_end; ++p) {
      Particle &pt = (*particles_)[p];
      if (!isParticleStateLocal(pt)) {
        continue;
      }

      if (SGMP_) {
        const int center_cell = pt.getCenterCell();
        if (center_cell < 0)
          continue;

        const auto center_infl = grid_->getCenterCellNodes(center_cell);

        Vec3 xx = pt.getPositionPrev();
        Vec3 vx = {0.0, 0.0, 0.0};
        Vec3 ax = {0.0, 0.0, 0.0};

        bool isinternal = true;
        std::array<int, 3> p_type = {0, 0, 0};
        const int inode = pt.getNode();
        if (inode >= 0 && inode < grid_->getNumNodes()) {
          const GridNode &node = grid_->getNode(inode);
          p_type = node.getBoundaryType();
          for (int i = 0; i < 3; ++i) {
            if (p_type[i] != 0) {
              isinternal = false;
              break;
            }
          }
        }

        Vec3 xi = pt.getNaturalCoordsAux();
        if (!isinternal) {
          xi = auxiliary_grid_shp(pt.getNaturalCoords(), pt.getNaturalCoordsAux(),
                                  p_type);
        }

        std::array<Real, 8> N;
        sgn_shape(xi, N);

        for (int n = 0; n < 8; ++n) {
          const int cell_id = center_infl[n];
          if (cell_id < 0 || cell_id >= grid_->getNumCenterCells())
            continue;

          const Real shp = N[n];
          const auto &cd = grid_->getCellProperty(cell_id);
          vx += shp * cd.getVelocity();
          ax += shp * cd.getAcceleration();
        }

        if (sgmp_dbg && dbg_pid >= 0 && p == dbg_pid) {
          std::cout << std::scientific << std::setprecision(6);
          std::cout << "SGMP_G2P_DBG step=" << step << " pid=" << p
                    << " time=" << current_time_ << " dt=" << dt_
                    << " center_cell=" << center_cell << " inode=" << inode
                    << " LT=" << pt.getLightingTime()
                    << " burned=" << ((current_time_ > pt.getLightingTime()) ? 1 : 0)
                    << " isinternal=" << (isinternal ? 1 : 0)
                    << " ptype=" << p_type[0] << "," << p_type[1] << "," << p_type[2]
                    << " xi=" << xi[0] << "," << xi[1] << "," << xi[2]
                    << " xx_prev=" << xx[0] << "," << xx[1] << "," << xx[2];

          std::cout << " N=";
          for (int n = 0; n < 8; ++n) {
            std::cout << N[n];
            if (n != 7)
              std::cout << ",";
          }

          std::cout << " cells=";
          for (int n = 0; n < 8; ++n) {
            const int cell_id = center_infl[n];
            if (cell_id < 0 || cell_id >= grid_->getNumCenterCells())
              continue;
            const auto &cd = grid_->getCellProperty(cell_id);
            const Vec3 cvx = cd.getVelocity();
            const Vec3 cax = cd.getAcceleration();
            std::cout << "(" << n << ":" << cell_id << ";cvx=" << cvx[0] << "," << cvx[1]
                      << "," << cvx[2] << ";cax=" << cax[0] << "," << cax[1] << "," << cax[2]
                      << ";nodes=";

            const auto infl = grid_->getCellNodes(cell_id);
            for (int j = 0; j < 8; ++j) {
              const int nid = infl[j];
              if (nid < 0 || nid >= grid_->getNumNodes())
                continue;
              const auto &gd = grid_->getNodeProperty(1, nid);
              const Real mg = gd.getMass();
              const Real axg = (mg > cutoff_) ? (gd.getForce()[0] / mg) : 0.0;
              std::cout << "[" << nid << ":mg=" << mg << ",ax=" << axg << "]";
            }

            std::cout << ")";
          }

          const Real dt_factor = (step == 1) ? (dt_ * 0.5) : dt_;
          std::cout << " vx=" << vx[0] << "," << vx[1] << "," << vx[2]
                    << " ax=" << ax[0] << "," << ax[1] << "," << ax[2]
                    << " dt_factor=" << dt_factor;
          std::cout << std::endl;
          std::cout.unsetf(std::ios::scientific);
        }

        pt.setPosition(xx + vx * dt_);
        Real dt_factor = (step == 1) ? (dt_ * 0.5) : dt_;
        pt.setVelocity(pt.getVelocity() + ax * dt_factor);
        if (USF_) {
          pt.setPositionPrev(pt.getPosition());
        }
        continue;
      }

      int icell = pt.getCell();
      if (icell < 0)
        continue;

      influence.clear();
      shape_func_->evaluate(pt, *grid_, influence.node_indices,
                            influence.shape_values,
                            influence.shape_gradients);

      Vec3 vel_pic = {0, 0, 0};
      Vec3 acc = {0, 0, 0};

      for (size_t n = 0; n < influence.size(); ++n) {
        int node_id = influence.node_indices[n];
        if (node_id < 0 || node_id >= grid_->getNumNodes())
          continue;

        const auto &node_prop = grid_->getNodeProperty(com_id, node_id);

        if (node_prop.getMass() > cutoff_) {
          Real shp = influence.shape_values[n];
          Vec3 f_grid = node_prop.getForce();
          Real m_grid = node_prop.getMass();

          Vec3 v_grid = node_prop.getMomentum() / m_grid;
          vel_pic += shp * v_grid;
          acc += shp * (f_grid / m_grid);
        }
      }

      Vec3 pos_new = pt.getPositionPrev() + vel_pic * dt_;
      pt.setPosition(pos_new);

      if (USF_) {
        pt.setPositionPrev(pos_new);
      }
      Real dt_factor = (step == 1) ? (dt_ * 0.5) : dt_;
      pt.setVelocity(pt.getVelocity() + acc * dt_factor);
    }
  }
#endif

}

// ============================================================================
// Apply Boundary Conditions
// ============================================================================

void UpdateStep::applyBoundaryConditions() {
  // Purpose: Apply boundary conditions to grid nodes


  for (int comp = 1; comp <= grid_->getNumComponents(); ++comp) {
 #if defined(MPM3D_USE_OPENMP)
    #pragma omp parallel for schedule(static)
 #endif
    for (int i = 0; i < grid_->getNumNodes(); ++i) {
      const GridNode &node = grid_->getNode(i);
      auto &node_prop = grid_->getNodeProperty(comp, i);

      if (node_prop.getMass() < cutoff_)
        continue;

      Vec3 momentum = node_prop.getMomentum();
      Vec3 velocity = node_prop.getVelocity();
      Vec3 force = node_prop.getForce();
      // Apply fixed boundary conditions
      // Fortran: if (FixedX(i)) Vg(1,i) = 0, Pg(1,i) = 0, Fg(1,i) = 0
      if (node.isFixedX()) {
        momentum[0] = 0.0;
        velocity[0] = 0.0;
        force[0] = 0.0;
      }
      if (node.isFixedY()) {
        momentum[1] = 0.0;
        velocity[1] = 0.0;
        force[1] = 0.0;
      }
      if (node.isFixedZ()) {
        momentum[2] = 0.0;
        velocity[2] = 0.0;
        force[2] = 0.0;
      }

      node_prop.setMomentum(momentum);
      node_prop.setVelocity(velocity);
      node_prop.setForce(force);
    }
  }

}

// ============================================================================
// Calculate Energy
// ============================================================================

void UpdateStep::calcEnergy() {
  // Purpose: Calculate total kinetic and internal energy
  // Matches Fortran calcEnergy in Particle.f90

  // Use long double accumulators to reduce cancellation differences in the
  // near-zero momentum components (Fortran often evaluates in extended
  // precision depending on compiler/flags).
  Real ke_acc = 0.0;
  Real ie_acc = 0.0;
  Real mx = 0.0, my = 0.0, mz = 0.0;

  // Match Fortran (src/Particle.f90): loop particles in strict global index
  // order (p=1..nb_particle) when accumulating EngKinetic/EngInternal/Momentum.
  // Use explicit scalar operations to reduce FP contraction/reordering.
  for (size_t p = 0; p < particles_->size(); ++p) {
    const Particle &pt = (*particles_)[static_cast<int>(p)];
    const Real mass = pt.getMass();
    const Vec3 vel = pt.getVelocity();
    const Real ie = pt.getInternalEnergy();

    const Real vx = vel[0];
    const Real vy = vel[1];
    const Real vz = vel[2];
    ke_acc += 0.5 * mass * (vx * vx + vy * vy + vz * vz);
    ie_acc += ie;
    mx += mass * vx;
    my += mass * vy;
    mz += mass * vz;
  }

  kinetic_energy_ = ke_acc;
  internal_energy_ = ie_acc;
  momentum_[0] = mx;
  momentum_[1] = my;
  momentum_[2] = mz;

#if defined(MPM3D_USE_MPI)
  if (dd_allreduce_) {
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (mpi_initialized) {
      Real ke = kinetic_energy_;
      Real ie = internal_energy_;
      Vec3 mom = momentum_;
      MPI_Allreduce(&ke, &kinetic_energy_, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
      MPI_Allreduce(&ie, &internal_energy_, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
      MPI_Allreduce(&mom[0], &momentum_[0], 3, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
    }
  }
#endif

}

// ============================================================================
// Update Time Step - Adaptive Time Stepping
// ============================================================================

Real UpdateStep::computeStableDt(bool include_max_vp) {
  // Shared implementation for:
  // - Fortran SetDT(): include_max_vp=false
  // - Fortran UpdateDT(): include_max_vp=true (vv = vv + max_vp)
  Real max_vp = 0.0;
  int max_vp_pid = -1;
  if (include_max_vp) {
#if defined(MPM3D_USE_OPENMP)
    #pragma omp parallel for schedule(static) reduction(max:max_vp)
#endif
    for (size_t b = 0; b < bodies_->size(); ++b) {
      const Body &body = (*bodies_)[b];
      const int par_begin = body.getParticleBegin();
      const int par_end = body.getParticleEnd();
      for (int p = par_begin; p < par_end; ++p) {
        const Particle &pt = (*particles_)[p];
        if (!isParticleLocal(pt)) {
          continue;
        }
        const Vec3 vel = pt.getVelocity();
        const Real vp_mag =
            std::max({std::abs(vel[0]), std::abs(vel[1]), std::abs(vel[2])});
        if (max_vp < vp_mag) {
          max_vp = vp_mag;
          max_vp_pid = p;
        }
      }
    }
  }

#if defined(MPM3D_USE_MPI)
  if (dd_allreduce_) {
    int mpi_initialized = 0;
    MPI_Initialized(&mpi_initialized);
    if (mpi_initialized) {
      Real global_max_vp = max_vp;
      MPI_Allreduce(&max_vp, &global_max_vp, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
      max_vp = global_max_vp;
    }
  }
#endif

  Real dt_min = 1.0e6;
  const Real cell_size = grid_->getCellSize();

  for (int m = 1; m <= materials_->getNumMaterials(); ++m) {
    const Material &mat = materials_->getMaterial(m);
    const MaterialType mtype = mat.getMaterialType();

    if (static_cast<int>(mtype) == 12)
      continue;

    const Real E = mat.getYoungsModulus();
    const Real nu = mat.getPoissonsRatio();
    const Real ro = mat.getDensity();

    Real vv = 0.0;
    if (ro > EPSILON && E > EPSILON && std::abs(1.0 + nu) > EPSILON &&
        std::abs(1.0 - 2.0 * nu) > EPSILON) {
      vv = std::sqrt(E * (1.0 - nu) / (1.0 + nu) / (1.0 - 2.0 * nu) / ro);
    }

    vv = std::max(vv, mat.getDetonationVelocity());
    vv = std::max(vv, mat.getWaveSpeed());
    if (include_max_vp)
      vv += max_vp;

    if (vv > EPSILON) {
      const Real dt_mat = cell_size / vv;
      if (dt_mat < dt_min)
        dt_min = dt_mat;
    }
  }

  // Save diagnostics (Fortran prints these separately; we store for report())
  last_max_vp_ = max_vp;
  last_dt_min_ = dt_min;

  
  return dt_scale_ * dt_min;
}

void UpdateStep::setDTInitial() {
  dt_ = computeStableDt(false);
}

void UpdateStep::updateDT() {
  dt_ = computeStableDt(true);
}

// ============================================================================
// Smooth Stress By Grid
// ============================================================================

void UpdateStep::smoothStressByGrid() {
  // Purpose: Smooth particle stresses for stability

  // Reset grid pressure
  for (int i = 0; i < grid_->getNumNodes(); ++i) {
    for (int comp = 1; comp <= grid_->getNumComponents(); ++comp) {
      auto &node_prop = grid_->getNodeProperty(comp, i);
      node_prop.setPressure(0.0);
      node_prop.setVolume(0.0);
    }
  }

  // Map particle pressure to grid
  for (size_t b = 0; b < bodies_->size(); ++b) {
    const Body &body = (*bodies_)[b];
    int par_begin = body.getParticleBegin();
    int par_end = body.getParticleEnd();
    int com_id = contact_enabled_ ? body.getComponentID() : 1;

    for (int p = par_begin; p < par_end; ++p) {
      const Particle &pt = (*particles_)[p];
      if (!isParticleLocal(pt)) {
        continue;
      }

      int icell = pt.getCell();
      if (icell < 0)
        continue;

      Real pressure = -pt.getMeanStress(); // Negative of mean stress
      Real volume = pt.getVolume();

      infl_nodes_.clear();
      shape_values_.clear();
      shape_gradients_.clear();

      shape_func_->evaluate(pt, *grid_, infl_nodes_, shape_values_, shape_gradients_);

      for (size_t n = 0; n < infl_nodes_.size(); ++n) {
        int node_id = infl_nodes_[n];
        if (node_id < 0 || node_id >= grid_->getNumNodes())
          continue;

        Real shp = shape_values_[n];
        auto &node_prop = grid_->getNodeProperty(com_id, node_id);

        Real pv = pressure * volume * shp;
        node_prop.setPressure(node_prop.getPressure() + pv);
        node_prop.setVolume(node_prop.getVolume() + volume * shp);
      }
    }
  }

  // Smooth pressure back to particles
  if (dd_allreduce_) {
    if (dd_exchange_nodes_ && dd_filter_particles_ &&
        grid_->getDecompSize() > 1 && grid_->getDecompGhost() > 0) {
      grid_->exchangeNodeFields(false, false, true);
    } else {
      grid_->allreduceNodeFields(false, false, true);
    }
  }

  for (size_t b = 0; b < bodies_->size(); ++b) {
    const Body &body = (*bodies_)[b];
    int par_begin = body.getParticleBegin();
    int par_end = body.getParticleEnd();
    int com_id = contact_enabled_ ? body.getComponentID() : 1;

    for (int p = par_begin; p < par_end; ++p) {
      Particle &pt = (*particles_)[p];
      if (!isParticleStateLocal(pt)) {
        continue;
      }

      int icell = pt.getCell();
      if (icell < 0)
        continue;

      infl_nodes_.clear();
      shape_values_.clear();
      shape_gradients_.clear();

      shape_func_->evaluate(pt, *grid_, infl_nodes_, shape_values_, shape_gradients_);

      Real smoothed_pressure = 0.0;

      for (size_t n = 0; n < infl_nodes_.size(); ++n) {
        int node_id = infl_nodes_[n];
        if (node_id < 0 || node_id >= grid_->getNumNodes())
          continue;

        Real shp = shape_values_[n];
        const auto &node_prop = grid_->getNodeProperty(com_id, node_id);

        Real vol = node_prop.getVolume();
        if (vol > EPSILON) {
          smoothed_pressure += shp * (node_prop.getPressure() / vol);
        }
      }

      pt.setSmoothedPressure(smoothed_pressure);
      pt.setMeanStress(-smoothed_pressure); // Update mean stress
    }
  }
}

// ============================================================================
// Dynamic Relaxation Damping
// ============================================================================

void UpdateStep::dynamicRelaxationDamping() {
  // Purpose: Apply damping for quasi-static analysis

  if (!QuasiLoad_)
    return;

  // Calculate kinetic energy ratio
  Real ke_ratio =
      kinetic_energy_ / (kinetic_energy_ + internal_energy_ + EPSILON);

  // If kinetic energy is small enough, we've reached equilibrium
  if (ke_ratio < 0.005) {
    std::cout << "Quasi-static equilibrium reached (KE ratio = " << ke_ratio
              << ")" << std::endl;
    return;
  }

  // Apply damping to velocities
  Real damping_factor = 0.99; // Can be adjusted

  for (size_t p = 0; p < particles_->size(); ++p) {
    Particle &pt = (*particles_)[p];
    if (!isParticleStateLocal(pt)) {
      continue;
    }
    Vec3 vel = pt.getVelocity();
    pt.setVelocity(damping_factor * vel);
  }
}

// ============================================================================
// SGMP Transfer - Auxiliary Grid to Background Grid
// ============================================================================

void UpdateStep::SGMPTransfer() {
  // Purpose: Transfer data from auxiliary grid to background grid

  if (!SGMP_)
    return;

  for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
    const auto &cell_prop = grid_->getCellProperty(i);

    if (cell_prop.getMass() < cutoff_)
      continue;

    // Get cell nodes
    auto cell_nodes = grid_->getCellNodes(i);

    Real cell_mass = cell_prop.getMass();
    Vec3 cell_momentum = cell_prop.getMomentum();

    // Distribute equally to 8 nodes
    for (int j = 0; j < 8; ++j) {
      int node_id = cell_nodes[j];
      if (node_id < 0 || node_id >= grid_->getNumNodes())
        continue;

      auto &node_prop = grid_->getNodeProperty(1, node_id);
      node_prop.addMass(0.125 * cell_mass);
      node_prop.addMomentum(0.125 * cell_momentum);
    }
  }
}

// ============================================================================
// Helper Functions
// ============================================================================

int UpdateStep::inWhichCell(const Vec3 &position) {
  return grid_->findCell(position);
}

int UpdateStep::centerInWhichCell(const Vec3 &position) {
  return grid_->findCenterCell(position);
}

// ============================================================================
// Grid Momentum MUSL
// ============================================================================

void UpdateStep::gridMomentumMUSL() {
  // Recalculate grid momentum from updated particle velocities
  if (dd_migrate_particles_) {
    migrateParticles(true);
  }

  // SGMP: reset auxiliary momentum (Cpxg) (matches Fortran)
  if (SGMP_) {
    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      auto &cd = grid_->getCellProperty(i);
      cd.setMomentum({0.0, 0.0, 0.0});
    }
  }

  // Step 1: Reset grid momentum (PXg in Fortran)
  for (int comp = 1; comp <= grid_->getNumComponents(); ++comp) {
    for (int i = 0; i < grid_->getNumNodes(); ++i) {
      auto &node_prop = grid_->getNodeProperty(comp, i);
      node_prop.setMomentum({0, 0, 0});
      // Note: In Fortran, mass is NOT reset in GridMomentumMUSL
      // Only momentum is reset to 0.0
    }
  }

  // Step 2: Map particle velocities to grid
  for (size_t b = 0; b < bodies_->size(); ++b) {
    const Body &body = (*bodies_)[b];
    int par_begin = body.getParticleBegin();
    int par_end = body.getParticleEnd();
    int com_id = contact_enabled_ ? body.getComponentID() : 1;

    for (int p = par_begin; p < par_end; ++p) {
      const Particle &pt = (*particles_)[p];
      if (!isParticleLocal(pt)) {
        continue;
      }

      const Real mp = pt.getMass();
      const Vec3 vxp = pt.getVelocity();

      if (SGMP_) {
        const int center_cell = pt.getCenterCell();
        if (center_cell < 0)
          continue;

        infl_nodes_.clear();
        shape_values_.clear();
        shape_gradients_.clear();
        shape_func_->evaluateAuxiliary(pt, *grid_, infl_nodes_, shape_values_,
                                       shape_gradients_);

        for (size_t n = 0; n < infl_nodes_.size(); ++n) {
          const int aux_id = infl_nodes_[n];
          if (aux_id < 0 || aux_id >= grid_->getNumCenterCells())
            continue;
          const Real shm = shape_values_[n] * mp;
          auto &cd = grid_->getCellProperty(aux_id);
          cd.setMomentum(cd.getMomentum() + shm * vxp);
        }
        continue;
      }

      int icell = pt.getCell();
      if (icell < 0)
        continue;

      infl_nodes_.clear();
      shape_values_.clear();
      shape_gradients_.clear();

      shape_func_->evaluate(pt, *grid_, infl_nodes_, shape_values_, shape_gradients_);

      for (size_t n = 0; n < infl_nodes_.size(); ++n) {
        int node_id = infl_nodes_[n];
        if (node_id < 0 || node_id >= grid_->getNumNodes())
          continue;

        Real shm = shape_values_[n] * mp;
        auto &node_prop = grid_->getNodeProperty(com_id, node_id);
        node_prop.setMomentum(node_prop.getMomentum() + shm * vxp);
      }
    }
  }

  // SGMP: transfer auxiliary momentum to background nodal momentum (0.125 * Cpxg)
  if (SGMP_) {
    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      const auto &cd = grid_->getCellProperty(i);
      const Vec3 cpxg = cd.getMomentum();
      const auto infl = grid_->getCellNodes(i);
      for (int j = 0; j < 8; ++j) {
        const int node_id = infl[j];
        if (node_id < 0 || node_id >= grid_->getNumNodes())
          continue;
        auto &gd = grid_->getNodeProperty(1, node_id);
        gd.setMomentum(gd.getMomentum() + 0.125 * cpxg);
      }
    }
  }

  if (dd_allreduce_) {
    if (dd_exchange_nodes_ && dd_filter_particles_ &&
        grid_->getDecompSize() > 1 && grid_->getDecompGhost() > 0) {
      grid_->exchangeNodeMomentum();
    } else {
      grid_->allreduceNodeMomentum();
    }
  }

  // Step 3: Update node velocities from momentum (for use in subsequent calculations)
  // In Fortran, velocities are computed on-the-fly as PXg/Mg
  // In C++, we store velocities for efficiency, so we must update them after momentum changes
  for (int comp = 1; comp <= grid_->getNumComponents(); ++comp) {
    for (int i = 0; i < grid_->getNumNodes(); ++i) {
      auto &node_prop = grid_->getNodeProperty(comp, i);
      Real mass = node_prop.getMass();
      if (mass > cutoff_) {
        Vec3 vel = node_prop.getMomentum() / mass;
        node_prop.setVelocity(vel);
      } else {
        node_prop.setVelocity({0.0, 0.0, 0.0});
      }
    }
  }
}

bool UpdateStep::isParticleLocal(const Particle& pt) const {
  if (dd_strict_) return true;
  if (!dd_filter_particles_) return true;
  if (!grid_ || !grid_->isDecompositionActive()) return true;
  return pt.getOwnerRank() == grid_->getDecompRank();
}

bool UpdateStep::isParticleStateLocal(const Particle& pt) const {
  if (dd_strict_) return true;
  if (!dd_filter_particles_) return true;
  if (!grid_ || !grid_->isDecompositionActive()) return true;
  // In replicated-particle mode (no migration), all ranks must evolve all
  // particle state fields only when replica balancing is enabled.
  if (!dd_migrate_particles_) return dd_balance_replica_ ? true : isParticleLocal(pt);
  return pt.getOwnerRank() == grid_->getDecompRank();
}

namespace {

struct ParticlePack {
  Real XX[3];
  Real Xp[3];
  Real Xo[3];
  Real VXp[3];
  Real FXp[3];
  Real XN[3];
  Real XXN[3];
  int icell;
  int centericell;
  int inode;
  int owner_rank;
  int body_id;
  Real mass;
  Real VOL;
  Real VOL0;
  Real SM;
  Real Seqv;
  Real SDxx, SDyy, SDzz;
  Real SDxy, SDyz, SDxz;
  Real Spre;
  Real PK[9];
  Real Fp[9];
  Real sig_y;
  Real epeff;
  Real DMG;
  int failure;
  Real celsius_t;
  Real ie;
  Real cp;
  Real q;
  Real LT;
  int SkipThis;
};

static_assert(std::is_trivially_copyable<ParticlePack>::value,
              "ParticlePack must be trivially copyable for MPI_BYTE transfers.");

ParticlePack packParticle(const Particle& pt) {
  ParticlePack pk{};
  const Vec3 xx = pt.getPosition();
  const Vec3 xp = pt.getPositionPrev();
  const Vec3 xo = pt.getPositionInitial();
  const Vec3 vx = pt.getVelocity();
  const Vec3 fx = pt.getExternalForce();
  const Vec3 xn = pt.getNaturalCoords();
  const Vec3 xxn = pt.getNaturalCoordsAux();
  pk.XX[0] = xx[0]; pk.XX[1] = xx[1]; pk.XX[2] = xx[2];
  pk.Xp[0] = xp[0]; pk.Xp[1] = xp[1]; pk.Xp[2] = xp[2];
  pk.Xo[0] = xo[0]; pk.Xo[1] = xo[1]; pk.Xo[2] = xo[2];
  pk.VXp[0] = vx[0]; pk.VXp[1] = vx[1]; pk.VXp[2] = vx[2];
  pk.FXp[0] = fx[0]; pk.FXp[1] = fx[1]; pk.FXp[2] = fx[2];
  pk.XN[0] = xn[0]; pk.XN[1] = xn[1]; pk.XN[2] = xn[2];
  pk.XXN[0] = xxn[0]; pk.XXN[1] = xxn[1]; pk.XXN[2] = xxn[2];
  pk.icell = pt.getCell();
  pk.centericell = pt.getCenterCell();
  pk.inode = pt.getNode();
  pk.owner_rank = pt.getOwnerRank();
  pk.body_id = pt.getBodyId();
  pk.mass = pt.getMass();
  pk.VOL = pt.getVolume();
  pk.VOL0 = pt.getVolumeInitial();
  pk.SM = pt.getMeanStress();
  pk.Seqv = pt.getEquivalentStress();
  pk.SDxx = pt.getSDxx();
  pk.SDyy = pt.getSDyy();
  pk.SDzz = pt.getSDzz();
  pk.SDxy = pt.getSDxy();
  pk.SDyz = pt.getSDyz();
  pk.SDxz = pt.getSDxz();
  pk.Spre = pt.getSmoothedPressure();
  const Vec9& pkstress = pt.getPKStress();
  for (int i = 0; i < 9; ++i) pk.PK[i] = pkstress[i];
  const Mat3& Fp = pt.getDeformationGradient();
  int idx = 0;
  for (int i = 0; i < 3; ++i) {
    for (int j = 0; j < 3; ++j) {
      pk.Fp[idx++] = Fp[i][j];
    }
  }
  pk.sig_y = pt.getYieldStress();
  pk.epeff = pt.getPlasticStrain();
  pk.DMG = pt.getDamage();
  pk.failure = pt.hasFailed() ? 1 : 0;
  pk.celsius_t = pt.getTemperature();
  pk.ie = pt.getInternalEnergy();
  pk.cp = pt.getSoundSpeed();
  pk.q = pt.getBulkViscosity();
  pk.LT = pt.getLightingTime();
  pk.SkipThis = pt.shouldSkip() ? 1 : 0;
  return pk;
}

Particle unpackParticle(const ParticlePack& pk) {
  Particle pt;
  pt.setPosition({pk.XX[0], pk.XX[1], pk.XX[2]});
  pt.setPositionPrev({pk.Xp[0], pk.Xp[1], pk.Xp[2]});
  pt.setPositionInitial({pk.Xo[0], pk.Xo[1], pk.Xo[2]});
  pt.setVelocity({pk.VXp[0], pk.VXp[1], pk.VXp[2]});
  pt.setExternalForce({pk.FXp[0], pk.FXp[1], pk.FXp[2]});
  pt.setNaturalCoords({pk.XN[0], pk.XN[1], pk.XN[2]});
  pt.setNaturalCoordsAux({pk.XXN[0], pk.XXN[1], pk.XXN[2]});
  pt.setCell(pk.icell);
  pt.setCenterCell(pk.centericell);
  pt.setNode(pk.inode);
  pt.setOwnerRank(pk.owner_rank);
  pt.setBodyId(pk.body_id);
  pt.setMass(pk.mass);
  pt.setVolume(pk.VOL);
  pt.setVolumeInitial(pk.VOL0);
  pt.setMeanStress(pk.SM);
  pt.setEquivalentStress(pk.Seqv);
  pt.setDeviatoricStress(pk.SDxx, pk.SDyy, pk.SDzz, pk.SDxy, pk.SDyz, pk.SDxz);
  pt.setSmoothedPressure(pk.Spre);
  Vec9 pkstress{};
  for (int i = 0; i < 9; ++i) pkstress[i] = pk.PK[i];
  pt.setPKStress(pkstress);
  Mat3 Fp{};
  int idx = 0;
  for (int i = 0; i < 3; ++i) {
    for (int j = 0; j < 3; ++j) {
      Fp[i][j] = pk.Fp[idx++];
    }
  }
  pt.setDeformationGradient(Fp);
  pt.setYieldStress(pk.sig_y);
  pt.setPlasticStrain(pk.epeff);
  pt.setDamage(pk.DMG);
  pt.setFailure(pk.failure != 0);
  pt.setTemperature(pk.celsius_t);
  pt.setInternalEnergy(pk.ie);
  pt.setSoundSpeed(pk.cp);
  pt.setBulkViscosity(pk.q);
  pt.setLightingTime(pk.LT);
  pt.setSkip(pk.SkipThis != 0);
  return pt;
}

} // namespace

void UpdateStep::rebuildBodyRanges() {
  if (!particles_ || !bodies_) return;
  const int num_bodies = static_cast<int>(bodies_->size());
  if (num_bodies <= 0) return;

  std::vector<std::vector<Particle>> by_body(static_cast<size_t>(num_bodies));

  for (const Particle& pt : *particles_) {
    int bid = pt.getBodyId();
    if (bid < 0 || bid >= num_bodies) {
      bid = 0;
    }
    by_body[static_cast<size_t>(bid)].push_back(pt);
  }

  ParticleList reordered;
  reordered.reserve(particles_->size());
  int cursor = 0;
  for (int b = 0; b < num_bodies; ++b) {
    const auto& group = by_body[static_cast<size_t>(b)];
    int begin = cursor;
    for (const Particle& pt : group) {
      reordered.push_back(pt);
      ++cursor;
    }
    int end = cursor;
    Body& body = (*bodies_)[static_cast<size_t>(b)];
    body.setParticleRange(begin, end);
  }

  particles_->swap(reordered);
}

void UpdateStep::migrateParticles(bool use_current_position) {
#if defined(MPM3D_USE_MPI)
  if (!dd_migrate_particles_) return;
  if (!grid_ || !grid_->isDecompositionActive()) return;

  int mpi_initialized = 0;
  MPI_Initialized(&mpi_initialized);
  if (!mpi_initialized) return;

  const int world_size = grid_->getDecompSize();
  const int world_rank = grid_->getDecompRank();
  if (world_size <= 1) return;

  std::vector<std::vector<ParticlePack>> send_bins(static_cast<size_t>(world_size));
  std::vector<ParticlePack> keep;
  keep.reserve(particles_->size());

  for (Particle& pt : *particles_) {
    const Vec3 pos_owner = use_current_position ? pt.getPosition() : pt.getPositionPrev();
    const int icell = grid_->findCell(pos_owner);
    pt.setCell(icell);

    int owner = world_rank;
    if (icell >= 0) {
      owner = grid_->ownerRankForCell(icell);
    }
    pt.setOwnerRank(owner);

    ParticlePack pk = packParticle(pt);
    if (owner == world_rank) {
      keep.push_back(pk);
    } else if (owner >= 0 && owner < world_size) {
      send_bins[static_cast<size_t>(owner)].push_back(pk);
    } else {
      keep.push_back(pk);
    }
  }

  std::vector<int> send_counts(world_size, 0);
  for (int r = 0; r < world_size; ++r) {
    send_counts[r] = static_cast<int>(send_bins[static_cast<size_t>(r)].size());
  }

  std::vector<int> recv_counts(world_size, 0);
  MPI_Alltoall(send_counts.data(), 1, MPI_INT,
               recv_counts.data(), 1, MPI_INT, MPI_COMM_WORLD);

  std::vector<int> send_displs(world_size, 0);
  std::vector<int> recv_displs(world_size, 0);
  int total_send = 0;
  int total_recv = 0;
  for (int r = 0; r < world_size; ++r) {
    send_displs[r] = total_send;
    recv_displs[r] = total_recv;
    total_send += send_counts[r];
    total_recv += recv_counts[r];
  }

  std::vector<ParticlePack> send_flat(static_cast<size_t>(total_send));
  for (int r = 0; r < world_size; ++r) {
    const auto& src = send_bins[static_cast<size_t>(r)];
    const int offset = send_displs[r];
    for (size_t i = 0; i < src.size(); ++i) {
      send_flat[static_cast<size_t>(offset) + i] = src[i];
    }
  }

  std::vector<ParticlePack> recv_flat(static_cast<size_t>(total_recv));

  std::vector<int> send_counts_bytes(world_size, 0);
  std::vector<int> recv_counts_bytes(world_size, 0);
  std::vector<int> send_displs_bytes(world_size, 0);
  std::vector<int> recv_displs_bytes(world_size, 0);
  const int pack_bytes = static_cast<int>(sizeof(ParticlePack));
  for (int r = 0; r < world_size; ++r) {
    send_counts_bytes[r] = send_counts[r] * pack_bytes;
    recv_counts_bytes[r] = recv_counts[r] * pack_bytes;
    send_displs_bytes[r] = send_displs[r] * pack_bytes;
    recv_displs_bytes[r] = recv_displs[r] * pack_bytes;
  }

  MPI_Alltoallv(send_flat.data(), send_counts_bytes.data(),
                send_displs_bytes.data(), MPI_BYTE,
                recv_flat.data(), recv_counts_bytes.data(),
                recv_displs_bytes.data(), MPI_BYTE,
                MPI_COMM_WORLD);

  ParticleList merged;
  merged.reserve(static_cast<size_t>(keep.size() + recv_flat.size()));
  for (const ParticlePack& pk : keep) {
    merged.push_back(unpackParticle(pk));
  }
  for (const ParticlePack& pk : recv_flat) {
    merged.push_back(unpackParticle(pk));
  }

  particles_->swap(merged);
  rebuildBodyRanges();
#endif
}

void UpdateStep::migrateParticlesInitial() {
#if defined(MPM3D_USE_MPI)
  if (!dd_migrate_particles_) return;
  migrateParticles(false);
#endif
}
// ============================================================================
// Contact - Lagrangian Node Contact
// ============================================================================

void UpdateStep::lagr_NodContact() {
  // Purpose: Detect and resolve contact between bodies
  // Matches Fortran Lagr_NodContact in update_step.f90

  if (!contact_enabled_ || grid_->getNumComponents() <= 1)
    return;

  // Call contact detection and resolution
  contact_.detectAndResolve(*grid_, *particles_, *bodies_, dt_);
}

// ============================================================================
// Total Lagrangian Functions (stubs for now)
// ============================================================================

void UpdateStep::gridMassInitial() {
  // Map particle mass to grid nodes (for TLMPM initialization)
  // From GridMassInitial() in update_step.f90
  // This is called once before TLMPM main loop

  // Reset grid masses
  grid_->resetGridProperties();

  if (SGMP_) {
    grid_->resetAuxiliaryGrid();
  }

  // Initialize particle positions
  particleInitial(); // Set cells and natural coordinates

  // Map masses to grid
  for (size_t b = 0; b < bodies_->size(); ++b) {
    const Body &body = (*bodies_)[b];
    int par_begin = body.getParticleBegin();
    int par_end = body.getParticleEnd();
    int comp_id = body.getComponentID();

    for (int p = par_begin; p < par_end; ++p) {
      Particle &pt = (*particles_)[p];
      if (!isParticleLocal(pt)) {
        continue;
      }

      if (SGMP_) {
        int center_cell = pt.getCenterCell();
        if (center_cell < 0)
          continue;

        Real mass = pt.getMass();

        // Evaluate shape functions on auxiliary grid
        infl_nodes_.clear();
        shape_values_.clear();
        shape_gradients_.clear();
        shape_func_->evaluateAuxiliary(pt, *grid_, infl_nodes_, shape_values_,
                                       shape_gradients_);

        // Map mass to auxiliary grid
        for (size_t n = 0; n < infl_nodes_.size(); ++n) {
          int node_id = infl_nodes_[n];
          if (node_id < 0 || node_id >= grid_->getNumCenterCells())
            continue;

          CellDataProperty &cell_prop = grid_->getCellProperty(node_id);
          Real shm = shape_values_[n] * mass;
          cell_prop.addMass(shm);
        }
      } else {
        int cell_id = pt.getCell();
        if (cell_id < 0)
          continue;

        Real mass = pt.getMass();

        // Evaluate shape functions
        infl_nodes_.clear();
        shape_values_.clear();
        shape_gradients_.clear();
        shape_func_->evaluate(pt, *grid_, infl_nodes_, shape_values_, shape_gradients_);

        // Map mass to grid nodes
        for (size_t n = 0; n < infl_nodes_.size(); ++n) {
          int node_id = infl_nodes_[n];
          if (node_id < 0 || node_id >= grid_->getNumNodes())
            continue;

          GridNodeProperty &node_prop =
              grid_->getNodeProperty(comp_id, node_id);
          Real shm = shape_values_[n] * mass;
          node_prop.addMass(shm);
        }
      }
    }
  }

  // Transfer auxiliary grid mass to background grid (SGMP)
  if (SGMP_) {
    int comp_id = 1; // Default component
    for (int i = 0; i < grid_->getNumCenterCells(); ++i) {
      CellDataProperty &cell_prop = grid_->getCellProperty(i);
      if (cell_prop.getMass() > cutoff_) {
        auto cell_nodes = grid_->getCellNodes(i);
        for (int j = 0; j < 8; ++j) {
          int node_id = cell_nodes[j];
          if (node_id >= 0 && node_id < grid_->getNumNodes()) {
            GridNodeProperty &node_prop =
                grid_->getNodeProperty(comp_id, node_id);
            node_prop.addMass(0.125 * cell_prop.getMass());
          }
        }
      }
    }
  }
}

void UpdateStep::TLParticleInitial() {
  // Similar to particleInitial but for TLMPM
  particleInitial();
}

void UpdateStep::TLGridMomentumInitial() {
  // Similar to gridMomentumInitial but for TLMPM
  gridMomentumInitial();
}

void UpdateStep::TLParticleStressUpdate() {
  // Uses TLConstitution instead of Constitution
  // Most logic is same as particleStressUpdate
  particleStressUpdate();
}

void UpdateStep::TLGridMomentumUpdate() {
  // Similar to gridMomentumUpdate but uses PK stress
  gridMomentumUpdate();
}

void UpdateStep::TLSmoothStressByGrid() {
  // Similar to smoothStressByGrid
  smoothStressByGrid();
}

} // namespace mpm3d
