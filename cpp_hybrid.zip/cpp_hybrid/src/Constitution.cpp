#include "Constitution.hpp"
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <stdexcept>

namespace mpm3d {

ConstitutionModel::ConstitutionModel()
    : mid_(0), mtype_(MaterialType::ELASTIC), etype_(EosType::NONE), young_(0),
      poisson_(0), yield0_(0), tangmod_(0), den0_(0), den_(0), vold_(0),
      vol_(0), vol0_(0), dvol_(0), sm_(0), smold_(0), dsm_(0), bqf_(0),
      seqv_(0), epeff_(0), sig_y_(0), depeff_(0), ratio_(0), G2_(0), K3_(0),
      PlaMod_(0), lamda_(0), miu2_(0), specheat_(0), tmprt_(293.0), iener_(0),
      specen_(0), ieinc_(0), mu_(0), rv_(0), bfac_(0), cp_(0), DMG_(0),
      oldDMG_(0), dt_(0), current_time_(0), cell_size_(0), bq1_(1.5),
      bq2_(0.06), Jaum_(true) {

  dinc_.fill(0);
  deF_ = zero_mat3();
  sd_.fill(0);
  Fp_ = identity_mat3();
  ppk_old_.fill(0);
  ppk_new_.fill(0);
  sig_.fill(0);
  sold_.fill(0);
}

void ConstitutionModel::constitution(const Vec6 &strain_increment,
                                     const Vec3 &vorticity,
                                     const Mat3 &vel_gradient, int body_id,
                                     int particle_id, const BodyList &body_list,
                                     ParticleList &particle_list,
                                     const MaterialList &material_list, Real dt,
                                     Real current_time, Real cell_size) {

  dt_ = dt;
  current_time_ = current_time;
  cell_size_ = cell_size;

  dinc_ = strain_increment;
  deF_ = vel_gradient;
  ieinc_ = 0.0;
  bqf_ = 0.0;
  Particle &pt = particle_list[particle_id];
  vold_ = pt.getVolume();
  vol_ = vold_ * (1 + dinc_[0] + dinc_[1] + dinc_[2]);
  if (vol_ <= 0.0) {
    // Fortran prints a warning when volume goes negative; it typically shouldn't
    // happen for stable runs. Clamp to a tiny positive value to avoid
    // negative density / runaway bulk viscosity.
    std::cerr << "=== warning: negative volume at particle " << particle_id
              << std::endl;
    vol_ = vold_;
  }
  pt.setVolume(vol_);
  dvol_ = 0.5 * (vol_ - vold_);

  mid_ = body_list[body_id].getMaterialID();
  const Material &mat = material_list.getMaterial(mid_);
  epeff_ = pt.getPlasticStrain();
  sig_y_ = pt.getYieldStress();
  seqv_ = pt.getEquivalentStress();
  Real ltim = pt.getLightingTime();
  tmprt_ = pt.getTemperature();
  iener_ = pt.getInternalEnergy();
  Real mp = pt.getMass();
  bool failure = pt.hasFailed();
  mtype_ = mat.getMaterialType();
  etype_ = mat.getEosType();
  miu2_ = 2.0 * mat.getDynamicViscosity();
  young_ = mat.getYoungsModulus();
  poisson_ = mat.getPoissonsRatio();
  yield0_ = mat.getYieldStress();
  tangmod_ = mat.getTangentModulus();
  den0_ = mat.getDensity();
  vol0_ = mp / den0_;
  den_ = mp / vol_;
  mu_ = den_ / den0_ - 1.0;
  rv_ = vol_ / vol0_;
  specen_ = iener_ / vol0_;
  DMG_ = pt.getDamage();
  oldDMG_ = DMG_;
  young_ = young_ * (1.0 - DMG_ + EPSILON);
  G2_ = young_ / (1.0 + poisson_);
  K3_ = young_ / (1.0 - 2.0 * poisson_);
  lamda_ = (young_ * poisson_) / ((1.0 + poisson_) * (1.0 - 2.0 * poisson_));
  PlaMod_ = young_ * tangmod_ / (young_ - tangmod_);
  cp_ = pt.getSoundSpeed();
  sm_ = pt.getMeanStress();
  smold_ = pt.getMeanStress();
  sd_[0] = pt.getSDxx();
  sd_[1] = pt.getSDyy();
  sd_[2] = pt.getSDzz();
  sd_[3] = pt.getSDyz();
  sd_[4] = pt.getSDxz();
  sd_[5] = pt.getSDxy();
  sig_[0] = sd_[0] + sm_;
  sig_[1] = sd_[1] + sm_;
  sig_[2] = sd_[2] + sm_;
  sig_[3] = sd_[3];
  sig_[4] = sd_[4];
  sig_[5] = sd_[5];
  sold_ = sd_;
  bqf_ = 0.0;

  switch (mtype_) {
  case MaterialType::ELASTIC:
    stressRotation(vorticity, sig_, sm_, sd_);
    M3DM1_Elastic();
    updateEnergyLie();
    break;
  case MaterialType::ELASTIC_PERFECT_PLASTIC:
    stressRotation(vorticity, sig_, sm_, sd_);
    M3DM2_ElasticPerfectPlastic();
    updateEnergyLie();
    break;
  case MaterialType::ISOTROPIC_HARDENING:
    stressRotation(vorticity, sig_, sm_, sd_);
    M3DM3_IsotropicHardening();
    updateEnergyLie();
    break;
  case MaterialType::JOHNSON_COOK:
    stressRotation(vorticity, sig_, sm_, sd_);
    M3DM4_JohnsonCook(mat, dt, tmprt_);
    if (sm_ < 0)
      computeBulkViscosity();
    ieinc_ = ieinc_ - 2.0 * bqf_ * (dinc_[0] + dinc_[1] + dinc_[2]);
    updateEnergyLie();
    specheat_ = mat.getSpecificHeat();
    tmprt_ = tmprt_ + seqv_ * depeff_ / den_ / specheat_;
    pt.setTemperature(tmprt_);
    break;
  case MaterialType::SIMPLIFIED_JC:
    stressRotation(vorticity, sig_, sm_, sd_);
    M3DM5_SimplifiedJC(mat, dt);
    if (etype_ == EosType::LINEAR_POLYNOMIAL)
      linearPolynomialEOS(mat);
    else if (etype_ == EosType::GRUNEISEN)
      gruneisenEOS(mat);
    else if (etype_ == EosType::JWL)
      JWLEOS(mat);
    else if (etype_ == EosType::TAIT)
      taitEOS(mat);
    break;
  case MaterialType::HIGH_EXPLOSIVE:
    // Match Fortran exactly: M3DM6 sets bfac, then seleos calls eos
    // Note: sold_ and sd_ are NOT zeroed here - they keep previous values
    // For high explosives, deviatoric stress should be zero, but we don't
    // explicitly zero it to match Fortran behavior exactly
    //
    // However, in the Fortran code path for high explosives, deviatoric stress
    // is effectively always zero and hieupd() should not include any shear-work
    // contribution from (sold+sd). Ensure sd/sold are zero BEFORE EOS so the
    // energy update matches Fortran.
    sd_.fill(0);
    sold_.fill(0);
    M3DM6_HighExplosive(ltim, current_time, mat.getDetonationVelocity());
    if (etype_ == EosType::JWL)
      JWLEOS(mat);
    else
      selectEquationOfState(failure);
    // After EOS, set deviatoric stress to zero (matches Fortran behavior
    // where sd is never updated for high explosives, so it remains zero)
    sd_.fill(0);

    {
      const char *dbg_env = std::getenv("MPM3D_SGMP_DEBUG");
      const bool dbg = (dbg_env && std::string(dbg_env) != "0");
      const char *pid_env = std::getenv("MPM3D_DBG_PID");
      const int dbg_pid = pid_env ? std::atoi(pid_env) : -1;
      if (dbg && dbg_pid >= 0 && particle_id == dbg_pid) {
        std::cout.setf(std::ios::scientific);
        std::cout.precision(6);
        std::cout << "EOS_DBG pid=" << particle_id << " time=" << current_time_
                  << " rv=" << rv_ << " specen=" << specen_ << " bfac=" << bfac_
                  << " sm=" << sm_ << " ie=" << iener_ << " vol=" << vol_
                  << " dvol=" << dvol_ << std::endl;
        std::cout.unsetf(std::ios::scientific);
      }
    }
    break;
  case MaterialType::SIMPLIFIED_JC_FAILURE:
    stressRotation(vorticity, sig_, sm_, sd_);
    if (!pt.hasFailed()) {
      M3DM5_SimplifiedJC(mat, dt);
      selectEquationOfState(failure);
      if (epeff_ > mat.getPlasticStrainAtFailure()) {
        epeff_ = mat.getPlasticStrainAtFailure() + 0.0000001;
        failure = true;
      }
      if (failure && sm_ < 0) {
        sm_ = 0.0;
        bqf_ = 0.0;
        vol_ = vold_;
        pt.setVolume(vol_);
      }
      if (failure) {
        sd_.fill(0);
        iener_ = iener_ - ieinc_ + dvol_ * (smold_ + sm_ - 2.0 * bqf_);
      }
      pt.setFailure(failure);
    } else {
      M3DM7_Null(dt);
      selectEquationOfState(failure);
    }
    specheat_ = mat.getSpecificHeat();
    tmprt_ = tmprt_ + seqv_ * depeff_ / den_ / specheat_;
    pt.setTemperature(tmprt_);
    break;
  case MaterialType::JC_FAILURE:
    stressRotation(vorticity, sig_, sm_, sd_);
    if (!pt.hasFailed()) {
      M3DM8_JCWithFailure(mat, dt, tmprt_, failure);
      selectEquationOfState(failure);
      if (epeff_ > mat.getPlasticStrainAtFailure()) {
        epeff_ = mat.getPlasticStrainAtFailure() + 0.0000001;
        DMG_ = 1.0;
        failure = true;
      } else {
        DMG_ = oldDMG_ + depeff_ / mat.getPlasticStrainAtFailure();
        if (DMG_ >= 1.0)
          DMG_ = 1.0;
        Real DMGRatio = (1.0 - DMG_) / (1.0 - oldDMG_);
        for (int i = 0; i < 6; ++i)
          sd_[i] *= DMGRatio;
        if (std::abs(DMG_ - 1.0) < 1e-5)
          failure = true;
      }
      if (failure && sm_ < 0) {
        sm_ = 0.0;
        bqf_ = 0.0;
        vol_ = vold_;
        pt.setVolume(vol_);
      }
      if (failure) {
        sd_.fill(0);
        iener_ = iener_ - ieinc_ + dvol_ * (smold_ + sm_ - 2.0 * bqf_);
      }
      pt.setFailure(failure);
    } else {
      M3DM7_Null(dt);
      selectEquationOfState(failure);
    }
    break;
  case MaterialType::DRUCKER_PRAGER:
    stressRotation(vorticity, sig_, sm_, sd_);
    M3DM9_DruckerPrager(mat, dt);
    updateEnergyLie();
    break;
  case MaterialType::RIGID_BODY:
    // Rigid body - no stress update, just skip
    break;
  default:
    break;
  }

  pt.setMeanStress(sm_);
  pt.setEquivalentStress(seqv_);
  pt.setDeviatoricStress(sd_[0], sd_[1], sd_[2], sd_[5], sd_[3], sd_[4]);
  pt.setYieldStress(sig_y_);
  pt.setPlasticStrain(epeff_);
  pt.setInternalEnergy(iener_);
  pt.setSoundSpeed(cp_);
  pt.setBulkViscosity(bqf_);
  pt.setDamage(DMG_);
}

void ConstitutionModel::stressRotation(const Vec3 &vorticity, Vec6 &sig,
                                       Real &sm, Vec6 &sd) {
  if (!Jaum_)
    return;
  // Exact port of Fortran sigrot() (src/Constitution.f90:527-575)
  // vorticity = (W32, W13, W21)*DT
  const Real vort1 = vorticity[0];
  const Real vort2 = vorticity[1];
  const Real vort3 = vorticity[2];

  // Voigt mapping: sig = (S11,S22,S33,S23,S13,S12) = (xx,yy,zz,yz,xz,xy)
  const Real q1 = 2.0 * sig[5] * vort3; // 2*sig(6)*vort(3)
  const Real q2 = 2.0 * sig[4] * vort2; // 2*sig(5)*vort(2)
  const Real q3 = 2.0 * sig[3] * vort1; // 2*sig(4)*vort(1)

  Vec6 rot;
  rot[0] = -q1 + q2;
  rot[1] = +q1 - q3;
  rot[2] = -q2 + q3;
  rot[3] = vort1 * (sig[1] - sig[2]) + vort3 * sig[4] - vort2 * sig[5];
  rot[4] = vort2 * (sig[2] - sig[0]) + vort1 * sig[5] - vort3 * sig[3];
  rot[5] = vort3 * (sig[0] - sig[1]) + vort2 * sig[3] - vort1 * sig[4];

  for (int i = 0; i < 6; ++i)
    sig[i] += rot[i];

  sm = (sig[0] + sig[1] + sig[2]) / 3.0;
  sd[0] = sig[0] - sm;
  sd[1] = sig[1] - sm;
  sd[2] = sig[2] - sm;
  sd[3] = sig[3];
  sd[4] = sig[4];
  sd[5] = sig[5];
}

void ConstitutionModel::M3DM1_Elastic() {
  ieinc_ = 0.0;
  for (int i = 0; i < 6; ++i) {
    ieinc_ += sig_[i] * dinc_[i];
  }

  elasticDeviatoricUpdate();
  elasticPressureUpdate();
  seqv_ = computeEquivalentStress(sd_);

  for (int i = 0; i < 3; ++i) {
    ieinc_ += (sd_[i] + sm_) * dinc_[i];
  }
  ieinc_ += sd_[3] * dinc_[3] + sd_[4] * dinc_[4] + sd_[5] * dinc_[5];

  updateEnergyLie();
}

void ConstitutionModel::M3DM2_ElasticPerfectPlastic() {
  elasticDeviatoricUpdate();
  elasticPressureUpdate();
  seqv_ = computeEquivalentStress(sd_);
  if (seqv_ > yield0_) {
    ratio_ = yield0_ / seqv_;
    for (int i = 0; i < 6; ++i)
      sd_[i] *= ratio_;
    seqv_ = yield0_;
  }
}

void ConstitutionModel::M3DM3_IsotropicHardening() {
  elasticDeviatoricUpdate();
  elasticPressureUpdate();
  seqv_ = computeEquivalentStress(sd_);
  if (seqv_ > sig_y_) {
    depeff_ = (seqv_ - sig_y_) / (1.5 * G2_ + PlaMod_);
    epeff_ += depeff_;
    sig_y_ += PlaMod_ * depeff_;
    ratio_ = sig_y_ / seqv_;
    for (int i = 0; i < 6; ++i)
      sd_[i] *= ratio_;
    seqv_ = sig_y_;
  }
}

void ConstitutionModel::M3DM4_JohnsonCook(const Material &mat, Real dt,
                                          Real temperature) {
  // Johnson-Cook plasticity model implementation
  // σ = [A + B·εⁿ] · [1 + C·ln(ε̇/ε₀)] · [1 - T*ᵐ]
  
  elasticDeviatoricUpdate();
  elasticPressureUpdate();
  seqv_ = computeEquivalentStress(sd_);
  
  // Get Johnson-Cook parameters
  Real A = mat.getYieldStress();  // Initial yield stress
  Real B = mat.getJC_B();         // Hardening constant
  Real n = mat.getJC_n();         // Hardening exponent
  Real C = mat.getJC_C();         // Strain rate coefficient
  Real epso = mat.getJC_epso();   // Reference strain rate
  Real Troom = mat.getRoomTemperature();
  Real Tmelt = mat.getMeltingTemperature();
  Real m = mat.getJC_m();         // Thermal exponent
  
  // Calculate strain rate
  Real srate = std::sqrt(2.0 * dinc_[0] * dinc_[0] + 2.0 * dinc_[1] * dinc_[1] + 
                     2.0 * dinc_[2] * dinc_[2] + dinc_[3] * dinc_[3] + 
                     dinc_[4] * dinc_[4] + dinc_[5] * dinc_[5]) / dt;
  
  // Prevent division by zero
  if (srate < 1e-10) srate = 1e-10;
  if (epso < 1e-10) epso = 1e-10;
  
  // Calculate temperature factor
  Real Tstar = 0.0;
  if (Tmelt > Troom) {
    Tstar = (temperature - Troom) / (Tmelt - Troom);
    if (Tstar < 0.0) Tstar = 0.0;
    if (Tstar > 1.0) Tstar = 1.0;
  }
  
  // Johnson-Cook yield stress
  Real strain_hardening = A + B * std::pow(epeff_, n);
  Real strain_rate_factor = 1.0 + C * std::log(srate / epso);
  Real thermal_factor = 1.0 - std::pow(Tstar, m);
  
  Real sig_y_jc = strain_hardening * strain_rate_factor * thermal_factor;
  
  // Calculate stress work for internal energy (matches Fortran)
  // ieinc = sig(1)*dinc(1) + sig(2)*dinc(2) + sig(3)*dinc(3) + sig(4)*dinc(4) + sig(5)*dinc(5) + sig(6)*dinc(6)
  // Use deviatoric stress components (sd_) + mean stress (sm_)
  Real sig1 = sd_[0] + sm_;  // σ11 = s11 + sm
  Real sig2 = sd_[1] + sm_;  // σ22 = s22 + sm  
  Real sig3 = sd_[2] + sm_;  // σ33 = s33 + sm
  Real sig4 = sd_[3];        // σ12 = s12
  Real sig5 = sd_[4];        // σ23 = s23
  Real sig6 = sd_[5];        // σ13 = s13
  
  ieinc_ = sig1 * dinc_[0] + sig2 * dinc_[1] + sig3 * dinc_[2] + 
             sig4 * dinc_[3] + sig5 * dinc_[4] + sig6 * dinc_[5];
  
  // Update stress if yield is exceeded
  if (seqv_ > sig_y_jc) {
    depeff_ = (seqv_ - sig_y_jc) / (1.5 * G2_ + PlaMod_);
    epeff_ += depeff_;
    
    // Update yield stress for next step
    sig_y_ = sig_y_jc;
    
    // Scale deviatoric stress
    ratio_ = sig_y_jc / seqv_;
    for (int i = 0; i < 6; ++i)
      sd_[i] *= ratio_;
    seqv_ = sig_y_jc;
  } else {
    sig_y_ = sig_y_jc;
  }
  
  // Apply bulk viscosity correction (matches Fortran line 228-230)
  ieinc_ = ieinc_ - 2.0 * bqf_ * (dinc_[0] + dinc_[1] + dinc_[2]);
}

void ConstitutionModel::elasticDeviatoricUpdate() {
  Real dem = (dinc_[0] + dinc_[1] + dinc_[2]) / 3.0;
  Real G = young_ / (2.0 * (1.0 + poisson_));
  sd_[0] += G2_ * (dinc_[0] - dem);
  sd_[1] += G2_ * (dinc_[1] - dem);
  sd_[2] += G2_ * (dinc_[2] - dem);
  sd_[3] += G * dinc_[3];
  sd_[4] += G * dinc_[4];
  sd_[5] += G * dinc_[5];
}

void ConstitutionModel::elasticPressureUpdate() {
  Real dem = (dinc_[0] + dinc_[1] + dinc_[2]) / 3.0;
  dsm_ = K3_ * dem;
  sm_ += dsm_;
}

Real ConstitutionModel::computeEquivalentStress(const Vec6 &dev_stress) {
  Real J2 =
      0.5 * (dev_stress[0] * dev_stress[0] + dev_stress[1] * dev_stress[1] +
             dev_stress[2] * dev_stress[2]) +
      dev_stress[3] * dev_stress[3] + dev_stress[4] * dev_stress[4] +
      dev_stress[5] * dev_stress[5];
  return std::sqrt(3.0 * J2);
}

void ConstitutionModel::updateEnergyLie() {
  if (sm_ < 0)
    computeBulkViscosity();
  ieinc_ = ieinc_ - 2.0 * bqf_ * (dinc_[0] + dinc_[1] + dinc_[2]);
  Real vavg = vol_ + vold_;
  iener_ = iener_ + 0.25 * ieinc_ * vavg;
}

void ConstitutionModel::updateEnergyHie(bool failure) {
  // Line-by-line translation from Fortran hieupd subroutine
  Real vavg;
  
  if (failure) {
    // Matches Fortran line 661
    ieinc_ = dvol_ * (smold_ - 2.0 * bqf_);
  } else {
    // Matches Fortran line 663
    vavg = vol_ + vold_;
    
    // Matches Fortran lines 665-667 exactly
    ieinc_ = dinc_[0] * (sold_[0] + sd_[0]) + 
             dinc_[1] * (sold_[1] + sd_[1]) + 
             dinc_[2] * (sold_[2] + sd_[2]) + 
             dinc_[3] * (sold_[3] + sd_[3]) + 
             dinc_[4] * (sold_[4] + sd_[4]) + 
             dinc_[5] * (sold_[5] + sd_[5]);
    
    // Matches Fortran line 669 exactly
    ieinc_ = 0.25 * ieinc_ * vavg + dvol_ * (smold_ - 2.0 * bqf_);
  }
  
  // Matches Fortran line 672 exactly
  iener_ = iener_ + ieinc_;
  
  // Matches Fortran line 674 exactly
  specen_ = iener_ / vol0_;
}

void ConstitutionModel::computeBulkViscosity() {
  Real dd = (dinc_[0] + dinc_[1] + dinc_[2]) / dt_;
  if (dd < 0.0) {
    bqf_ = den_ * cell_size_ * cell_size_ * bq1_ * dd * dd -
           bq2_ * den_ * cell_size_ * cp_ * dd;
  } else {
    bqf_ = 0.0;
  }
}

void ConstitutionModel::M3DM5_SimplifiedJC(const Material &mat, Real dt) {
  Real Bjc = mat.getJC_B();
  Real njc = mat.getJC_n();
  Real Cjc = mat.getJC_C();
  Real epso = mat.getJC_epso();

  epeff_ += 0.0001;
  Real PlaMod = Bjc * njc * std::pow(epeff_, njc - 1.0);
  epeff_ -= 0.0001;

  elasticDeviatoricUpdate();
  seqv_ = computeEquivalentStress(sd_);

  if (seqv_ > sig_y_) {
    Real G2 = young_ / (1.0 + poisson_);
    Real depeff = (seqv_ - sig_y_) / (1.5 * G2 + PlaMod);
    epeff_ += depeff;

    Real srate = depeff / epso / dt;
    if (srate < 0.001)
      srate = 0.001;

    sig_y_ =
        (yield0_ + Bjc * std::pow(epeff_, njc)) * (1.0 + Cjc * std::log(srate));

    if (sig_y_ > seqv_) {
      epeff_ -= depeff;
      depeff_ = 0.0;
    } else {
      ratio_ = sig_y_ / seqv_;
      for (int i = 0; i < 6; ++i)
        sd_[i] *= ratio_;
      seqv_ *= ratio_;
      depeff_ = depeff; // Use locally for updates if needed
    }
  }
}

void ConstitutionModel::M3DM6_HighExplosive(Real ltim, Real ctim, Real dvelo) {
  // Line-by-line translation from Fortran M3DM6 subroutine
  // Matches Fortran lines 1115-1119 exactly
  if (ctim > ltim) {
    bfac_ = 1.0;
  } else {
    bfac_ = 0.0;
  }
  // Note: Fortran M3DM6 does NOT zero sd_ - it's done after EOS call
}

void ConstitutionModel::M3DM7_Null(Real dt) {
  sd_.fill(0);
  Real tri = (dinc_[0] / dt + dinc_[1] / dt + dinc_[2] / dt) / 3.0;
  sd_[0] = miu2_ * (dinc_[0] / dt - tri);
  sd_[1] = miu2_ * (dinc_[1] / dt - tri);
  sd_[2] = miu2_ * (dinc_[2] / dt - tri);
  sd_[3] = 0.5 * miu2_ * dinc_[3] / dt;
  sd_[4] = 0.5 * miu2_ * dinc_[4] / dt;
  sd_[5] = 0.5 * miu2_ * dinc_[5] / dt;
}

void ConstitutionModel::M3DM8_JCWithFailure(const Material &mat, Real dt,
                                            Real temperature, bool &failure) {
  M3DM4_JohnsonCook(mat, dt, temperature);
}

void ConstitutionModel::M3DM9_DruckerPrager(const Material &mat, Real dt) {
  // Port of Fortran subroutine M3DM9 (Drucker-Prager, LS-DYNA Mat 193)
  // Reference: src/Constitution.f90: subroutine M3DM9

  const Real qfai = mat.getDP_q_fai();
  const Real kfai = mat.getDP_k_fai();
  const Real qpsi = mat.getDP_q_psi();

  // Shear and bulk moduli (Fortran Gmod, Kmod)
  const Real Gmod = young_ / (2.0 * (1.0 + poisson_));
  const Real Kmod = young_ / (3.0 * (1.0 - 2.0 * poisson_));

  // Fortran: ieinc = sig*dinc computed BEFORE trial elastic update
  Real ieinc0 = 0.0;
  for (int i = 0; i < 6; ++i) {
    ieinc0 += sig_[i] * dinc_[i];
  }

  // Tensile cutoff (Fortran tenf)
  Real tenf = 0.0;
  if (qfai == 0.0) {
    tenf = 0.0;
  } else {
    const Real tenf_max = kfai / qfai;
    tenf = std::min(mat.getDP_ten_f(), tenf_max);
  }

  // Trial elastic update
  elasticDeviatoricUpdate();
  elasticPressureUpdate();

  // J2 invariant and equivalent stress
  const Real J2 =
      0.5 * (sd_[0] * sd_[0] + sd_[1] * sd_[1] + sd_[2] * sd_[2]) +
      sd_[3] * sd_[3] + sd_[4] * sd_[4] + sd_[5] * sd_[5];
  const Real Tau = std::sqrt(std::max(0.0, J2));
  seqv_ = Tau * std::sqrt(3.0);

  const Real dpFi = Tau + qfai * sm_ - kfai; // D-P yield surface
  const Real dpsig = sm_ - tenf;             // spherical stress difference

  // Plastic flow
  if (dpsig < 0.0) {
    // Shear plastic flow only
    if (dpFi > 0.0 && Tau > EPSILON) {
      const Real dlamd = dpFi / (Gmod + Kmod * qfai * qpsi);
      sm_ = sm_ - Kmod * qpsi * dlamd;

      const Real newTau = kfai - qfai * sm_;
      ratio_ = newTau / Tau;
      for (int i = 0; i < 6; ++i) {
        sd_[i] *= ratio_;
      }
      seqv_ *= ratio_;

      depeff_ = dlamd * std::sqrt(1.0 / 3.0 + (2.0 / 9.0) * (qpsi * qpsi));
      epeff_ += depeff_;
    }
  } else {
    // Combined shear + tension cap
    const Real alphap = std::sqrt(1.0 + qfai * qfai) - qfai;
    const Real Taup = kfai - qfai * tenf;
    const Real dp_hfai = Tau - Taup - alphap * dpsig;

    if (dp_hfai > 0.0 && Tau > EPSILON) {
      // Shear plastic flow
      const Real dlamd = dpFi / (Gmod + Kmod * qfai * qpsi);
      sm_ = sm_ - Kmod * qpsi * dlamd;
      const Real newTau = kfai - qfai * sm_;
      ratio_ = newTau / Tau;
      for (int i = 0; i < 6; ++i) {
        sd_[i] *= ratio_;
      }
      seqv_ *= ratio_;
      depeff_ = dlamd * std::sqrt(1.0 / 3.0 + (2.0 / 9.0) * (qpsi * qpsi));
      epeff_ += depeff_;
    } else {
      // Tension plastic flow (Fortran iplas=2 branch):
      // - cap mean stress at tenf
      // - keep deviatoric stress from trial elastic update
      const Real dlamd = (sm_ - tenf) / Kmod;
      sm_ = tenf;
      depeff_ = dlamd * (1.0 / 3.0) * std::sqrt(2.0);
      epeff_ += depeff_;
    }
  }

  // Internal energy increment (Fortran adds corrected stress power to ieinc0)
  ieinc_ = ieinc0 + (sd_[0] + sm_) * dinc_[0] + (sd_[1] + sm_) * dinc_[1] +
           (sd_[2] + sm_) * dinc_[2] + sd_[3] * dinc_[3] + sd_[4] * dinc_[4] +
           sd_[5] * dinc_[5];
}

void ConstitutionModel::M3DM10_NeoHookean() {
  // NeoHookean material model for ULMPM
  // Simplified implementation - basic elastic response
  
  // Use elastic update functions (similar to M3DM1)
  elasticDeviatoricUpdate();
  elasticPressureUpdate();
  seqv_ = computeEquivalentStress(sd_);
  
  // Internal energy increment (elastic work)
  ieinc_ = 0.0;
  for (int i = 0; i < 6; ++i) {
    ieinc_ += sig_[i] * dinc_[i];
  }
}
void ConstitutionModel::M3DM11_NeoHookeanTL() {
  // NeoHookean material model for TLMPM (Total Lagrangian)
  // Simplified implementation - basic elastic response for TLMPM
  
  // Use elastic update functions (similar to M3DM1)
  elasticDeviatoricUpdate();
  elasticPressureUpdate();
  seqv_ = computeEquivalentStress(sd_);
  
  // Internal energy increment (elastic work)
  ieinc_ = 0.0;
  for (int i = 0; i < 6; ++i) {
    ieinc_ += sig_[i] * dinc_[i];
  }
}

void ConstitutionModel::selectEquationOfState(bool &failure) {
  // Select equation of state based on EOS type
  // This is called after material stress updates
  
  switch (etype_) {
    case EosType::LINEAR_POLYNOMIAL:
      // Linear polynomial EOS - would need material reference
      break;
    case EosType::GRUNEISEN:
      // Gruneisen EOS - would need material reference
      break;
    case EosType::JWL:
      // JWL EOS - would need material reference
      break;
    case EosType::TAIT:
      // Tait EOS - would need material reference
      break;
    case EosType::USER_EOS:
      // User-defined EOS - would need custom implementation
      break;
    case EosType::NONE:
    default:
      // No EOS - use pressure from material model directly
      break;
  }
}

void ConstitutionModel::linearPolynomialEOS(const Material &mat) {
  Real c0 = mat.getEosConstants()[0], c1 = mat.getEosConstants()[1],
       c2 = mat.getEosConstants()[2], c3 = mat.getEosConstants()[3],
       c4 = mat.getEosConstants()[4], c5 = mat.getEosConstants()[5],
       c6 = mat.getEosConstants()[6];
  Real A = c0 + mu_ * (c1 + mu_ * (c2 + mu_ * c3));
  Real B = c4 + mu_ * (c5 + mu_ * c6);
  bool fail = false;
  updateEnergyHie(fail);
  Real pnew = (A + B * specen_) / (1.0 + B * dvol_ / vol0_);
  if (fail && pnew < 0.0)
    pnew = 0.0;
  iener_ -= dvol_ * pnew;
  sm_ = -pnew;
}

void ConstitutionModel::gruneisenEOS(const Material &mat) {
  Real c1 = mat.getEosConstants()[0], c2 = mat.getEosConstants()[1],
       c3 = mat.getEosConstants()[2], c4 = mat.getEosConstants()[3],
       c5 = mat.getEosConstants()[4];
  Real A, B;
  if (mu_ > 0) {
    A = (c1 * mu_ + c2 * mu_ * mu_ + c3 * mu_ * mu_ * mu_) *
        (1.0 - c4 * mu_ * 0.5 / den_);
    B = c5;
  } else {
    A = c1 * mu_;
    B = 0.0;
  }
  if (sm_ < 0)
    computeBulkViscosity();
  bool fail = false;
  updateEnergyHie(fail);
  Real pnew = (A + B * specen_) / (1.0 + B * dvol_ / vol0_);
  if (fail && pnew < 0.0)
    pnew = 0.0;
  iener_ -= dvol_ * pnew;
  sm_ = -pnew;
}

void ConstitutionModel::JWLEOS(const Material &mat) {
  // Line-by-line translation from Fortran eos3 subroutine
  // Initialize parameters exactly as Fortran
  Real c1 = mat.getEosConstants()[0];  // A
  Real c2 = mat.getEosConstants()[1];  // B
  Real r1 = mat.getEosConstants()[2];  // R1
  Real r2 = mat.getEosConstants()[3];  // R2
  Real w1 = mat.getEosConstants()[4];  // w
  
  // Calculate intermediate values exactly as Fortran
  Real r1v = r1 * rv_;
  Real r2v = r2 * rv_;
  Real wr1v = c1 * w1 / r1v;
  Real wr2v = c2 * w1 / r2v;
  Real wdr1v = c1 - wr1v;
  Real wdr2v = c2 - wr2v;
  Real er1v = std::exp(-r1v);
  Real er2v = std::exp(-r2v);
  
  // Calculate A and B (before multiplying by bfac)
  // Note: bqf_ should be 0.0 for high explosives (no bulk viscosity)
  Real A = wdr1v * er1v + wdr2v * er2v + bqf_;
  Real B = w1 / rv_;
  
  // Call hieupd BEFORE multiplying by bfac (matches Fortran line 1499)
  bool failure = false; // High explosives don't use failure flag
  updateEnergyHie(failure);
  
  // Multiply A and B by burn fraction AFTER energy update (matches Fortran lines 1501-1502)
  A = A * bfac_;
  B = B * bfac_;
  
  // Calculate pressure (matches Fortran line 1504 exactly)
  // Match Fortran operation order: 1 + B * dvol / vol0_
  Real denom = 1.0 + (B * dvol_) / vol0_;
  Real pnew = (A + B * specen_) / denom;
  
  // Check for negative pressure with failure (matches Fortran line 1506)
  if (failure && pnew < 0.0)
    pnew = 0.0;
  
  // Update internal energy (matches Fortran line 1507 exactly)
  iener_ = iener_ - dvol_ * pnew;
  
  // Set mean stress (matches Fortran line 1509)
  sm_ = -pnew;
}

void ConstitutionModel::taitEOS(const Material &mat) {
  Real c0 = mat.getEosConstants()[0];
  if (sm_ < 0)
    computeBulkViscosity();
  bool fail = false;
  updateEnergyHie(fail);
  Real pnew = c0 * (std::pow(rv_, -7.0) - 1.0);
  if (pnew < 0)
    pnew = 0.0;
  iener_ -= dvol_ * pnew;
  sm_ = -pnew;
}

void ConstitutionModel::TLConstitution(
    const Vec6 &strain_increment, const Vec3 &vorticity,
    const Mat3 &vel_gradient, int body_id, int particle_id,
    const BodyList &body_list, ParticleList &particle_list,
    const MaterialList &material_list, Real dt, Real cell_size) {
  dt_ = dt;
  cell_size_ = cell_size;
  dinc_ = strain_increment;
  deF_ = vel_gradient;
  Particle &pt = particle_list[particle_id];
  ppk_old_ = pt.getPKStress();
  ppk_new_.fill(0);
  vold_ = pt.getVolume();
  Fp_ = pt.getDeformationGradient();
  for (int i = 0; i < 3; ++i)
    Fp_[i][i] = Fp_[i][i] + 1.0;
  Real detF = det(Fp_);
  vol_ = detF * pt.getVolumeInitial();
  pt.setVolume(vol_);
  dvol_ = 0.5 * (vol_ - vold_);
  mid_ = body_list[body_id].getMaterialID();
  const Material &mat = material_list.getMaterial(mid_);
  mtype_ = mat.getMaterialType();
  etype_ = mat.getEosType();
  young_ = mat.getYoungsModulus();
  poisson_ = mat.getPoissonsRatio();
  den0_ = mat.getDensity();
  Real mp = pt.getMass();
  vol0_ = mp / den0_;
  den_ = mp / vol_;
  mu_ = den_ / den0_ - 1.0;
  rv_ = vol_ / vol0_;
  cp_ = pt.getSoundSpeed();
  sm_ = pt.getMeanStress();
  smold_ = pt.getMeanStress();
  iener_ = pt.getInternalEnergy();
  sd_[0] = pt.getSDxx();
  sd_[1] = pt.getSDyy();
  sd_[2] = pt.getSDzz();
  sd_[3] = pt.getSDyz();
  sd_[4] = pt.getSDxz();
  sd_[5] = pt.getSDxy();
  switch (mtype_) {
  case MaterialType::USER_MAT1:
    M3DM11_NeoHookeanTL();
    break;
  default:
    break;
  }
  pt.setPKStress(ppk_new_);
  pt.setMeanStress(sm_);
  pt.setDeviatoricStress(sd_[0], sd_[1], sd_[2], sd_[5], sd_[3], sd_[4]);
  pt.setInternalEnergy(iener_);
}

} // namespace mpm3d
