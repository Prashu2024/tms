// FFI.cpp - File Format Interface
// Translated from FFI.f90

#include "FFI.hpp"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

namespace mpm3d {

FFI::FFI() {
}

std::string FFI::trim(const std::string& str) {
    size_t first = str.find_first_not_of(' ');
    if (std::string::npos == first) {
        return str;
    }
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

std::string FFI::toLower(const std::string& str) {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), ::tolower);
    return result;
}

std::vector<std::string> FFI::split(const std::string& str, char delimiter) {
    std::vector<std::string> tokens;
    std::istringstream iss(str);
    std::string token;
    
    while (std::getline(iss, token, delimiter)) {
        std::string trimmed = trim(token);
        if (!trimmed.empty()) {
            tokens.push_back(trimmed);
        }
    }
    
    return tokens;
}

bool FFI::isComment(const std::string& line) {
    if (line.empty()) return true;
    char first = line[0];
    return (first == '#' || first == '!' || first == '*');
}

bool FFI::isKeyword(const std::string& line, const std::string& keyword) {
    std::string lower_line = toLower(trim(line));
    std::string lower_keyword = toLower(keyword);
    
    return (lower_line.find(lower_keyword) == 0);
}

int FFI::parseInteger(const std::string& str) {
    std::istringstream iss(str);
    int value;
    iss >> value;
    return value;
}

Real FFI::parseReal(const std::string& str) {
    std::istringstream iss(str);
    Real value;
    iss >> value;
    return value;
}

bool FFI::parseBool(const std::string& str) {
    std::string lower = toLower(trim(str));
    return (lower == "true" || lower == "on" || lower == "yes" || lower == "1");
}

} // namespace mpm3d
