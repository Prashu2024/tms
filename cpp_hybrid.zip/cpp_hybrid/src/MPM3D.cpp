#include "MPMSolver.hpp"
#include "DataIn.hpp"
#include <iostream>
#include <exception>
#include <chrono>

using namespace mpm3d;

int main(int argc, char** argv) {
    try {
        std::cout << "========================================\n";
        std::cout << "MPM3D - Modern C++ Implementation\n";
        std::cout << "3D Material Point Method Solver\n";
        std::cout << "========================================\n\n";
        
        // Get input filename
        std::string input_file = "input.mpm";
        if (argc > 1) {
            input_file = argv[1];
        }
        
        std::cout << "Reading input from: " << input_file << "\n";
        
        // Parse input and create solver
        // Note: For this demo, we'll create a simple test case programmatically
        // In production, use: auto solver = DataIn::parseInputFile(input_file);
        
        // Create a simple test case
        Vec3 origin = {0.0, 0.0, 0.0};
        Vec3 extent = {1.0, 1.0, 1.0};
        std::array<int, 3> divisions = {20, 20, 20};
        
        auto grid = std::make_unique<Grid>(origin, extent, divisions);
        
        // Set boundary conditions (fixed bottom)
        grid->setFixedBoundary(2, 0); // z-axis, bottom
        
        SolverConfig config;
        config.dt = 1.0e-4;
        config.total_time = 0.1; // 0.1 seconds
        config.output_interval = 50;
        config.gravity = {0.0, 0.0, -9.81};
        config.damping = 0.0;
        config.use_FLIP = true;
        config.FLIP_ratio = 0.95;
        config.output_dir = "./output";
        
        auto solver = std::make_unique<MPMSolver>(std::move(grid), config);
        
        // Add material
        auto material = std::make_unique<LinearElasticMaterial>(1.0e6, 0.3);
        material->setID(0);
        material->setName("Elastic");
        material->setDensity(1000.0);
        solver->addMaterial(std::move(material));
        
        // Create particles (cube falling under gravity)
        int nx = 8, ny = 8, nz = 8;
        Real spacing = 0.04;
        Real particle_volume = spacing * spacing * spacing;
        Real particle_mass = 1000.0 * particle_volume; // density * volume
        
        std::cout << "Creating " << (nx * ny * nz) << " particles...\n";
        
        for (int k = 0; k < nz; ++k) {
            for (int j = 0; j < ny; ++j) {
                for (int i = 0; i < nx; ++i) {
                    auto p = std::make_unique<Particle>();
                    
                    Vec3 pos = {
                        0.3 + i * spacing,
                        0.3 + j * spacing,
                        0.6 + k * spacing
                    };
                    
                    p->setPosition(pos);
                    p->setVelocity({0.0, 0.0, 0.0});
                    p->setMass(particle_mass);
                    p->setVolume(particle_volume);
                    p->setMaterialID(0);
                    p->setDeformationGradient(identity_mat3());
                    p->setStateVariableSize(1);
                    
                    solver->addParticle(std::move(p));
                }
            }
        }
        
        std::cout << "\nStarting simulation...\n";
        std::cout << "Grid: " << divisions[0] << " x " << divisions[1] << " x " << divisions[2] << "\n";
        std::cout << "Particles: " << solver->getNumParticles() << "\n";
        std::cout << "Time step: " << config.dt << " s\n";
        std::cout << "Total time: " << config.total_time << " s\n\n";
        
        // Start timer
        auto start_time = std::chrono::high_resolution_clock::now();
        
        // Run simulation
        solver->solve();
        
        // End timer
        auto end_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::seconds>(end_time - start_time);
        
        std::cout << "\n========================================\n";
        std::cout << "Simulation completed successfully!\n";
        std::cout << "Total time: " << duration.count() << " seconds\n";
        std::cout << "Results saved to: " << config.output_dir << "\n";
        std::cout << "========================================\n";
        
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
}
