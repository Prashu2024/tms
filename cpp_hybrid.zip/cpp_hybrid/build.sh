#!/bin/bash

# MPM3D-CPP Build Script

set -e

# Ensure we run relative to this script's directory so CMake uses cpp/CMakeLists.txt
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "========================================="
echo "Building MPM3D-CPP"
echo "========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check for CMake
if ! command -v cmake &> /dev/null; then
    echo -e "${RED}Error: CMake not found. Please install CMake 3.15 or higher.${NC}"
    exit 1
fi

# Clean previous build
if [ -d "build" ]; then
    echo -e "${YELLOW}Cleaning previous build...${NC}"
    rm -rf build
fi

# Configure
echo -e "${GREEN}Configuring...${NC}"
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release

# Build
echo -e "${GREEN}Building...${NC}"

# macOS doesn't provide nproc by default
if command -v nproc &> /dev/null; then
    JOBS=$(nproc)
else
    JOBS=$(sysctl -n hw.ncpu)
fi

# Use cmake --build so the generator can be Ninja/Xcode/Unix Makefiles
cmake --build build --config Release -j${JOBS}

# Check if build was successful
if [ -f "build/mpm3d" ]; then
    echo -e "${GREEN}=========================================${NC}"
    echo -e "${GREEN}Build successful!${NC}"
    echo -e "${GREEN}Executable: build/mpm3d${NC}"
    echo -e "${GREEN}=========================================${NC}"
    
    # Create output directory
    mkdir -p ../output
    
    echo ""
    echo "To run the simulation:"
    echo "  cd build"
    echo "  ./mpm3d"
    echo ""
else
    echo -e "${RED}Build failed!${NC}"
    exit 1
fi
