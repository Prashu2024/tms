#ifndef MPM3D_DOMAINDECOMP_HPP
#define MPM3D_DOMAINDECOMP_HPP

#include <array>
#include <string>

namespace mpm3d {

struct Subdomain3D {
    int ix0 = 0; // inclusive
    int ix1 = 0; // exclusive
    int iy0 = 0;
    int iy1 = 0;
    int iz0 = 0;
    int iz1 = 0;
};

struct DecompInfo {
    std::array<int, 3> dims = {1, 1, 1};
    std::array<int, 3> coords = {0, 0, 0};
    Subdomain3D cells;
};

class DomainDecomp {
public:
    // Compute 3D block decomposition for cell counts (nx, ny, nz)
    // If an environment variable MPM3D_DIMS is provided (e.g., "2x2x1"),
    // it will be used to set the decomposition dims.
    static DecompInfo compute(int world_rank, int world_size,
                              int nx, int ny, int nz);

    // Map a global cell index (ix,iy,iz) to the owning MPI rank.
    static int ownerRankForCell(int ix, int iy, int iz,
                                const std::array<int, 3>& dims,
                                int nx, int ny, int nz);

    // Helper to convert to a short printable string.
    static std::string toString(const DecompInfo& info);

private:
    static bool parseDimsEnv(std::array<int, 3>& dims);
    static void splitAxis(int n, int p, int coord, int& begin, int& end);
    static int ownerCoord(int n, int p, int idx);
};

} // namespace mpm3d

#endif // MPM3D_DOMAINDECOMP_HPP
