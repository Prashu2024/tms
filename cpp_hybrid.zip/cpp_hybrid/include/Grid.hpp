#ifndef MPM3D_GRID_HPP
#define MPM3D_GRID_HPP

#include "Types.hpp"
#include "DomainDecomp.hpp"
#include <vector>
#include <array>

namespace mpm3d {

/**
 * @brief GridNode - geometric properties of a grid node
 */
class GridNode {
public:
    GridNode() : Xg_({0, 0, 0}), 
                 Fix_x_(false), Fix_y_(false), Fix_z_(false),
                 bd_type_({0, 0, 0}) {}
    
    // Position
    Vec3 getPosition() const { return Xg_; }
    void setPosition(const Vec3& pos) { Xg_ = pos; }
    
    // Boundary conditions
    bool isFixedX() const { return Fix_x_; }
    bool isFixedY() const { return Fix_y_; }
    bool isFixedZ() const { return Fix_z_; }
    
    void setFixedX(bool fix) { Fix_x_ = fix; }
    void setFixedY(bool fix) { Fix_y_ = fix; }
    void setFixedZ(bool fix) { Fix_z_ = fix; }
    
    void setFixX(bool fix) { Fix_x_ = fix; }
    void setFixY(bool fix) { Fix_y_ = fix; }
    void setFixZ(bool fix) { Fix_z_ = fix; }
    
    // Boundary type: 0-not boundary, 1-left boundary, 2-right boundary
    const std::array<int, 3>& getBoundaryType() const { return bd_type_; }
    void setBoundaryType(int dir, int type) { bd_type_[dir] = type; }
    
private:
    Vec3 Xg_;                    // Grid node coordinate
    bool Fix_x_, Fix_y_, Fix_z_; // Boundary conditions
    std::array<int, 3> bd_type_; // Boundary type for each direction
};

/**
 * @brief GridNodeProperty - physical properties mapped to grid node
 */
class GridNodeProperty {
public:
    GridNodeProperty() {
        reset();
    }
    
    void reset() {
        Mg_ = 0.0L;
        PXg_ = {0.0L, 0.0L, 0.0L};
        FXg_ = {0.0L, 0.0L, 0.0L};
        Gpre_ = 0.0;
        GV_all_ = 0.0;
        mapped_ = false;
    }
    
    // Mass
    Real getMass() const { return static_cast<Real>(Mg_); }
    void addMass(Real m) {
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Mg_ += static_cast<long double>(m);
        mapped_ = true;
    }
    void setMass(Real m) { Mg_ = static_cast<long double>(m); }
    
    // Momentum
    Vec3 getMomentum() const {
        return {static_cast<Real>(PXg_[0]), static_cast<Real>(PXg_[1]),
                static_cast<Real>(PXg_[2])};
    }
    void addMomentum(const Vec3& p) {
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        PXg_[0] += static_cast<long double>(p[0]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        PXg_[1] += static_cast<long double>(p[1]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        PXg_[2] += static_cast<long double>(p[2]);
    }
    void setMomentum(const Vec3& p) {
        PXg_[0] = static_cast<long double>(p[0]);
        PXg_[1] = static_cast<long double>(p[1]);
        PXg_[2] = static_cast<long double>(p[2]);
    }
    
    // Force
    Vec3 getForce() const {
        return {static_cast<Real>(FXg_[0]), static_cast<Real>(FXg_[1]),
                static_cast<Real>(FXg_[2])};
    }
    void addForce(const Vec3& f) {
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        FXg_[0] += static_cast<long double>(f[0]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        FXg_[1] += static_cast<long double>(f[1]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        FXg_[2] += static_cast<long double>(f[2]);
    }
    void setForce(const Vec3& f) {
        FXg_[0] = static_cast<long double>(f[0]);
        FXg_[1] = static_cast<long double>(f[1]);
        FXg_[2] = static_cast<long double>(f[2]);
    }
    
    // Velocity (computed from momentum)
    Vec3 getVelocity() const {
        if (Mg_ > static_cast<long double>(EPSILON)) {
            const long double inv_m = 1.0L / Mg_;
            return {static_cast<Real>(PXg_[0] * inv_m),
                    static_cast<Real>(PXg_[1] * inv_m),
                    static_cast<Real>(PXg_[2] * inv_m)};
        }
        return {0, 0, 0};
    }
    
    void setVelocity(const Vec3& v) {
        if (Mg_ > static_cast<long double>(EPSILON)) {
            PXg_[0] = Mg_ * static_cast<long double>(v[0]);
            PXg_[1] = Mg_ * static_cast<long double>(v[1]);
            PXg_[2] = Mg_ * static_cast<long double>(v[2]);
        }
    }
    
    // Pressure (for smoothing)
    Real getPressure() const { return Gpre_; }
    void setPressure(Real p) { Gpre_ = p; }
    
    // Volume (mapped from particles)
    Real getVolume() const { return GV_all_; }
    void setVolume(Real v) { GV_all_ = v; }
    
    // Mapping flag
    bool isMapped() const { return mapped_; }
    bool isActive() const { return Mg_ > static_cast<long double>(EPSILON); }
    
private:
    long double Mg_;                       // Mass on grid node
    std::array<long double, 3> PXg_;       // Momentum on grid node
    std::array<long double, 3> FXg_;       // Internal/external force on grid node
    Real Gpre_;      // Pressure on grid node
    Real GV_all_;    // Volume on grid node mapped by particles
    bool mapped_;    // Is there a mapping to this node?
};

/**
 * @brief CellData - geometric properties of cell center (for SGMP)
 */
class CellData {
public:
    CellData() : Cxg_({0, 0, 0}) {}
    
    Vec3 getCenterPosition() const { return Cxg_; }
    void setCenterPosition(const Vec3& pos) { Cxg_ = pos; }
    
private:
    Vec3 Cxg_;  // Cell center coordinate
};

/**
 * @brief CellDataProperty - auxiliary grid properties (for SGMP)
 */
class CellDataProperty {
public:
    CellDataProperty() {
        reset();
    }
    
    void reset() {
        Cmg_ = 0.0L;
        Cpxg_ = {0.0L, 0.0L, 0.0L};
        Cfxg_ = {0.0L, 0.0L, 0.0L};
        Cfint_ = {0, 0, 0, 0, 0, 0};
        Cfext_ = {0.0L, 0.0L, 0.0L};
        Cvx_ = {0, 0, 0};
        Cax_ = {0, 0, 0};
        Co_ = {0, 0, 0, 0, 0, 0};
        Cw_ = {0, 0, 0};
        CdeFp_ = zero_mat3();
        CPKint_ = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        CGpre_ = 0.0;
        CGV_all_ = 0.0;
        Cmapped_ = false;
    }
    
    // Mass
    Real getMass() const { return static_cast<Real>(Cmg_); }
    void addMass(Real m) {
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cmg_ += static_cast<long double>(m);
        Cmapped_ = true;
    }
    void setMass(Real m) { Cmg_ = static_cast<long double>(m); }
    
    // Momentum
    Vec3 getMomentum() const {
        return {static_cast<Real>(Cpxg_[0]), static_cast<Real>(Cpxg_[1]),
                static_cast<Real>(Cpxg_[2])};
    }
    void addMomentum(const Vec3& p) {
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cpxg_[0] += static_cast<long double>(p[0]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cpxg_[1] += static_cast<long double>(p[1]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cpxg_[2] += static_cast<long double>(p[2]);
    }
    void setMomentum(const Vec3& p) {
        Cpxg_[0] = static_cast<long double>(p[0]);
        Cpxg_[1] = static_cast<long double>(p[1]);
        Cpxg_[2] = static_cast<long double>(p[2]);
    }
    
    // Total force
    Vec3 getTotalForce() const {
        return {static_cast<Real>(Cfxg_[0]), static_cast<Real>(Cfxg_[1]),
                static_cast<Real>(Cfxg_[2])};
    }
    void setTotalForce(const Vec3& f) {
        Cfxg_[0] = static_cast<long double>(f[0]);
        Cfxg_[1] = static_cast<long double>(f[1]);
        Cfxg_[2] = static_cast<long double>(f[2]);
    }
    void addTotalForce(const Vec3& f) {
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfxg_[0] += static_cast<long double>(f[0]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfxg_[1] += static_cast<long double>(f[1]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfxg_[2] += static_cast<long double>(f[2]);
    }
    
    // Internal force (Voigt notation)
    const Vec6& getInternalForce() const { return Cfint_; }
    void setInternalForce(const Vec6& f) { Cfint_ = f; }
    void addInternalForce(const Vec6& f) {
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfint_[0] += f[0];
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfint_[1] += f[1];
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfint_[2] += f[2];
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfint_[3] += f[3];
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfint_[4] += f[4];
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfint_[5] += f[5];
    }
    
    // External force
    Vec3 getExternalForce() const {
        return {static_cast<Real>(Cfext_[0]), static_cast<Real>(Cfext_[1]),
                static_cast<Real>(Cfext_[2])};
    }
    void setExternalForce(const Vec3& f) {
        Cfext_[0] = static_cast<long double>(f[0]);
        Cfext_[1] = static_cast<long double>(f[1]);
        Cfext_[2] = static_cast<long double>(f[2]);
    }
    void addExternalForce(const Vec3& f) {
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfext_[0] += static_cast<long double>(f[0]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfext_[1] += static_cast<long double>(f[1]);
#if defined(MPM3D_USE_OPENMP)
        #pragma omp atomic
#endif
        Cfext_[2] += static_cast<long double>(f[2]);
    }
    
    // Velocity at t+1/2
    Vec3 getVelocity() const { return Cvx_; }
    void setVelocity(const Vec3& v) { Cvx_ = v; }
    
    // Acceleration at t+1/2
    Vec3 getAcceleration() const { return Cax_; }
    void setAcceleration(const Vec3& a) { Cax_ = a; }
    
    // Strain increment
    const Vec6& getStrainIncrement() const { return Co_; }
    void setStrainIncrement(const Vec6& e) { Co_ = e; }
    
    // Vorticity
    Vec3 getVorticity() const { return Cw_; }
    void setVorticity(const Vec3& w) { Cw_ = w; }
    
    // Deformation gradient increment
    const Mat3& getDefGradIncrement() const { return CdeFp_; }
    void setDefGradIncrement(const Mat3& f) { CdeFp_ = f; }
    
    // PK stress
    const Vec9& getPKStress() const { return CPKint_; }
    void setPKStress(const Vec9& pk) { CPKint_ = pk; }
    
    // Pressure
    Real getPressure() const { return CGpre_; }
    void setPressure(Real p) { CGpre_ = p; }
    
    // Volume
    Real getVolume() const { return CGV_all_; }
    void setVolume(Real v) { CGV_all_ = v; }
    
    // Mapping flag
    bool isMapped() const { return Cmapped_; }
    bool isActive() const { return Cmg_ > static_cast<long double>(EPSILON); }
    
private:
    long double Cmg_;                       // Mass on auxiliary grid node
    std::array<long double, 3> Cpxg_;       // Momentum on auxiliary grid node
    std::array<long double, 3> Cfxg_;       // Total grid force
    Vec6 Cfint_;      // Internal force (Voigt)
    std::array<long double, 3> Cfext_;      // External force
    Vec3 Cvx_;        // Velocity at t+1/2
    Vec3 Cax_;        // Acceleration at t+1/2
    Vec6 Co_;         // Strain increment
    Vec3 Cw_;         // Vorticity
    Mat3 CdeFp_;      // Deformation gradient increment
    Vec9 CPKint_;     // PK stress for TLMPM
    Real CGpre_;      // Pressure on auxiliary node
    Real CGV_all_;    // Volume on auxiliary node
    bool Cmapped_;    // Mapping flag
};

/**
 * @brief ContactGridNodeProperty - contact-specific properties
 */
class ContactGridNodeProperty {
public:
    ContactGridNodeProperty() : ndir_({0, 0, 0}), sdir_({0, 0, 0}) {}
    
    // Normal direction of contact grid node
    Vec3 getNormalDirection() const { return ndir_; }
    void setNormalDirection(const Vec3& n) { ndir_ = n; }
    
    // Tangential unit vector of contact grid node
    Vec3 getTangentDirection() const { return sdir_; }
    void setTangentDirection(const Vec3& s) { sdir_ = s; }
    
private:
    Vec3 ndir_;  // Normal direction
    Vec3 sdir_;  // Tangential unit vector
};

/**
 * @brief Grid - main grid class
 */
class Grid {
public:
    Grid();
    ~Grid() = default;
    
    // Initialize grid with parameters
    void initialize(const Vec3& span_x, const Vec3& span_y, const Vec3& span_z,
                   Real cell_size, int num_components);
    
    // Grid geometry
    Vec3 getSpanX() const { return {SpanX_[0], SpanX_[1]}; }
    Vec3 getSpanY() const { return {SpanY_[0], SpanY_[1]}; }
    Vec3 getSpanZ() const { return {SpanZ_[0], SpanZ_[1]}; }
    Real getCellSize() const { return DCell_; }
    
    // Grid dimensions
    int getNumCellsX() const { return NumCellx_; }
    int getNumCellsY() const { return NumCelly_; }
    int getNumCellsZ() const { return NumCellz_; }
    int getNumCells() const { return NumCell_; }
    int getNumNodes() const { return nb_gridnode_; }
    int getNumComponents() const { return nb_component_; }

    // Domain decomposition
    void setDecomposition(const DecompInfo& info, int world_rank, int world_size,
                          int ghost_layers = 1);
    bool isDecompositionActive() const { return decomp_active_; }
    int getDecompRank() const { return decomp_rank_; }
    int getDecompSize() const { return decomp_size_; }
    int getDecompGhost() const { return decomp_ghost_; }
    const Subdomain3D& getCellDomainOwned() const { return decomp_cells_owned_; }
    const Subdomain3D& getCellDomainLocal() const { return decomp_cells_local_; }

    bool isCellOwned(int cell_id) const;
    bool isNodeOwned(int node_id) const;
    bool isNodeLocal(int node_id) const;
    int ownerRankForCell(int cell_id) const;
    
    // Auxiliary grid (for SGMP)
    int getNumCenterCells() const { return nb_centernode_; }
    bool hasSGMP() const { return use_SGMP_; }
    void enableSGMP(bool enable) { use_SGMP_ = enable; }
    
    // Node access
    GridNode& getNode(int index) { return node_list_[index]; }
    const GridNode& getNode(int index) const { return node_list_[index]; }
    
    GridNodeProperty& getNodeProperty(int component, int node) {
        // Component is 1-based in calling code, convert to 0-based
        return grid_list_[(component - 1) * nb_gridnode_ + node];
    }
    const GridNodeProperty& getNodeProperty(int component, int node) const {
        // Component is 1-based in calling code, convert to 0-based
        return grid_list_[(component - 1) * nb_gridnode_ + node];
    }
    
    // Cell access (auxiliary grid)
    CellData& getCellData(int index) { return cell_list_[index]; }
    const CellData& getCellData(int index) const { return cell_list_[index]; }
    
    CellDataProperty& getCellProperty(int index) { return cellp_list_[index]; }
    const CellDataProperty& getCellProperty(int index) const { return cellp_list_[index]; }
    
    // Contact properties
    ContactGridNodeProperty& getContactProperty(int component, int node) {
        // Component is 1-based in calling code, convert to 0-based
        return CP_list_[(component - 1) * nb_gridnode_ + node];
    }
    
    // Cell connectivity
    const std::array<int, 8>& getCellNodes(int cell) const {
        return CellsNode_[cell];
    }
    
    const std::array<int, 8>& getCenterCellNodes(int cell) const {
        return CenterCellNode_[cell];
    }
    
    // Find which cell a point is in
    int findCell(const Vec3& position) const;
    int findCenterCell(const Vec3& position) const;
    
    // Calculate natural coordinates
    Vec3 calculateNaturalCoords(const Vec3& position, int cell) const;
    
    // Reset all grid properties
    void resetGridProperties();
    void resetAuxiliaryGrid();
    
    // Boundary conditions
    void setFixedBoundary(const std::array<int, 6>& fixed);
    const std::array<int, 6>& getFixedBoundary() const { return FixS_; }
    void setExtendedBoundaryLayers(bool enable) { extended_bc_layers_ = enable; }
    Real getCutOff() const { return CutOff_; }
    void setCutOff(Real cutoff) { CutOff_ = cutoff; }
    
    // Contact
    Real getFriction() const { return fricfa_; }
    void setFriction(Real f) { fricfa_ = f; }
    
    int getNormalBody() const { return normbody_; }
    void setNormalBody(int body) { normbody_ = body; }
    
    Vec3 getTotalContactForce() const { return tot_cont_for_; }
    void setTotalContactForce(const Vec3& f) { tot_cont_for_ = f; }

    // MPI: reduce nodal fields across ranks (global sum).
    void allreduceNodeFields(bool reduce_mass_mom,
                             bool reduce_force,
                             bool reduce_pressure_volume);
    void allreduceNodeMomentum();
    void exchangeNodeFields(bool reduce_mass_mom,
                            bool reduce_force,
                            bool reduce_pressure_volume);
    void exchangeNodeMomentum();
    
private:
    // Grid geometry
    std::array<Real, 2> SpanX_, SpanY_, SpanZ_;  // Computational region
    Real DCell_;                                   // Grid spacing
    Real CutOff_;                                  // Grid mass cutoff
    
    // Grid dimensions
    int NumCellx_, NumCelly_, NumCellz_;          // Number of cells
    int NumCellxy_, NumCell_;                      // Total cells
    int NGx_, NGy_, NGz_, NGxy_;                  // Number of nodes
    int nb_gridnode_;                              // Total nodes
    int nb_component_;                             // Number of components
    
    // Auxiliary grid (SGMP)
    bool use_SGMP_;
    int CenterNumCellx_, CenterNumCelly_, CenterNumCellz_;
    int CenterNumCellxy_, CenterNumCell_;
    int nb_centernode_;
    
    // Node and cell data
    std::vector<GridNode> node_list_;
    std::vector<GridNodeProperty> grid_list_;      // [component][node]
    std::vector<CellData> cell_list_;
    std::vector<CellDataProperty> cellp_list_;
    std::vector<ContactGridNodeProperty> CP_list_; // [component][node]
    
    // Cell connectivity
    std::vector<std::array<int, 8>> CellsNode_;
    std::vector<std::array<int, 8>> CenterCellNode_;
    
    // Boundary conditions
    std::array<int, 6> FixS_;  // Fixed surfaces
    bool extended_bc_layers_ = false;
    
    // Contact parameters
    Real fricfa_;              // Friction coefficient
    int normbody_;             // Normal body flag
    Vec3 tot_cont_for_;        // Total contact force
    
    // Helper methods
    void createGridNodes();
    void createCellConnectivity();
    void createAuxiliaryGrid();

    void cellIdToIndices(int cell_id, int& ix, int& iy, int& iz) const;
    void nodeIdToIndices(int node_id, int& ix, int& iy, int& iz) const;

    // Decomposition state
    bool decomp_active_ = false;
    int decomp_rank_ = 0;
    int decomp_size_ = 1;
    int decomp_ghost_ = 0;
    DecompInfo decomp_info_{};
    Subdomain3D decomp_cells_owned_{};
    Subdomain3D decomp_cells_local_{};
    Subdomain3D decomp_nodes_owned_{};
    Subdomain3D decomp_nodes_local_{};
};

} // namespace mpm3d

#endif // MPM3D_GRID_HPP
