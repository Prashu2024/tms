#ifndef MPM3D_DATAIN_HPP
#define MPM3D_DATAIN_HPP

#include "Types.hpp"
#include "Particle.hpp"
#include "Body.hpp"
#include "Grid.hpp"
#include "Material.hpp"
#include <string>
#include <fstream>

namespace mpm3d {

/**
 * @brief Simulation parameters
 */
struct SimulationParameters {
    std::string title;
    Real end_time = 1.0;
    Real dt_scale = 0.8;
    Real output_interval = 0.01;
    Real report_interval = 0.1;
    Real damping_coefficient = 0.0;
    
    AlgorithmType algorithm = AlgorithmType::USL;
    ShapeFunctionType shape_function = ShapeFunctionType::LINEAR;
    ContactType contact_type = ContactType::NONE;
    
    Real friction_coefficient = 0.0;
    int contact_normbody = 0;
    bool update_volume_by_F = false;
    bool quasi_static = false;
    bool stress_smoothing = false;
    bool write_tecplot = false;
    bool write_paraview = false;
    Vec3 gravity = {0, 0, 0};
    
    // 2D plotting parameters
    bool plot2d_enabled = false;
    Real plot2d_x1 = 0.0;
    Real plot2d_x2 = 0.0;
    
    // Output variables
    std::vector<std::string> output_variables;
};

/**
 * @brief Input file parser
 * Reads MPM input files and initializes simulation
 */
class DataIn {
public:
    DataIn();
    
    // Read input file
    bool readInputFile(const std::string& filename,
                      ParticleList& particles,
                      BodyList& bodies,
                      Grid& grid,
                      MaterialList& materials,
                      SimulationParameters& params);
    
private:
    // Keyword processing
    std::string extractKeyword(const std::string& line);
    bool processKeyword(const std::string& keyword,
                       std::ifstream& file,
                       ParticleList& particles,
                       BodyList& bodies,
                       Grid& grid,
                       MaterialList& materials,
                       SimulationParameters& params);
    
    // Individual keyword readers
    bool readTitle(std::ifstream& file, SimulationParameters& params);
    bool readNumParticles(std::ifstream& file, ParticleList& particles);
    bool readEndTime(std::ifstream& file, SimulationParameters& params);
    bool readGrid(std::ifstream& file, Grid& grid);
    bool readSpanX(std::ifstream& file, Grid& grid);
    bool readSpanY(std::ifstream& file, Grid& grid);
    bool readSpanZ(std::ifstream& file, Grid& grid);
    bool readCellSize(std::ifstream& file, Grid& grid);
    bool readDTScale(std::ifstream& file, SimulationParameters& params);
    bool readOutputTime(std::ifstream& file, SimulationParameters& params);
    bool readReportTime(std::ifstream& file, SimulationParameters& params);
    bool readFixedBoundaries(std::ifstream& file, Grid& grid);
    bool readNumMaterials(std::ifstream& file, MaterialList& materials);
    bool readMaterial(std::ifstream& file, MaterialList& materials);
    bool readParticles(std::ifstream& file, ParticleList& particles, BodyList& bodies);
    bool readContact(std::ifstream& file, SimulationParameters& params);
    bool readBulkViscosity(std::ifstream& file, MaterialList& materials);
    bool readLoad(std::ifstream& file, ParticleList& particles);
    bool readVelocity(std::ifstream& file, ParticleList& particles);
    bool readEOS(std::ifstream& file, MaterialList& materials);
    bool readDetonation(std::ifstream& file, MaterialList& materials);
    
    // Helper functions
    int readInt(std::ifstream& file);
    Real readReal(std::ifstream& file);
    bool readBool(std::ifstream& file);
    
    // Counters
    int body_counter_;
    int component_counter_;
    int particle_counter_;
    int current_line_;
};

} // namespace mpm3d

#endif // MPM3D_DATAIN_HPP
