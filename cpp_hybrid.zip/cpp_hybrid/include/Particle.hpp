#ifndef MPM3D_PARTICLE_HPP
#define MPM3D_PARTICLE_HPP

#include "Types.hpp"
#include <vector>

namespace mpm3d {

/**
 * @brief Particle class - represents a material point
 * 
 * This class contains all particle properties including:
 * - Kinematic properties (position, velocity)
 * - Stress state (Cauchy, deviatoric, PK stress)
 * - Material state (volume, density, damage)
 * - History variables (plastic strain, temperature)
 */
class Particle {
public:
    // Constructor
    Particle();
    
    // ========== Position and Kinematics ==========
    
    // Position at time t+1
    Vec3 getPosition() const { return XX_; }
    void setPosition(const Vec3& pos) { XX_ = pos; }
    
    // Position at time t
    Vec3 getPositionPrev() const { return Xp_; }
    void setPositionPrev(const Vec3& pos) { Xp_ = pos; }
    
    // Initial position (t=0)
    Vec3 getPositionInitial() const { return Xo_; }
    void setPositionInitial(const Vec3& pos) { Xo_ = pos; }
    
    // Velocity
    Vec3 getVelocity() const { return VXp_; }
    void setVelocity(const Vec3& vel) { VXp_ = vel; }
    
    // External force
    Vec3 getExternalForce() const { return FXp_; }
    void setExternalForce(const Vec3& force) { FXp_ = force; }
    
    // ========== Grid Coordinates ==========
    
    // Natural coordinates in background grid
    Vec3 getNaturalCoords() const { return XN_; }
    void setNaturalCoords(const Vec3& coords) { XN_ = coords; }
    
    // Natural coordinates in auxiliary grid (for SGMP)
    Vec3 getNaturalCoordsAux() const { return XXN_; }
    void setNaturalCoordsAux(const Vec3& coords) { XXN_ = coords; }
    
    // Cell and node tracking
    int getCell() const { return icell_; }
    void setCell(int cell) { icell_ = cell; }
    
    int getCenterCell() const { return centericell_; }
    void setCenterCell(int cell) { centericell_ = cell; }
    
    int getNode() const { return inode_; }
    void setNode(int node) { inode_ = node; }

    // Domain decomposition owner
    int getOwnerRank() const { return owner_rank_; }
    void setOwnerRank(int rank) { owner_rank_ = rank; }

    // Body id (0-based index in BodyList)
    int getBodyId() const { return body_id_; }
    void setBodyId(int id) { body_id_ = id; }
    
    // ========== Material Properties ==========
    
    Real getMass() const { return mass_; }
    void setMass(Real mass) { mass_ = mass; }
    
    Real getVolume() const { return VOL_; }
    void setVolume(Real vol) { VOL_ = vol; }
    
    Real getVolumeInitial() const { return VOL0_; }
    void setVolumeInitial(Real vol) { VOL0_ = vol; }
    
    // ========== Stress State ==========
    
    // Mean stress
    Real getMeanStress() const { return SM_; }
    void setMeanStress(Real sm) { SM_ = sm; }
    
    // Von Mises equivalent stress
    Real getEquivalentStress() const { return Seqv_; }
    void setEquivalentStress(Real seqv) { Seqv_ = seqv; }
    
    // Deviatoric stress components
    Real getSDxx() const { return SDxx_; }
    Real getSDyy() const { return SDyy_; }
    Real getSDzz() const { return SDzz_; }
    Real getSDxy() const { return SDxy_; }
    Real getSDyz() const { return SDyz_; }
    Real getSDxz() const { return SDxz_; }
    
    void setDeviatoricStress(Real xx, Real yy, Real zz, 
                            Real xy, Real yz, Real xz) {
        SDxx_ = xx; SDyy_ = yy; SDzz_ = zz;
        SDxy_ = xy; SDyz_ = yz; SDxz_ = xz;
    }
    
    // Full stress tensor (Cauchy stress in Voigt notation)
    Vec6 getCauchyStress() const {
        return {SDxx_ + SM_ - q_, SDyy_ + SM_ - q_, SDzz_ + SM_ - q_, 
                SDyz_, SDxz_, SDxy_};
    }
    
    void setCauchyStress(const Vec6& stress) {
        SM_ = mean_stress(stress);
        Vec6 sd = deviatoric_stress(stress);
        SDxx_ = sd[0]; SDyy_ = sd[1]; SDzz_ = sd[2];
        SDyz_ = sd[3]; SDxz_ = sd[4]; SDxy_ = sd[5];
    }
    
    // First Piola-Kirchhoff stress (for TLMPM)
    const Vec9& getPKStress() const { return PK_; }
    void setPKStress(const Vec9& pk) { PK_ = pk; }
    
    // Smoothed pressure (for pressure smoothing)
    Real getSmoothedPressure() const { return Spre_; }
    void setSmoothedPressure(Real p) { Spre_ = p; }
    
    // ========== Deformation ==========
    
    // Deformation gradient tensor
    const Mat3& getDeformationGradient() const { return Fp_; }
    void setDeformationGradient(const Mat3& F) { Fp_ = F; }
    
    // ========== Plasticity and Damage ==========
    
    // Yield stress
    Real getYieldStress() const { return sig_y_; }
    void setYieldStress(Real sy) { sig_y_ = sy; }
    
    // Effective plastic strain
    Real getPlasticStrain() const { return epeff_; }
    void setPlasticStrain(Real ep) { epeff_ = ep; }
    
    // Damage variable (0 = no damage, 1 = fully damaged)
    Real getDamage() const { return DMG_; }
    void setDamage(Real dmg) { DMG_ = dmg; }
    
    // Failure flag
    bool hasFailed() const { return failure_; }
    void setFailure(bool failed) { failure_ = failed; }
    
    // ========== Thermal ==========
    
    // Temperature (Celsius)
    Real getTemperature() const { return celsius_t_; }
    void setTemperature(Real temp) { celsius_t_ = temp; }
    
    // Internal energy
    Real getInternalEnergy() const { return ie_; }
    void setInternalEnergy(Real ie) { ie_ = ie; }
    
    // ========== Wave Propagation ==========
    
    // Sound speed
    Real getSoundSpeed() const { return cp_; }
    void setSoundSpeed(Real cp) { cp_ = cp; }
    
    // Bulk viscosity
    Real getBulkViscosity() const { return q_; }
    void setBulkViscosity(Real q) { q_ = q; }
    
    // ========== Special Applications ==========
    
    // Lighting time (for explosives)
    Real getLightingTime() const { return LT_; }
    void setLightingTime(Real lt) { LT_ = lt; }
    
    // Skip flag (for plotting less particles)
    bool shouldSkip() const { return SkipThis_; }
    void setSkip(bool skip) { SkipThis_ = skip; }
    
    // ========== Update Methods ==========
    
    void updatePosition(Real dt) {
        Xp_ = XX_;  // Save previous position
        XX_ = XX_ + VXp_ * dt;
    }
    
    void updateVelocity(const Vec3& acc, Real dt) {
        VXp_ += acc * dt;
    }
    
    void updateDeformationGradient(const Mat3& velocity_gradient, Real dt);
    
    void updateVolume(const Mat3& strain_rate, Real dt) {
        Real vol_rate = trace(strain_rate);
        VOL_ *= (1.0 + vol_rate * dt);
    }
    
    void updateVolumeByF() {
        Real J = det(Fp_);
        VOL_ = VOL0_ * J;
    }
    
private:
    // ========== Position and Kinematics ==========
    Vec3 XX_;          // Position at time t+1
    Vec3 Xp_;          // Position at time t
    Vec3 Xo_;          // Initial position at t=0
    Vec3 VXp_;         // Velocity
    Vec3 FXp_;         // External load/force
    
    // ========== Grid Coordinates ==========
    Vec3 XN_;          // Natural coordinates in background grid
    Vec3 XXN_;         // Natural coordinates in auxiliary grid (SGMP)
    int icell_;        // Cell number in background grid
    int centericell_;  // Cell number in auxiliary grid
    int inode_;        // Closest node number
    int owner_rank_;   // Owning MPI rank
    int body_id_;      // Owning body index
    
    // ========== Material Properties ==========
    Real mass_;        // Particle mass
    Real VOL_;         // Current volume
    Real VOL0_;        // Initial volume
    
    // ========== Stress State ==========
    Real SM_;          // Mean stress
    Real Seqv_;        // Von Mises equivalent stress
    Real SDxx_, SDyy_, SDzz_;  // Deviatoric stress (normal components)
    Real SDxy_, SDyz_, SDxz_;  // Deviatoric stress (shear components)
    Real Spre_;        // Smoothed pressure
    Vec9 PK_;          // First Piola-Kirchhoff stress (for TLMPM)
    
    // ========== Deformation ==========
    Mat3 Fp_;          // Deformation gradient tensor
    
    // ========== Plasticity and Damage ==========
    Real sig_y_;       // Yield stress
    Real epeff_;       // Effective plastic strain
    Real DMG_;         // Damage variable
    bool failure_;     // Failure flag
    
    // ========== Thermal ==========
    Real celsius_t_;   // Temperature (Celsius)
    Real ie_;          // Internal energy
    
    // ========== Wave Propagation ==========
    Real cp_;          // Sound speed
    Real q_;           // Bulk viscosity
    
    // ========== Special ==========
    Real LT_;          // Lighting time (for explosives)
    bool SkipThis_;    // Skip flag for plotting
};

// Particle container
using ParticleList = std::vector<Particle>;

} // namespace mpm3d

#endif // MPM3D_PARTICLE_HPP
