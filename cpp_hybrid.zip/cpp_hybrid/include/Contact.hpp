#ifndef MPM3D_CONTACT_HPP
#define MPM3D_CONTACT_HPP

#include "Types.hpp"
#include "Particle.hpp"
#include "Body.hpp"
#include "Grid.hpp"
#include <map>

namespace mpm3d {

/**
 * @brief Contact node properties
 */
struct ContactNodeProperty {
    Vec3 normal;    // Contact normal direction
    Vec3 tangent;   // Contact tangent direction
};

/**
 * @brief Contact detection and resolution
 */
class Contact {
public:
    Contact();
    
    // Initialize contact settings
    void initialize(ContactType type, Real friction, Real penalty_k = 1.0e6);
    
    // Main contact detection and resolution
    void detectAndResolve(Grid& grid, const ParticleList& particles,
                         const BodyList& bodies, Real dt);
    
    // Setters
    void setType(ContactType type) { type_ = type; }
    void setFrictionCoefficient(Real friction) { friction_coefficient_ = friction; }
    void setPenaltyStiffness(Real k) { penalty_stiffness_ = k; }
    void setNormalBody(int body) { normal_body_ = body; }
    
    // Getters
    ContactType getType() const { return type_; }
    Real getFrictionCoefficient() const { return friction_coefficient_; }
    Vec3 getTotalContactForce() const { return total_contact_force_; }
    
    // Store contact node properties
    void setContactNodeProperty(int node_id, const Vec3& normal, const Vec3& tangent);
    
private:
    // Contact algorithms
    void lagrangianContact(Grid& grid, const ParticleList& particles,
                          const BodyList& bodies, Real dt);
    void penaltyContact(Grid& grid, const ParticleList& particles,
                       const BodyList& bodies, Real dt);
    
    // Helper functions
    Vec3 calculateContactNormal(int node_id, const Grid& grid,
                               const ParticleList& particles,
                               const BodyList& bodies);
    Real calculatePenetration(int node_id, const Grid& grid,
                             const ParticleList& particles,
                             const BodyList& bodies);
    void calculateTangents(const Vec3& normal, Vec3& tangent1, Vec3& tangent2);
    
    // Contact parameters
    ContactType type_;
    Real friction_coefficient_;
    Real penalty_stiffness_;
    int normal_body_;  // Body used for normal calculation
    
    // Contact node properties
    std::map<int, ContactNodeProperty> contact_properties_;
    
    // Contact tracking
    Vec3 total_contact_force_;
};

} // namespace mpm3d

#endif // MPM3D_CONTACT_HPP
