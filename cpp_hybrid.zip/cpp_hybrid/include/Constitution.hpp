#ifndef MPM3D_CONSTITUTION_HPP
#define MPM3D_CONSTITUTION_HPP

#include "Body.hpp"
#include "Material.hpp"
#include "Particle.hpp"
#include "Types.hpp"
#include <vector>

namespace mpm3d {

/**
 * @brief ConstitutionModel - handles all constitutive stress update
 * calculations
 *
 * This class implements the Constitution() and TLConstitution() functions from
 * Fortran. Supports 11+ material models with various constitutive behaviors.
 */
class ConstitutionModel {
public:
  ConstitutionModel();

  // Main constitutive update functions
  void constitution(const Vec6 &strain_increment, const Vec3 &vorticity,
                    const Mat3 &vel_gradient, int body_id, int particle_id,
                    const BodyList &body_list, ParticleList &particle_list,
                    const MaterialList &material_list, Real dt,
                    Real current_time, Real cell_size);

  void TLConstitution(const Vec6 &strain_increment, const Vec3 &vorticity,
                      const Mat3 &vel_gradient, int body_id, int particle_id,
                      const BodyList &body_list, ParticleList &particle_list,
                      const MaterialList &material_list, Real dt,
                      Real cell_size);

  // Utility functions
  void stressRotation(const Vec3 &vorticity, Vec6 &stress, Real &mean_stress,
                      Vec6 &dev_stress);
  void updateEnergyLie();
  void updateEnergyHie(bool failure);
  Real computeEquivalentStress(const Vec6 &dev_stress);
  void computeBulkViscosity();
  void selectEquationOfState(bool &failure);

  // Material model implementations
  void M3DM1_Elastic();
  void M3DM2_ElasticPerfectPlastic();
  void M3DM3_IsotropicHardening();
  void M3DM4_JohnsonCook(const Material &mat, Real dt, Real temperature);
  void M3DM5_SimplifiedJC(const Material &mat, Real dt);
  void M3DM6_HighExplosive(Real lighting_time, Real current_time,
                           Real det_velocity);
  void M3DM7_Null(Real dt);
  void M3DM8_JCWithFailure(const Material &mat, Real dt, Real temperature,
                           bool &failure);
  void M3DM9_DruckerPrager(const Material &mat, Real dt);
  void M3DM10_NeoHookean();
  void M3DM11_NeoHookeanTL();

  // Helper functions for constitutive models
  void elasticDeviatoricUpdate();
  void elasticPressureUpdate();
  void plasticCorrection(Real yield_stress, Real hardening_modulus);
  void druckerPragerCorrection(Real q_fai, Real k_fai, Real q_psi, Real ten_f);

  // EOS functions
  void linearPolynomialEOS(const Material &mat);
  void gruneisenEOS(const Material &mat);
  void JWLEOS(const Material &mat);
  void taitEOS(const Material &mat);

private:
  // Working variables (correspond to module-level variables in Fortran)
  int mid_;            // Material set ID
  MaterialType mtype_; // Material model type
  EosType etype_;      // EOS type

  Real young_, poisson_;  // Elastic properties
  Real yield0_, tangmod_; // Plasticity properties

  Real den0_; // Initial density
  Real den_;  // Current density

  Real vold_; // Volume at step n
  Real vol_;  // Current volume
  Real vol0_; // Initial volume
  Real dvol_; // 0.5 * volume increment

  Vec6 dinc_;    // Strain increment
  Mat3 deF_;     // Deformation gradient increment
  Real sm_;      // Mean stress
  Real smold_;   // Mean stress of last step
  Vec6 sd_;      // Deviatoric stress
  Mat3 Fp_;      // Deformation gradient tensor
  Vec9 ppk_old_; // PK stress at step n (TLMPM)
  Vec9 ppk_new_; // PK stress at step n+1 (TLMPM)
  Vec6 sig_;     // Stress components
  Vec6 sold_;    // Deviatoric stress of step n
  Real dsm_;     // Mean stress increment
  Real bqf_;     // Bulk viscosity force

  Real seqv_;   // Equivalent stress
  Real epeff_;  // Effective plastic strain
  Real sig_y_;  // Current yield stress
  Real depeff_; // Increment of equivalent plastic strain
  Real ratio_;  // For hardening calculation

  Real G2_, K3_, PlaMod_; // 2*G, 3*K, plastic hardening modulus
  Real lamda_;            // Lame's first parameter
  Real miu2_;             // 2*miu
  Real specheat_;         // Specific heat
  Real tmprt_;            // Temperature

  Real iener_;  // Internal energy
  Real specen_; // Internal energy per initial volume
  Real ieinc_;  // Internal energy increment

  Real mu_;   // mu = den_/den0_ - 1
  Real rv_;   // Relative volume rv = vol_/vol0_
  Real bfac_; // Burn fraction
  Real cp_;   // Sound speed

  Real DMG_;    // Damage
  Real oldDMG_; // Damage of last step

  // Global parameters (passed in or from material list)
  Real dt_;           // Current time step
  Real current_time_; // Current simulation time
  Real cell_size_;    // Grid cell size
  Real bq1_, bq2_;    // Bulk viscosity coefficients
  bool Jaum_;         // Use Jaumann rate?
};

} // namespace mpm3d

#endif // MPM3D_CONSTITUTION_HPP
