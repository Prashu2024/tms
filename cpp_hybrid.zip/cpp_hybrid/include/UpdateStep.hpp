#ifndef MPM3D_UPDATESTEP_HPP
#define MPM3D_UPDATESTEP_HPP

#include "Types.hpp"
#include "Particle.hpp"
#include "Body.hpp"
#include "Grid.hpp"
#include "Material.hpp"
#include "ShapeFunction.hpp"
#include "Constitution.hpp"
#include "Contact.hpp"

namespace mpm3d {

/**
 * @brief UpdateStep - Contains all MPM algorithm step functions
 * 
 * This class implements the core MPM algorithm including:
 * - Particle to Grid (P2G) transfers
 * - Grid operations
 * - Grid to Particle (G2P) transfers
 * - Boundary conditions
 * - Contact detection
 * - Energy calculations
 * - Adaptive time stepping
 */
class UpdateStep {
public:
    UpdateStep();
    
    // Initialize with data structures
    void initialize(ParticleList& particles,
                   BodyList& bodies,
                   Grid& grid,
                   MaterialList& materials,
                   ShapeFunction& shape_func,
                   ConstitutionModel& constitution);
    
    // ========== Standard MPM Steps ==========
    
    // Initialize grid mass
    void gridMassInitial();
    
    // P2G: Map particle mass and momentum to grid
    virtual void gridMomentumInitial();

    // Calculate particle grid coordinates
    void particleInitial();

    // Update particle stresses using constitutive models
    virtual void particleStressUpdate();

    // Calculate grid nodal forces
    virtual void gridMomentumUpdate();

    // Explicit time integration on grid
    virtual void integrateMomentum(int step);

    // G2P: Map grid velocities back to particles and update positions
    virtual void particlePositionUpdate(int step);
    
    // Modified USL momentum calculation
    void gridMomentumMUSL();
    
    // Apply boundary conditions to grid nodes
    void applyBoundaryConditions();
    
    // ========== Total Lagrangian MPM Steps ==========
    
    void TLParticleInitial();
    void TLGridMomentumInitial();
    void TLParticleStressUpdate();
    void TLGridMomentumUpdate();
    void TLSmoothStressByGrid();
    
    // ========== Advanced Features ==========
    
    // Adaptive time stepping
    void updateDT();

    // Initial time step (Fortran SetDT) - does NOT include max particle velocity
    void setDTInitial();
    
    // Calculate kinetic and internal energy
    virtual void calcEnergy();

    // MPI domain decomposition: initial particle migration
    void migrateParticlesInitial();
    
    // Stress smoothing for stability
    void smoothStressByGrid();
    
    // Dynamic relaxation damping for quasi-static
    void dynamicRelaxationDamping();
    
    // Lagrangian contact detection and resolution
    void lagr_NodContact();
    
    // ========== SGMP Auxiliary Grid ==========
    
    void SGMPTransfer();
    
    // ========== Getters/Setters ==========
    
    Real getDT() const { return dt_; }
    void setDT(Real dt) { dt_ = dt; }
    
    Real getCurrentTime() const { return current_time_; }
    void setCurrentTime(Real t) { current_time_ = t; }
    
    Real getDTScale() const { return dt_scale_; }
    void setDTScale(Real scale) { dt_scale_ = scale; }
    
    Real getCutOff() const { return cutoff_; }
    void setCutOff(Real cutoff) { cutoff_ = cutoff; }
    
    // Getters for energy and momentum
    Real getKineticEnergy() const { return kinetic_energy_; }
    Real getInternalEnergy() const { return internal_energy_; }
    Vec3 getMomentum() const { return momentum_; }
    Vec3 getTotalContactForce() const { return contact_.getTotalContactForce(); }
    
    Real getLastMaxVp() const { return last_max_vp_; }
    Real getLastDtMin() const { return last_dt_min_; }
    Real getLastMaxVg() const { return last_max_vg_; }
    
    // Algorithm flags
    void setUSL(bool usl) { USL_ = usl; }
    void setUSF(bool usf) { USF_ = usf; }
    void setMUSL(bool musl) { MUSL_ = musl; }
    void setTLMPM(bool tlmpm) { TLMPM_ = tlmpm; }
    void setGIMP(bool gimp) { GIMP_ = gimp; }
    void setBspline(bool bspline) { Bspline_ = bspline; }
    void setSGMP(bool sgmp) { SGMP_ = sgmp; }
    void setContact(bool contact) { contact_enabled_ = contact; }
    void setContactType(ContactType type, Real friction = 0.0, Real penalty_k = 1.0e6) {
        contact_.initialize(type, friction, penalty_k);
    }
    void setUpdateVbyFp(bool update) { UpdateVbyFp_ = update; }
    void setQuasiLoad(bool quasi) { QuasiLoad_ = quasi; }
    
    // Grid data management
    void resetGridData();
    
private:
    // Reference to data structures
    ParticleList* particles_;
    BodyList* bodies_;
    Grid* grid_;
    MaterialList* materials_;
    ShapeFunction* shape_func_;
    ConstitutionModel* constitution_;
    
    // Time parameters
    Real dt_;               // Current time step
    Real dt_scale_;         // Time step scale factor
    Real current_time_;     // Current simulation time
    
    // Grid parameters
    Real cutoff_;           // Mass cutoff threshold
    
    // Method to calculate cutoff value based on Fortran formula
    void calculateCutoff();
    
    // Energy tracking
    Real kinetic_energy_;
    Real internal_energy_;
    Vec3 momentum_;
    
    // Contact tracking
    Contact contact_;
    bool contact_enabled_;
    
    Real last_max_vp_;
    Real last_dt_min_;
    Real last_max_vg_;
    
    // Algorithm flags
    bool USL_;              // Update Stress Last
    bool USF_;              // Update Stress First
    bool MUSL_;             // Modified USL
    bool TLMPM_;            // Total Lagrangian MPM
    bool GIMP_;             // Use GIMP shape functions
    bool Bspline_;          // Use B-spline shape functions
    bool SGMP_;             // Use SGMP auxiliary grid
    bool UpdateVbyFp_;      // Update volume by deformation gradient
    bool QuasiLoad_;        // Quasi-static loading with damping
    bool dd_filter_particles_; // MPI domain decomposition: filter by owner
    bool dd_allreduce_;        // MPI domain decomposition: global reductions
    bool dd_migrate_particles_; // MPI domain decomposition: migrate particles
    bool dd_strict_;           // MPI correctness mode: disable filtering
    bool dd_exchange_nodes_;   // MPI domain decomposition: ghost-node exchange
    bool dd_repro_mode_;       // MPI domain decomposition: deterministic reductions
    bool dd_balance_replica_;  // MPI DD replicated mode: refresh owner each step
    
    // Helper functions
    int inWhichCell(const Vec3& position);
    int centerInWhichCell(const Vec3& position);

    // Shared dt computation
    Real computeStableDt(bool include_max_vp);

    // MPI domain decomposition: migrate particles between ranks
    void migrateParticles(bool use_current_position = false);
    void rebuildBodyRanges();
    
    // Pre-allocated arrays for performance (matching Fortran)
    static const int MAX_INFL_NODES = 27;
    std::vector<int> infl_nodes_;
    std::vector<Real> shape_values_;
    std::vector<Vec3> shape_gradients_;

    // Persistent SoA scratch buffers for hotspot kernels.
    std::vector<int> soa_pid_;
    std::vector<int> soa_comp_off_;
    std::vector<Real> soa_mass_;
    std::vector<Real> soa_vx_;
    std::vector<Real> soa_vy_;
    std::vector<Real> soa_vz_;
    std::vector<Real> soa_fx0_;
    std::vector<Real> soa_fx1_;
    std::vector<Real> soa_fx2_;
    std::vector<Real> soa_s0_;
    std::vector<Real> soa_s1_;
    std::vector<Real> soa_s2_;
    std::vector<Real> soa_s3_;
    std::vector<Real> soa_s4_;
    std::vector<Real> soa_s5_;
    std::vector<Real> soa_vol_;
    
    // Pre-allocated influence domain to avoid repeated allocations
    InfluenceDomain influence_domain_;

    bool isParticleLocal(const Particle& pt) const;
    bool isParticleStateLocal(const Particle& pt) const;
};

} // namespace mpm3d

#endif // MPM3D_UPDATESTEP_HPP
