#ifndef MPM3D_DATAOUT_HPP
#define MPM3D_DATAOUT_HPP

#include "Types.hpp"
#include "Particle.hpp"
#include "Body.hpp"
#include "Grid.hpp"
#include <string>

namespace mpm3d {

/**
 * @brief Output file generation
 * Supports VTK (ParaView), TecPlot, and curve data
 */
class DataOut {
public:
    DataOut();
    
    // Initialize output
    void initialize(const std::string& job_name, bool tecplot = false, 
                   bool paraview = true);
    
    // Write output at current time
    void writeOutput(Real time, const ParticleList& particles,
                    const BodyList& bodies, const Grid& grid);
    
    // Write energy data only
    void writeEnergy(Real time, const ParticleList& particles);

    // Write energy/momentum data from precomputed values
    void writeEnergy(Real time, Real kinetic_energy, Real internal_energy,
                     const Vec3& momentum);
    
    // Finalize output
    void finalize();
    
    // Enable/disable output types
    void setWriteTecPlot(bool enable) { write_tecplot_ = enable; }
    void setWriteParaView(bool enable) { write_paraview_ = enable; }
    void setWriteCurves(bool enable) { write_curves_ = enable; }
    
    // Enable/disable contact output and set contact force
    void setContactEnabled(bool enabled) { contact_enabled_ = enabled; }
    void setContactForce(const Vec3& force) { contact_force_ = force; }
    
private:
    // ParaView VTK output
    void initializeParaView();
    void writeParaView(Real time, const ParticleList& particles,
                      const BodyList& bodies, const Grid& grid);
    void updatePVDCollection(Real time, const std::string& vtu_file);
    
    // TecPlot output
    void writeTecPlot(Real time, const ParticleList& particles,
                     const BodyList& bodies);
    
    // Curve data output
    void initializeCurves();
    void writeCurves(Real time, const ParticleList& particles);
    
    // Filenames
    std::string job_name_;
    std::string pvd_filename_;      // ParaView collection
    std::string curve_filename_;    // Curve data
    std::string energy_filename_;   // Energy history
    std::string momentum_filename_; // Momentum history
    
    // Counters
    int output_counter_;
    
    // Flags
    bool write_tecplot_;
    bool write_paraview_;
    bool write_curves_;
    bool contact_enabled_;
    Vec3 contact_force_;
};

} // namespace mpm3d

#endif // MPM3D_DATAOUT_HPP
