#ifndef MPM3D_BODY_HPP
#define MPM3D_BODY_HPP

#include "Types.hpp"

namespace mpm3d {

/**
 * @brief Body class - represents a collection of particles with same material
 * 
 * Bodies are used for:
 * - Grouping particles by material
 * - Organizing contact detection (different components)
 * - Applying body-specific gravity
 */
class Body {
public:
    Body() : material_id_(0), component_id_(1), 
             gravity_({0, 0, 0}),
             particle_begin_(0), particle_end_(0) {}
    
    Body(int mat_id, int comp_id, int par_begin, int par_end)
        : material_id_(mat_id), component_id_(comp_id),
          gravity_({0, 0, 0}),
          particle_begin_(par_begin), particle_end_(par_end) {}
    
    // Material ID (1 to nb_mat)
    int getMaterialID() const { return material_id_; }
    void setMaterialID(int id) { material_id_ = id; }
    
    // Component ID for contact (1 to nb_component)
    int getComponentID() const { return component_id_; }
    void setComponentID(int id) { component_id_ = id; }
    
    // Particle range in particle list
    int getParticleBegin() const { return particle_begin_; }
    void setParticleBegin(int begin) { particle_begin_ = begin; }
    
    int getParticleEnd() const { return particle_end_; }
    void setParticleEnd(int end) { particle_end_ = end; }
    
    void setParticleRange(int begin, int end) {
        particle_begin_ = begin;
        particle_end_ = end;
    }
    
    int getNumParticles() const {
        return particle_end_ - particle_begin_;
    }
    
    // Body-specific gravity
    Vec3 getGravity() const { return gravity_; }
    void setGravity(const Vec3& g) { gravity_ = g; }
    
private:
    int material_id_;      // Material set number (1 ~ nb_mat)
    int component_id_;     // Component set number (1 ~ nb_component)
    Vec3 gravity_;         // Body-specific gravity
    int particle_begin_;   // Index of first particle
    int particle_end_;     // Index of last particle (exclusive)
};

// Body container
using BodyList = std::vector<Body>;

} // namespace mpm3d

#endif // MPM3D_BODY_HPP