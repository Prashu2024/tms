#ifndef MPM3D_TYPES_HPP
#define MPM3D_TYPES_HPP

#include <array>
#include <vector>
#include <memory>
#include <string>
#include <cmath>

namespace mpm3d {

// Precision type
using Real = double;

// Vector types
using Vec2 = std::array<Real, 2>;
using Vec3 = std::array<Real, 3>;
using Vec3i = std::array<int, 3>;

// 3x3 matrix type (row-major)
using Mat3 = std::array<std::array<Real, 3>, 3>;

// 6-component vector for stress/strain (Voigt notation: xx, yy, zz, yz, xz, xy)
using Vec6 = std::array<Real, 6>;

// 9-component vector for PK stress
using Vec9 = std::array<Real, 9>;

// Constants
constexpr Real PI = 3.141592653589793;
constexpr Real EPSILON = 1.0e-15;

// Algorithm types
enum class AlgorithmType {
    USL,      // Update Stress Last
    USF,      // Update Stress First  
    MUSL,     // Modified Update Stress Last
    TLMPM     // Total Lagrangian MPM
};

// Shape function types
enum class ShapeFunctionType {
    LINEAR,    // Standard linear
    GIMP,      // Generalized Interpolation Material Point
    BSPLINE,   // Cubic B-spline
    SGMP       // Stabilized Grid Material Point
};

// Material types
enum class MaterialType {
    ELASTIC = 1,              // Elastic
    ELASTIC_PERFECT_PLASTIC,  // Elastic-perfectly plastic
    ISOTROPIC_HARDENING,      // Isotropic hardening
    JOHNSON_COOK,             // Johnson-Cook
    SIMPLIFIED_JC,            // Simplified Johnson-Cook
    HIGH_EXPLOSIVE,           // High explosive (M3DM6)
    SIMPLIFIED_JC_FAILURE,    // SJC with failure
    JC_FAILURE,               // Johnson-Cook with failure
    DRUCKER_PRAGER,           // Drucker-Prager soil
    FLUID,                    // Fluid
    RIGID_BODY,               // Rigid body (type 12)
    USER_MAT1,                // User-defined material 1
    USER_MAT2,
    USER_MAT3,
    USER_MAT4,
    USER_MAT5
};

// Equation of State types
enum class EosType {
    NONE = 0,
    LINEAR_POLYNOMIAL,
    GRUNEISEN,
    JWL,                      // Jones-Wilkins-Lee (explosives)
    TAIT,
    USER_EOS
};

// Contact types
enum class ContactType {
    NONE = 0,
    LAGRANGIAN,               // Lagrangian contact
    PENALTY                   // Penalty method
};

// Boundary types
enum class BoundaryType {
    FREE = 0,
    FIXED,
    SYMMETRIC,
    VELOCITY,
    FORCE
};

// Utility functions for vector operations
inline Vec3 operator+(const Vec3& a, const Vec3& b) {
    return {a[0] + b[0], a[1] + b[1], a[2] + b[2]};
}

inline Vec3 operator-(const Vec3& a, const Vec3& b) {
    return {a[0] - b[0], a[1] - b[1], a[2] - b[2]};
}

inline Vec3 operator*(Real s, const Vec3& v) {
    return {s * v[0], s * v[1], s * v[2]};
}

inline Vec3 operator*(const Vec3& v, Real s) {
    return s * v;
}

inline Vec3 operator/(const Vec3& v, Real s) {
    return {v[0] / s, v[1] / s, v[2] / s};
}

inline Vec3& operator+=(Vec3& a, const Vec3& b) {
    a[0] += b[0]; a[1] += b[1]; a[2] += b[2];
    return a;
}

inline Vec3& operator-=(Vec3& a, const Vec3& b) {
    a[0] -= b[0]; a[1] -= b[1]; a[2] -= b[2];
    return a;
}

inline Real dot(const Vec3& a, const Vec3& b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

inline Real norm(const Vec3& v) {
    return std::sqrt(dot(v, v));
}

inline Vec3 cross(const Vec3& a, const Vec3& b) {
    return {
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0]
    };
}

inline Vec3 normalize(const Vec3& v) {
    Real n = norm(v);
    if (n < EPSILON) return {0, 0, 0};
    return v / n;
}

// Matrix operations
inline Mat3 zero_mat3() {
    Mat3 m;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            m[i][j] = 0.0;
    return m;
}

inline Mat3 identity_mat3() {
    Mat3 m = zero_mat3();
    m[0][0] = m[1][1] = m[2][2] = 1.0;
    return m;
}

inline Real trace(const Mat3& m) {
    return m[0][0] + m[1][1] + m[2][2];
}

inline Real det(const Mat3& m) {
    return m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
         - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
         + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
}

inline Mat3 transpose(const Mat3& m) {
    Mat3 result;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            result[i][j] = m[j][i];
    return result;
}

inline Mat3 operator*(const Mat3& a, const Mat3& b) {
    Mat3 result = zero_mat3();
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            for (int k = 0; k < 3; ++k)
                result[i][j] += a[i][k] * b[k][j];
    return result;
}

inline Mat3 operator+(const Mat3& a, const Mat3& b) {
    Mat3 result;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            result[i][j] = a[i][j] + b[i][j];
    return result;
}

inline Mat3 operator-(const Mat3& a, const Mat3& b) {
    Mat3 result;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            result[i][j] = a[i][j] - b[i][j];
    return result;
}

inline Mat3 operator*(Real s, const Mat3& m) {
    Mat3 result;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            result[i][j] = s * m[i][j];
    return result;
}

inline Vec3 operator*(const Mat3& m, const Vec3& v) {
    Vec3 result;
    for (int i = 0; i < 3; ++i) {
        result[i] = 0.0;
        for (int j = 0; j < 3; ++j)
            result[i] += m[i][j] * v[j];
    }
    return result;
}

// Voigt notation utilities
inline Mat3 voigt_to_matrix(const Vec6& voigt) {
    Mat3 m;
    m[0][0] = voigt[0]; // xx
    m[1][1] = voigt[1]; // yy
    m[2][2] = voigt[2]; // zz
    m[1][2] = m[2][1] = voigt[3]; // yz
    m[0][2] = m[2][0] = voigt[4]; // xz
    m[0][1] = m[1][0] = voigt[5]; // xy
    return m;
}

inline Vec6 matrix_to_voigt(const Mat3& m) {
    return {
        m[0][0],         // xx
        m[1][1],         // yy
        m[2][2],         // zz
        m[1][2],         // yz
        m[0][2],         // xz
        m[0][1]          // xy
    };
}

// Deviatoric stress utilities
inline Real von_mises_stress(const Vec6& stress) {
    Real sxx = stress[0];
    Real syy = stress[1];
    Real szz = stress[2];
    Real syz = stress[3];
    Real sxz = stress[4];
    Real sxy = stress[5];
    
    return std::sqrt(0.5 * ((sxx - syy) * (sxx - syy) + 
                            (syy - szz) * (syy - szz) + 
                            (szz - sxx) * (szz - sxx) +
                            6.0 * (sxy * sxy + syz * syz + sxz * sxz)));
}

inline Real mean_stress(const Vec6& stress) {
    return (stress[0] + stress[1] + stress[2]) / 3.0;
}

inline Vec6 deviatoric_stress(const Vec6& stress) {
    Real sm = mean_stress(stress);
    return {
        stress[0] - sm,
        stress[1] - sm,
        stress[2] - sm,
        stress[3],
        stress[4],
        stress[5]
    };
}

// Sign function for shape functions
constexpr int SNX[8] = {-1, 1, 1, -1, -1, 1, 1, -1};
constexpr int SNY[8] = {-1, -1, 1, 1, -1, -1, 1, 1};
constexpr int SNZ[8] = {-1, -1, -1, -1, 1, 1, 1, 1};

} // namespace mpm3d

#endif // MPM3D_TYPES_HPP