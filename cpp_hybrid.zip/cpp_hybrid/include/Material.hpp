#ifndef MPM3D_MATERIAL_HPP
#define MPM3D_MATERIAL_HPP

#include "Types.hpp"
#include <string>
#include <array>
#include <stdexcept>

namespace mpm3d {

/**
 * @brief Material class - contains all material properties
 * 
 * Supports multiple material models:
 * - Elastic
 * - Elastic-perfectly plastic
 * - Isotropic hardening
 * - Johnson-Cook plasticity
 * - Drucker-Prager soil model
 * - User-defined materials
 */
class Material {
public:
    Material();
    
    // ========== Material Identification ==========
    
    MaterialType getMaterialType() const { return MatType_; }
    void setMaterialType(MaterialType type) { MatType_ = type; }
    
    EosType getEosType() const { return EosType_; }
    void setEosType(EosType type) { EosType_ = type; }
    
    std::string getName() const { return name_; }
    void setName(const std::string& name) { name_ = name; }
    
    int getID() const { return id_; }
    void setID(int id) { id_ = id; }
    
    // ========== Basic Mechanical Properties ==========
    
    Real getDensity() const { return Density_; }
    void setDensity(Real rho) { Density_ = rho; }
    
    Real getYoungsModulus() const { return Young_; }
    void setYoungsModulus(Real E) { Young_ = E; }
    
    Real getPoissonsRatio() const { return Poisson_; }
    void setPoissonsRatio(Real nu) { Poisson_ = nu; }
    
    Real getDynamicViscosity() const { return miu_; }
    void setDynamicViscosity(Real mu) { miu_ = mu; }
    
    // Derived properties
    Real getBulkModulus() const { return BulkModulus_; }
    void setBulkModulus(Real K) { BulkModulus_ = K; }
    
    Real getShearModulus() const {
        return Young_ / (2.0 * (1.0 + Poisson_));
    }
    
    Real getLameFirstParameter() const {
        return (Young_ * Poisson_) / ((1.0 + Poisson_) * (1.0 - 2.0 * Poisson_));
    }
    
    // ========== Plasticity Properties ==========
    
    Real getYieldStress() const { return Yield0_; }
    void setYieldStress(Real sy) { Yield0_ = sy; }
    
    Real getTangentModulus() const { return TangMod_; }
    void setTangentModulus(Real H) { TangMod_ = H; }
    
    Real getPlasticModulus() const {
        if (std::abs(Young_ - TangMod_) < EPSILON) return 0.0;
        return (Young_ * TangMod_) / (Young_ - TangMod_);
    }
    
    // ========== Johnson-Cook Parameters ==========
    
    Real getJC_B() const { return B_jc_; }
    void setJC_B(Real B) { B_jc_ = B; }
    
    Real getJC_n() const { return n_jc_; }
    void setJC_n(Real n) { n_jc_ = n; }
    
    Real getJC_C() const { return C_jc_; }
    void setJC_C(Real C) { C_jc_ = C; }
    
    Real getJC_m() const { return m_jc_; }
    void setJC_m(Real m) { m_jc_ = m; }
    
    Real getJC_epso() const { return epso_; }
    void setJC_epso(Real eps0) { epso_ = eps0; }
    
    // ========== Failure Parameters ==========
    
    Real getPressureAtDamage() const { return prd_; }
    void setPressureAtDamage(Real p) { prd_ = p; }
    
    Real getPlasticStrainAtFailure() const { return epf_; }
    void setPlasticStrainAtFailure(Real epf) { epf_ = epf; }
    
    // ========== Thermal Properties ==========
    
    Real getRoomTemperature() const { return roomt_; }
    void setRoomTemperature(Real T) { roomt_ = T; }
    
    Real getMeltingTemperature() const { return Melt_; }
    void setMeltingTemperature(Real Tm) { Melt_ = Tm; }
    
    Real getSpecificHeat() const { return SpecHeat_; }
    void setSpecificHeat(Real cp) { SpecHeat_ = cp; }
    
    // ========== Explosive Properties ==========
    
    Real getDetonationVelocity() const { return D_; }
    void setDetonationVelocity(Real D) { D_ = D; }
    
    // ========== Equation of State Constants ==========
    
    const std::array<Real, 10>& getEosConstants() const { return cEos_; }
    void setEosConstant(int index, Real value) {
        if (index >= 0 && index < 10) {
            cEos_[index] = value;
        }
    }
    void setEosConstants(const std::array<Real, 10>& constants) {
        cEos_ = constants;
    }
    
    // ========== Drucker-Prager Parameters ==========
    
    Real getDP_q_fai() const { return q_fai_; }
    void setDP_q_fai(Real q) { q_fai_ = q; }
    
    Real getDP_k_fai() const { return k_fai_; }
    void setDP_k_fai(Real k) { k_fai_ = k; }
    
    Real getDP_q_psi() const { return q_psi_; }
    void setDP_q_psi(Real q) { q_psi_ = q; }
    
    Real getDP_ten_f() const { return ten_f_; }
    void setDP_ten_f(Real t) { ten_f_ = t; }
    
    // ========== Particle Mass ==========
    
    Real getParticleMass() const { return Mp_; }
    void setParticleMass(Real m) { Mp_ = m; }
    
    // ========== Wave Speed ==========
    
    Real getWaveSpeed() const { return Wavespd_; }
    void setWaveSpeed(Real c) { Wavespd_ = c; }
    
    Real computeWaveSpeed() const {
        if (Density_ < EPSILON) return 0.0;
        Real K = getBulkModulus();
        return std::sqrt(K / Density_);
    }
    
private:
    // Identification
    MaterialType MatType_;
    EosType EosType_;
    std::string name_;
    int id_;
    
    // Basic properties
    Real Density_;          // Initial density
    Real Young_;            // Young's modulus
    Real Poisson_;          // Poisson's ratio
    Real miu_;              // Dynamic viscosity
    Real Mp_;               // Particle mass
    Real BulkModulus_;      // Bulk modulus (can be computed or set)
    Real Wavespd_;          // Wave speed
    
    // Plasticity
    Real Yield0_;           // Initial yield stress
    Real TangMod_;          // Tangential modulus (hardening)
    
    // Johnson-Cook parameters
    Real B_jc_;             // Strain hardening constant
    Real n_jc_;             // Strain hardening exponent
    Real C_jc_;             // Strain rate constant
    Real m_jc_;             // Thermal softening exponent
    Real epso_;             // Reference strain rate
    
    // Failure
    Real prd_;              // Pressure at damage initiation
    Real epf_;              // Plastic strain at failure
    
    // Thermal
    Real roomt_;            // Room temperature
    Real Melt_;             // Melting temperature
    Real SpecHeat_;         // Specific heat capacity
    
    // Explosives
    Real D_;                // Detonation velocity
    
    // Equation of State
    std::array<Real, 10> cEos_;  // EOS constants
    // Linear polynomial: C0, C1, C2, C3, C4, C5, C6
    // Gruneisen: C1, C2, C3, C4
    // JWL: A, B, R1, R2, W, E0, V0
    
    // Drucker-Prager parameters
    Real q_fai_;            // Friction parameter
    Real k_fai_;            // Cohesion parameter
    Real q_psi_;            // Dilation parameter
    Real ten_f_;            // Tensile cutoff
};

/**
 * @brief MaterialList - container for all materials
 */
class MaterialList {
public:
    MaterialList() : Jaum_(true), bq1_(1.5), bq2_(0.06), nDeto_(0) {
        DetoX_.fill(0.0);
        DetoY_.fill(0.0);
        DetoZ_.fill(0.0);
    }
    
    // Material management
    void addMaterial(const Material& mat) {
        materials_.push_back(mat);
    }
    
    Material& getMaterial(int id) {
        for (auto& mat : materials_) {
            if (mat.getID() == id) return mat;
        }
        throw std::runtime_error("Material ID not found: " + std::to_string(id));
    }
    
    const Material& getMaterial(int id) const {
        for (const auto& mat : materials_) {
            if (mat.getID() == id) return mat;
        }
        throw std::runtime_error("Material ID not found: " + std::to_string(id));
    }
    
    size_t getNumMaterials() const { return materials_.size(); }
    
    // Jaumann rate option
    bool useJaumannRate() const { return Jaum_; }
    void setUseJaumannRate(bool use) { Jaum_ = use; }
    
    // Bulk viscosity coefficients
    Real getBQ1() const { return bq1_; }
    Real getBQ2() const { return bq2_; }
    void setBQ1(Real bq1) { bq1_ = bq1; }
    void setBQ2(Real bq2) { bq2_ = bq2; }
    
    // Detonation points
    void addDetonationPoint(Real x, Real y, Real z) {
        if (nDeto_ < 10) {
            DetoX_[nDeto_] = x;
            DetoY_[nDeto_] = y;
            DetoZ_[nDeto_] = z;
            nDeto_++;
        }
    }
    
    int getNumDetonationPoints() const { return nDeto_; }
    Vec3 getDetonationPoint(int i) const {
        if (i >= 0 && i < nDeto_) {
            return {DetoX_[i], DetoY_[i], DetoZ_[i]};
        }
        return {0, 0, 0};
    }
    
private:
    std::vector<Material> materials_;
    
    bool Jaum_;                          // Use Jaumann rate?
    Real bq1_, bq2_;                     // Artificial bulk viscosity coefficients
    
    int nDeto_;                          // Number of detonation points
    std::array<Real, 10> DetoX_;         // Detonation point X coordinates
    std::array<Real, 10> DetoY_;         // Detonation point Y coordinates
    std::array<Real, 10> DetoZ_;         // Detonation point Z coordinates
};

} // namespace mpm3d

#endif // MPM3D_MATERIAL_HPP
