#ifndef MPM3D_MPMSOLVER_HPP
#define MPM3D_MPMSOLVER_HPP

#include "Types.hpp"
#include "Particle.hpp"
#include "Body.hpp"
#include "Grid.hpp"
#include "Material.hpp"
#include "ShapeFunction.hpp"
#include "Constitution.hpp"
#include "UpdateStep.hpp"
#include "DomainDecomp.hpp"
#include "DataIn.hpp"
#include "DataOut.hpp"
#include <memory>
#include <string>

namespace mpm3d {

/**
 * @brief Main MPM Solver class
 * Coordinates the entire MPM simulation
 */
class MPMSolver {
public:
    MPMSolver();
    
    // Initialize solver from input file
    void initialize(const std::string& input_file);
    
    // Run simulation
    void solve();
    
    // Setters
    void setAlgorithm(AlgorithmType alg) { algorithm_ = alg; }
    void setShapeFunctionType(ShapeFunctionType type) { shape_func_type_ = type; }
    void setFinalTime(Real t) { final_time_ = t; }
    void setTimeStep(Real dt) { dt_ = dt; }
    void setTimeStepScale(Real scale) { dt_scale_ = scale; }
    void setOutputInterval(Real interval) { output_interval_ = interval; }
    void setReportInterval(Real interval) { report_interval_ = interval; }
    void setQuasiStatic(bool quasi) { quasi_static_ = quasi; }
    
    // Getters
    Real getCurrentTime() const { return current_time_; }
    int getStep() const { return step_; }
    
    // Access to data structures
    ParticleList& getParticles() { return particles_; }
    BodyList& getBodies() { return bodies_; }
    Grid& getGrid() { return grid_; }
    MaterialList& getMaterials() { return materials_; }
    
private:
    // Main simulation step
    void step();
    
    // Algorithm-specific steps
    void stepUSL();    // Update Stress Last
    void stepUSF();    // Update Stress First
    void stepMUSL();   // Modified USL
    void stepTLMPM();  // Total Lagrangian
    
    // Output and reporting
    void report();
    void output();
    void writeEnergy();
    void finalReport();
    
    // Helper functions
    void setAlgorithmFlags();
    void initializeParticleProperties();
    std::string getAlgorithmName() const;
    std::string getShapeFunctionName() const;
    
    // Data structures
    ParticleList particles_;
    BodyList bodies_;
    Grid grid_;
    MaterialList materials_;
    
    // Solver components
    std::unique_ptr<ShapeFunction> shape_function_;
    std::unique_ptr<ConstitutionModel> constitution_;
    std::unique_ptr<UpdateStep> update_step_;
    
    // Algorithm settings
    AlgorithmType algorithm_;
    ShapeFunctionType shape_func_type_;
    
    // Time parameters
    Real current_time_;
    Real final_time_;
    Real dt_;
    Real dt_scale_;
    
    // Output parameters
    Real output_interval_;
    Real report_interval_;
    
    // Simulation state
    int step_;
    bool initialized_;
    bool quasi_static_;  // Quasi-static loading flag

    SimulationParameters params_;
    std::string job_name_;

    DataOut data_out_;
    bool data_out_initialized_;

    int mpi_rank_;
    int mpi_size_;
    bool mpi_strict_;

    bool isRootRank() const { return mpi_size_ <= 1 || mpi_rank_ == 0; }
};

} // namespace mpm3d

#endif // MPM3D_MPMSOLVER_HPP
