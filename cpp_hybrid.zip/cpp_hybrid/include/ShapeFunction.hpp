#ifndef MPM3D_SHAPE_FUNCTION_HPP
#define MPM3D_SHAPE_FUNCTION_HPP

#include "Types.hpp"
#include "Grid.hpp"
#include "Particle.hpp"
#include <vector>

namespace mpm3d {

/**
 * @brief ShapeFunction - handles shape function evaluation
 * 
 * Supports multiple shape function types:
 * - Linear (standard MPM)
 * - GIMP (Generalized Interpolation Material Point)
 * - B-spline (cubic B-spline)
 * - SGMP (Stabilized Grid Material Point)
 */
class ShapeFunction {
public:
    ShapeFunction(ShapeFunctionType type = ShapeFunctionType::LINEAR);
    
    // Set shape function type
    void setType(ShapeFunctionType type) { type_ = type; }
    ShapeFunctionType getType() const { return type_; }
    
    // Evaluate shape functions for a particle
    void evaluate(const Particle& particle, const Grid& grid,
                 std::vector<int>& node_indices,
                 std::vector<Real>& shape_values,
                 std::vector<Vec3>& shape_gradients);
    
    // Evaluate auxiliary grid shape functions (SGMP)
    void evaluateAuxiliary(const Particle& particle, const Grid& grid,
                          std::vector<int>& cell_indices,
                          std::vector<Real>& shape_values,
                          std::vector<Vec3>& shape_gradients);
    
    // Maximum number of influenced nodes
    int getMaxInfluenceNodes() const {
        switch (type_) {
            case ShapeFunctionType::LINEAR: return 8;
            case ShapeFunctionType::GIMP: return 27;
            case ShapeFunctionType::BSPLINE: return 27;
            case ShapeFunctionType::SGMP: return 8;
            default: return 8;
        }
    }
    
private:
    ShapeFunctionType type_;
    
    // Shape function evaluators for different types
    void evaluateLinear(const Vec3& xi, 
                       std::vector<Real>& N,
                       std::vector<Vec3>& dN,
                       Real cell_size);
    
    void evaluateGIMP(const Particle& particle, const Grid& grid,
                     std::vector<int>& nodes,
                     std::vector<Real>& N,
                     std::vector<Vec3>& dN);
    
    void evaluateBspline(const Particle& particle, const Grid& grid,
                        std::vector<int>& nodes,
                        std::vector<Real>& N,
                        std::vector<Vec3>& dN);
    
    void evaluateSGMP(const Vec3& xi,
                     std::vector<Real>& N,
                     std::vector<Vec3>& dN,
                     Real cell_size);
    
    // 1D shape functions
    Real linearShape(Real xi) const {
        return (std::abs(xi) < 1.0) ? (1.0 - std::abs(xi)) : 0.0;
    }
    
    Real linearShapeGrad(Real xi) const {
        if (xi < -1.0 || xi > 1.0) return 0.0;
        return (xi < 0.0) ? 1.0 : -1.0;
    }
    
    Real bsplineShape(Real xi) const;
    Real bsplineShapeGrad(Real xi) const;
    
    // GIMP helper functions
    void findGIMPInfluenceNodes(const Particle& particle, const Grid& grid,
                               int base_cell, std::vector<int>& nodes);
};

/**
 * @brief Influence domain helper
 */
struct InfluenceDomain {
    std::vector<int> node_indices;
    std::vector<Real> shape_values;
    std::vector<Vec3> shape_gradients;
    
    void clear() {
        node_indices.clear();
        shape_values.clear();
        shape_gradients.clear();
    }
    
    void reserve(size_t n) {
        node_indices.reserve(n);
        shape_values.reserve(n);
        shape_gradients.reserve(n);
    }
    
    size_t size() const {
        return node_indices.size();
    }
};

} // namespace mpm3d

#endif // MPM3D_SHAPE_FUNCTION_HPP
