#ifndef MPM3D_FFI_HPP
#define MPM3D_FFI_HPP

#include "Types.hpp"
#include <string>
#include <vector>

namespace mpm3d {

/**
 * @brief File Format Interface
 * Helper functions for parsing input files
 */
class FFI {
public:
    FFI();
    
    // String utilities
    static std::string trim(const std::string& str);
    static std::string toLower(const std::string& str);
    static std::vector<std::string> split(const std::string& str, char delimiter = ' ');
    
    // Line parsing
    static bool isComment(const std::string& line);
    static bool isKeyword(const std::string& line, const std::string& keyword);
    
    // Value parsing
    static int parseInteger(const std::string& str);
    static Real parseReal(const std::string& str);
    static bool parseBool(const std::string& str);
};

} // namespace mpm3d

#endif // MPM3D_FFI_HPP
