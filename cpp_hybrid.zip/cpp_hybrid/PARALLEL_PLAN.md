# Parallelization plan (MPI + OpenMP)

This directory is the parallel track for MPM3D. The goal is bitwise-identical
results vs the serial C++ when running with 1 MPI rank and 1 OpenMP thread, and
numerically identical (within a strict tolerance) for multi-rank/thread runs.

## Domain decomposition
- Use a 3D block decomposition of the background grid.
- Each MPI rank owns a subdomain of cells and the nodes that bound those cells.
- Introduce 1-cell ghost layers for nodal data that are required by shape
  functions spanning neighboring cells.
- Particle ownership is by the cell containing the particle center; particles
  migrate across ranks when their containing cell changes.

## Data exchange (overlap handling)
- Ghost-node halo exchange at each step for nodal quantities needed by G2P and
  boundary conditions:
  - mass, momentum, velocity, force, pressure, volume (and auxiliary grid data
    if SGMP is enabled).
- Use deterministic exchange order (rank-ordered) and deterministic reduction
  when multiple ranks contribute to the same ghost node.

## Parallelization order
1. OpenMP-only safe loops (no shared writes): particle initializations, particle
   stress update (with thread-local scratch), G2P operations that only write to
   particle state.
2. OpenMP for reductions using thread-local node buffers followed by a fixed
   serial merge into global nodes to preserve determinism.
3. MPI domain decomposition (grid + particle migration) with ghost-layer halo
   exchanges; deterministic rank-ordered reductions.

## Determinism strategy
- Avoid atomics for floating-point accumulation when exact matching is required.
- Use fixed traversal order for reductions (per-thread buffers reduced in a
  fixed thread index order; per-rank buffers reduced in rank order).
- Provide a strict mode that enforces deterministic reductions even if slower.

